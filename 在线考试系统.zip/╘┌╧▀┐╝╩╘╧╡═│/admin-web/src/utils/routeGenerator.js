import { defineAsyncComponent } from 'vue'

// 生成路由配置
export function generateRoutes(menus) {
    return menus.map(menu => {
        const route = {
            path: menu.path,
            name: menu.name,
            component: loadComponent(menu.component),
            meta: {
                title: menu.name,
                icon: menu.icon
            }
        }

        if (menu.children && menu.children.length > 0) {
            route.children = generateRoutes(menu.children)
        }

        return route
    })
}

// 动态加载组件
function loadComponent(component) {
    // Layout 组件特殊处理
    if (component === 'Layout') {
        return defineAsyncComponent(() => import('../layout/index.vue'))
    }
    
    // 其他组件动态导入
    return defineAsyncComponent(() => import(`../views/${component}.vue`))
}

// 生成菜单配置
export function generateMenus(menus) {
    return menus.map(menu => {
        const menuItem = {
            name: menu.name,
            path: menu.path,
            meta: {
                title: menu.name,
                icon: menu.icon
            }
        }

        if (menu.children && menu.children.length > 0) {
            menuItem.children = generateMenus(menu.children)
        }

        return menuItem
    })
} 