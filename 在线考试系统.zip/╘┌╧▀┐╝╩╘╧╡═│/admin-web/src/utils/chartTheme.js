export const chartColors = [
  '#6b9ac4', // 主色
  '#8fc0a9', // 辅助色1
  '#fad284', // 辅助色2
  '#f4989c', // 辅助色3
  '#b8c4d4', // 辅助色4
  '#a0d8ef', // 辅助色5
  '#f7d794', // 辅助色6
  '#ff9b9b'  // 辅助色7
]

export const chartTheme = {
  color: chartColors,
  
  title: {
    textStyle: {
      color: '#2c3e50'
    }
  },
  
  legend: {
    textStyle: {
      color: '#606266'
    }
  },
  
  tooltip: {
    backgroundColor: 'rgba(255,255,255,0.9)',
    borderColor: '#ebeef5',
    textStyle: {
      color: '#606266'
    }
  }
} 