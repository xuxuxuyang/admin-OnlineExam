import { api } from './auth'
export const test = () => {
  return api.get('/students/test')
} 