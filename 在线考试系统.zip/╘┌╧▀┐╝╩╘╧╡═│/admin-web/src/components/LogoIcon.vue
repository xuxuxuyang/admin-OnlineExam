<template>
    <svg class="logo-icon" width="32" height="32" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="128" height="128" rx="24" fill="currentColor"/>
        <path d="M40 32L60 64L40 96" stroke="white" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M88 32L68 64L88 96" stroke="white" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M44 64H84" stroke="white" stroke-width="8" stroke-linecap="round"/>
    </svg>
</template>

<style scoped>
.logo-icon {
    vertical-align: middle;
    transform: scale(0.9);
}

/* 添加悬停效果 */
.logo-icon:hover {
    transform: scale(1);
    transition: transform 0.3s ease;
}
</style> 