<template>
  <el-card class="base-card" :body-style="{ padding: '20px' }">
    <template #header>
      <div class="card-header">
        <slot name="header"></slot>
      </div>
    </template>
    <slot></slot>
  </el-card>
</template>

<style scoped>
.base-card {
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.05);
  transition: all 0.3s;
}

.base-card:hover {
  box-shadow: 0 4px 16px 0 rgba(0,0,0,0.08);
}

.card-header {
  padding: 16px 20px;
  border-bottom: 1px solid var(--border-color);
}
</style> 