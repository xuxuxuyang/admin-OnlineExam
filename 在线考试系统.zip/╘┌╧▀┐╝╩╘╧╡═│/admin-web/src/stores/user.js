import { defineStore } from 'pinia'
import { ref } from 'vue'
import request from '../utils/request'

export const useUserStore = defineStore('user', () => {
    const token = ref(localStorage.getItem('token') || '')
    const username = ref(localStorage.getItem('username') || '')

    const login = async (loginForm) => {
        try {
            console.log('Sending login request to:', request.defaults.baseURL);  // 添加这行，检查请求地址
            console.log('Login data:', loginForm);
            const res = await request.post('/auth/login', loginForm)
            console.log('Login response:', res);
            if (res.code === 200) {  // 添加这个判断
                token.value = res.data.token
                username.value = res.data.username
                localStorage.setItem('token', res.data.token)
                localStorage.setItem('username', res.data.username)
                return res
            } else {
                throw new Error(res.message || '登录失败')
            }
        } catch (error) {
            console.error('Login failed:', error.response || error)
            throw error
        }
    }

    const logout = () => {
        token.value = ''
        username.value = ''
        localStorage.removeItem('token')
        localStorage.removeItem('username')
    }

    return {
        token,
        username,
        login,
        logout
    }
}) 