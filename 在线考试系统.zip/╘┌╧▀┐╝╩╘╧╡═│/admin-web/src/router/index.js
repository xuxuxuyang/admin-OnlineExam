import { createRouter, createWebHistory } from 'vue-router'
import LoginView from '../views/LoginView.vue'

// 所有可能的路由配置
const allRoutes = [
  {
    path: '/login',
    name: 'login',
    component: LoginView
  },
  {
    path: '/system',
    name: 'SystemLayout',
    component: () => import('../layouts/Layout.vue'),
    meta: { role: 'admin' },
    children: [
     
      {
        path: 'exam',
        name: 'AdminExam',
        component: () => import('../views/admin/exam/index.vue'),
        meta: { title: '试卷管理', role: 'admin' }
      },
      {
        path: 'paper',
        name: 'AdminPaper',
        component: () => import('../views/admin/paper/index.vue'),
        meta: { title: '组卷管理', role: 'admin' }
      },
      {
        path: 'question',
        name: 'AdminQuestion',
        component: () => import('../views/admin/question/index.vue'),
        meta: { title: '题库管理', role: 'admin' }
      },
      {
        path: 'class-grade',
        name: 'ClassGrade',
        component: () => import('../views/admin/grade/class.vue'),
        meta: { title: '班级成���管理', role: 'admin' }
      },
      {
        path: 'subject-grade',
        name: 'SubjectGrade',
        component: () => import('../views/admin/grade/subject.vue'),
        meta: { title: '学科成绩管理', role: 'admin' }
      },
      {
        path: 'monitor',
        name: 'AdminMonitor',
        component: () => import('../views/admin/monitor/index.vue'),
        meta: { title: '学生监控管理', role: 'admin' }
      },
      {
        path: 'grade-analysis',
        name: 'GradeAnalysis',
        component: () => import('../views/admin/grade/analysis.vue'),
        meta: { title: '年级成绩管理', role: 'admin' }
      },
      {
        path: 'history',
        name: 'AdminHistory',
        component: () => import('../views/admin/history/index.vue'),
        meta: { title: '历史答卷管理', role: 'admin' }
      }
    ]
  },
  {
    path: '/teacher',
    name: 'TeacherLayout',
    component: () => import('../layouts/Layout.vue'),
    meta: { role: 'teacher' },
    children: [
      {
        path: 'exam',
        name: 'ExamManage',
        component: () => import('../views/teacher/exam/index.vue'),
        meta: { title: '试卷管理', role: 'teacher' }
      },
      {
        path: 'marking',
        name: 'PaperMarking',
        component: () => import('../views/teacher/marking/index.vue'),
        meta: { title: '批改试卷', role: 'teacher' }
      },
      {
        path: 'paper',
        name: 'PaperManage',
        component: () => import('../views/teacher/paper/index.vue'),
        meta: { title: '组卷管理', role: 'teacher' }
      },
      {
        path: 'question',
        name: 'QuestionBank',
        component: () => import('../views/teacher/question/index.vue'),
        meta: { title: '题库管理', role: 'teacher' }
      },
      {
        path: 'grade',
        name: 'GradeManage',
        component: () => import('../views/teacher/grade/index.vue'),
        meta: { title: '成绩管理', role: 'teacher' }
      },
      {
        path: 'monitor',
        name: 'StudentMonitor',
        component: () => import('../views/teacher/monitor/index.vue'),
        meta: { title: '学生监控管理', role: 'teacher' }
      },
      {
        path: 'history',
        name: 'AnswerHistory',
        component: () => import('../views/teacher/history/index.vue'),
        meta: { title: '历史答卷管理', role: 'teacher' }
      }
    ]
  },
  {
    path: '/student',
    name: 'StudentLayout',
    component: () => import('../layouts/Layout.vue'),
    meta: { role: 'student' },
    children: [
      {
        path: 'exam',
        name: 'StudentExam',
        component: () => import('../views/student/exam/index.vue'),
        meta: { title: '考试管理', role: 'student' }
      },
      {
        path: 'exam/:id',
        name: 'ExamPage',
        component: () => import('../views/student/exam/ExamPage.vue'),
        meta: { title: '正在考试', role: 'student' }
      },
      {
        path: 'history',
        name: 'ExamHistory',
        component: () => import('../views/student/history/index.vue'),
        meta: { title: '历史考试', role: 'student' }
      },
      {
        path: 'monitor',
        name: 'ExamMonitor',
        component: () => import('../views/student/monitor/index.vue'),
        meta: { title: '考试行为监控', role: 'student' }
      },
      {
        path: 'grade',
        name: 'StudentGrade',
        component: () => import('../views/student/grade/index.vue'),
        meta: { title: '成绩管理', role: 'student' }
      }
    ]
  }
]

// 修改路由过滤函数，让管理员可以访问所有路由
const filterRoutesByRole = (routes, role) => {
  return routes.filter(route => {
    // 管理员可以访问所有路由
    if (role === 'admin') return true;
    if (route.meta && route.meta.role && route.meta.role !== role) {
      return false
    }
    if (route.children) {
      route.children = filterRoutesByRole(route.children, role)
      return route.children.length > 0
    }
    return true
  })
}

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/login',
      name: 'login',
      component: LoginView
    }
  ]
})

// 动态添加路由的函数
export const setupRoutes = (role) => {
  const filteredRoutes = filterRoutesByRole(allRoutes, role)
  filteredRoutes.forEach(route => {
    if (route.name !== 'login') {  // 避免重复添加登录路由
      router.addRoute(route)
    }
  })
}

// 路由守卫
router.beforeEach((to, from, next) => {
  const userRole = localStorage.getItem('userRole')
  if (to.path === '/login') {
    if (userRole) {
      // 已登录用户访问登录页，重定向到对应的首页
      const homePath = getHomePathByRole(userRole)
      next(homePath)
      return
    }
    next()
    return
  }

  if (!userRole) {
    next('/login')
    return
  }

  // 如果路由还没有被添加，添加路由后再跳转
  if (router.getRoutes().length === 1) {  // 只有登录路由时
    setupRoutes(userRole)
    // 如果访问的是根径，重定向到对应角色的首页
    if (to.path === '/') {
      const homePath = getHomePathByRole(userRole)
      next({ path: homePath, replace: true })
      return
    }
    // 否则跳转到目标路由
    next({ ...to, replace: true })
    return
  }

  // 检查用户是否有权限访问该路由
  if (to.meta.role && to.meta.role !== userRole) {
    const homePath = getHomePathByRole(userRole)
    next(homePath)
    return
  }

  // 如果访问根路径，重定向到对应角色的首页
  if (to.path === '/') {
    const homePath = getHomePathByRole(userRole)
    next(homePath)
    return
  }
  next()
})

// 根据角色获取首页路径
const getHomePathByRole = (role) => {
  switch (role) {
    case 'admin':
      return '/system/exam'
    case 'teacher':
      return '/teacher/marking' 
    case 'student':
      return '/student/exam'
    default:
      return '/login'
  }
}

export default router 