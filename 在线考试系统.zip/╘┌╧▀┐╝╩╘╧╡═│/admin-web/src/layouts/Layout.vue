<template>
  <el-container class="layout-container">
    <el-aside width="200px">
      <el-menu :default-active="route.path" class="side-menu" router>
        <!-- 管理员菜单 -->
        <template v-if="userRole === 'admin'">
          <el-menu-item index="/system/exam">
            <el-icon><Document /></el-icon>
            <span>试卷管理</span>
          </el-menu-item>
          <el-menu-item index="/system/paper">
            <el-icon><Edit /></el-icon>
            <span>组卷管理</span>
          </el-menu-item>
          <el-menu-item index="/system/question">
            <el-icon><Collection /></el-icon>
            <span>题库管理</span>
          </el-menu-item>
          <el-sub-menu index="grade">
            <template #title>
              <el-icon><DataLine /></el-icon>
              <span>成绩管理</span>
            </template>
            <el-menu-item index="/system/class-grade"
              >班级成绩管理</el-menu-item
            >
            <el-menu-item index="/system/subject-grade"
              >学科成绩管理</el-menu-item
            >
            <el-menu-item index="/system/grade-analysis"
              >年级成绩管理</el-menu-item
            >
          </el-sub-menu>
          <el-menu-item index="/system/monitor">
            <el-icon><VideoCamera /></el-icon>
            <span>学生监控</span>
          </el-menu-item>
          <el-menu-item index="/system/history">
            <el-icon><List /></el-icon>
            <span>历史答卷</span>
          </el-menu-item>
        </template>

        <!-- 教师菜单 -->
        <template v-if="userRole === 'teacher'">
          <el-menu-item index="/teacher/marking">
            <el-icon><Edit /></el-icon>
            <span>批改试卷</span>
          </el-menu-item>
          <el-menu-item index="/teacher/paper">
            <el-icon><Document /></el-icon>
            <span>组卷管理</span>
          </el-menu-item>
          <el-menu-item index="/teacher/question">
            <el-icon><Collection /></el-icon>
            <span>题库管理</span>
          </el-menu-item>
          <el-menu-item index="/teacher/exam">
            <el-icon><Files /></el-icon>
            <span>试卷管理</span>
          </el-menu-item>
          <el-menu-item index="/teacher/grade">
            <el-icon><DataLine /></el-icon>
            <span>成绩管理</span>
          </el-menu-item>
          <el-menu-item index="/teacher/monitor">
            <el-icon><VideoCamera /></el-icon>
            <span>学生监控</span>
          </el-menu-item>
          <el-menu-item index="/teacher/history">
            <el-icon><List /></el-icon>
            <span>历史答卷</span>
          </el-menu-item>
        </template>

        <!-- 学生菜单 -->
        <template v-if="userRole === 'student'">
          <el-menu-item index="/student/exam">
            <el-icon><Edit /></el-icon>
            <span>考试管理</span>
          </el-menu-item>
          <el-menu-item index="/student/history">
            <el-icon><List /></el-icon>
            <span>历史考试</span>
          </el-menu-item>
          <el-menu-item index="/student/monitor">
            <el-icon><VideoCamera /></el-icon>
            <span>考试行为监控</span>
          </el-menu-item>
          <el-menu-item index="/student/grade">
            <el-icon><Document /></el-icon>
            <span>成绩管理</span>
          </el-menu-item>
        </template>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header>
        <div class="header-left">
          <h2>在线考试系统</h2>
        </div>
        <div class="header-right">
          <el-dropdown @command="handleCommand">
            <span class="user-info">
              {{ userName }}
              <el-icon><CaretBottom /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="logout">退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import {
  HomeFilled,
  Edit,
  List,
  Document,
  VideoCamera,
  CaretBottom,
  Collection,
  Files,
  DataLine,
  Monitor,
} from "@element-plus/icons-vue";
import { ElMessage } from "element-plus";

const route = useRoute();
const router = useRouter();
const userName = ref("");
const userRole = ref("");

onMounted(() => {
  userName.value = localStorage.getItem("userName") || "用户";
  userRole.value = localStorage.getItem("userRole");
});

const handleCommand = (command) => {
  if (command === "logout") {
    localStorage.removeItem("userRole");
    localStorage.removeItem("userName");
    localStorage.removeItem("userMenus");
    router.push("/login");
    ElMessage.success("已退出登录");
  }
};
</script>

<style scoped>
.layout-container {
  height: 100vh;
}

.side-menu {
  height: 100%;
  border-right: none;
}

.el-header {
  background: #fff;
  border-bottom: 1px solid #e6e6e6;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
}

.header-left h2 {
  margin: 0;
  font-size: 18px;
  color: #409eff;
}

.user-info {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #606266;
}

.user-info .el-icon {
  margin-left: 4px;
}

.el-aside {
  background: #fff;
  border-right: 1px solid #e6e6e6;
}

.el-main {
  background: #f5f7fa;
  padding: 20px;
}

.el-menu-item {
  display: flex;
  align-items: center;
}

.el-menu-item .el-icon {
  margin-right: 8px;
}
</style>
