<template>
  <div class="teacher-monitor">
    <el-card>
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <span>学生监控管理</span>
            <el-select v-model="currentExam" placeholder="选择考试" style="width: 300px; margin-left: 16px">
              <el-option
                v-for="item in examList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-select v-model="currentClass" placeholder="选择班级" style="width: 200px; margin-left: 16px">
              <el-option
                v-for="item in classList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
        </div>
      </template>

      <!-- 监控统计卡片 -->
      <el-row :gutter="20" class="statistics-row">
        <el-col :span="6" v-for="card in statisticsCards" :key="card.title">
          <el-card shadow="hover" class="statistics-card">
            <div class="card-content">
              <div class="card-value">{{ card.value }}</div>
              <div class="card-title">{{ card.title }}</div>
            </div>
          </el-card>
        </el-col>
      </el-row>

      <!-- 监控列表 -->
      <el-table :data="monitorList" border stripe>
        <el-table-column prop="studentName" label="学生姓名" width="120" />
        <el-table-column prop="studentId" label="学号" width="120" />
        <el-table-column prop="className" label="班级" width="120" />
        <el-table-column prop="time" label="记录时间" width="180" />
        <el-table-column prop="type" label="行为类型" width="120">
          <template #default="scope">
            <el-tag :type="getBehaviorType(scope.row.type)">
              {{ scope.row.type }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="description" label="行为描述" />
        <el-table-column prop="status" label="处理状态" width="120">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="scope">
            <el-button 
              size="small" 
              type="warning" 
              @click="handleWarn(scope.row)"
              :disabled="scope.row.status !== '未处理'"
            >
              警告
            </el-button>
            <el-button 
              size="small" 
              type="danger" 
              @click="handlePunish(scope.row)"
              :disabled="scope.row.status !== '未处理'"
            >
              处分
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const currentExam = ref('')
const currentClass = ref('')

const examList = [
  { label: '2024年春季高等数学期末考试', value: '1' },
  { label: '2024年春季大学英语四级考试', value: '2' }
]

const classList = [
  { label: '计算机2101', value: '2101' },
  { label: '计算机2102', value: '2102' }
]

const statisticsCards = [
  { title: '在线人数', value: '45' },
  { title: '异常行为', value: '3' },
  { title: '已处理', value: '2' },
  { title: '未处理', value: '1' }
]

const monitorList = ref([
  {
    studentName: '张三',
    studentId: '2021001',
    className: '计算机2101',
    time: '2024-03-20 09:15:30',
    type: '切换窗口',
    description: '切换到浏览器其他标签页',
    status: '未处理'
  },
  {
    studentName: '李四',
    studentId: '2021002',
    className: '计算机2101',
    time: '2024-03-20 09:30:45',
    type: '离开视野',
    description: '摄像头未捕捉到考生面部',
    status: '已警告'
  }
])

const getBehaviorType = (type) => {
  const typeMap = {
    '切换窗口': 'warning',
    '离开视野': 'danger',
    '正常操作': 'success'
  }
  return typeMap[type]
}

const getStatusType = (status) => {
  const typeMap = {
    '未处理': 'info',
    '已警告': 'warning',
    '已处分': 'danger'
  }
  return typeMap[status]
}

const handleWarn = (record) => {
  ElMessageBox.confirm(
    `确定要对学生 ${record.studentName} 发出警告吗？`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  )
  .then(() => {
    console.log('发出警告', record)
    ElMessage.success('已发出警告')
  })
  .catch(() => {
    ElMessage.info('已取消操作')
  })
}

const handlePunish = (record) => {
  ElMessageBox.confirm(
    `确定要对学生 ${record.studentName} 进行处分吗？`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  )
  .then(() => {
    console.log('进行处分', record)
    ElMessage.success('已记录处分')
  })
  .catch(() => {
    ElMessage.info('已取消操作')
  })
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
}

.statistics-row {
  margin-bottom: 20px;
}

.statistics-card {
  text-align: center;
}

.card-value {
  font-size: 24px;
  font-weight: bold;
  color: #1890ff;
}

.card-title {
  margin-top: 8px;
  color: #666;
}
</style> 