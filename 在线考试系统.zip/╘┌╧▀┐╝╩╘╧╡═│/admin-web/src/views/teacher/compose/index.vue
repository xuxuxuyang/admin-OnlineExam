<template>
  <div class="teacher-compose">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>组卷管理</span>
          <el-button type="primary" @click="handleCreate">创建试卷</el-button>
        </div>
      </template>

      <!-- 试卷列表 -->
      <el-table :data="paperList" border stripe>
        <el-table-column prop="name" label="试卷名称" />
        <el-table-column prop="subject" label="科目" width="120" />
        <el-table-column prop="totalScore" label="总分" width="100" />
        <el-table-column prop="questionCount" label="题目数量" width="120" />
        <el-table-column prop="difficulty" label="难度" width="120">
          <template #default="scope">
            <el-rate
              v-model="scope.row.difficulty"
              disabled
              text-color="#ff9900"
            />
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="创建时间" width="180" />
        <el-table-column label="操作" width="250" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handlePreview(scope.row)">预览</el-button>
            <el-button 
              size="small" 
              type="primary" 
              @click="handleEdit(scope.row)"
              :disabled="scope.row.status === '已发布'"
            >
              编辑
            </el-button>
            <el-button 
              size="small" 
              type="success" 
              @click="handlePublish(scope.row)"
              :disabled="scope.row.status === '已发布'"
            >
              发布
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 创建/编辑试卷对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogType === 'create' ? '创建试卷' : '编辑试卷'"
      width="800px"
    >
      <el-form
        ref="paperFormRef"
        :model="paperForm"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="试卷名称" prop="name">
          <el-input v-model="paperForm.name" placeholder="请输入试卷名称" />
        </el-form-item>
        <el-form-item label="科目" prop="subject">
          <el-select v-model="paperForm.subject" placeholder="请选择科目" style="width: 100%">
            <el-option label="高等数学" value="高等数学" />
            <el-option label="大学英语" value="大学英语" />
            <el-option label="计算机基础" value="计算机基础" />
          </el-select>
        </el-form-item>
        <el-form-item label="总分" prop="totalScore">
          <el-input-number v-model="paperForm.totalScore" :min="1" :max="150" />
        </el-form-item>
        <el-form-item label="难度" prop="difficulty">
          <el-rate v-model="paperForm.difficulty" />
        </el-form-item>
        
        <!-- 题目配置 -->
        <el-divider>题目配置</el-divider>
        <div class="question-config" v-for="type in questionTypes" :key="type.value">
          <div class="config-header">
            <span class="type-label">{{ type.label }}</span>
            <div class="config-controls">
              <span class="count-label">数量：</span>
              <el-input-number 
                v-model="paperForm.questionConfig[type.value].count" 
                :min="0" 
                :max="50"
                size="small"
              />
              <span class="score-label">单题分值：</span>
              <el-input-number 
                v-model="paperForm.questionConfig[type.value].score" 
                :min="0" 
                :max="100"
                size="small"
              />
            </div>
          </div>
          <div class="question-pool">
            <el-table
              :data="getQuestionPool(type.value)"
              border
              stripe
              height="200"
              @selection-change="(val) => handleSelectionChange(type.value, val)"
            >
              <el-table-column type="selection" width="55" />
              <el-table-column prop="content" label="题目内容" show-overflow-tooltip />
              <el-table-column prop="difficulty" label="难度" width="120">
                <template #default="scope">
                  <el-rate v-model="scope.row.difficulty" disabled />
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="handleSubmit" :loading="loading">
            确定
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const dialogVisible = ref(false)
const dialogType = ref('create')
const loading = ref(false)
const paperFormRef = ref(null)

const questionTypes = [
  { label: '单选题', value: 'single' },
  { label: '多选题', value: 'multiple' },
  { label: '判断题', value: 'judge' },
  { label: '简答题', value: 'essay' }
]

const paperForm = ref({
  name: '',
  subject: '',
  totalScore: 100,
  difficulty: 3,
  questionConfig: {
    single: { count: 10, score: 3 },
    multiple: { count: 5, score: 4 },
    judge: { count: 10, score: 2 },
    essay: { count: 2, score: 10 }
  },
  selectedQuestions: {
    single: [],
    multiple: [],
    judge: [],
    essay: []
  }
})

const rules = {
  name: [
    { required: true, message: '请输入试卷名称', trigger: 'blur' },
    { min: 3, max: 50, message: '长度在 3 到 50 个字符', trigger: 'blur' }
  ],
  subject: [
    { required: true, message: '请选择科目', trigger: 'change' }
  ],
  totalScore: [
    { required: true, message: '请设��总分', trigger: 'change' }
  ]
}

const paperList = ref([
  {
    name: '2024春季高等数学期末试卷A',
    subject: '高等数学',
    totalScore: 100,
    questionCount: 25,
    difficulty: 3,
    status: '草稿',
    createTime: '2024-01-15 10:00:00'
  },
  {
    name: '2024春季大学英语四级模拟试卷',
    subject: '大学英语',
    totalScore: 100,
    questionCount: 30,
    difficulty: 4,
    status: '已发布',
    createTime: '2024-01-16 14:30:00'
  }
])

const getStatusType = (status) => {
  const typeMap = {
    '草稿': 'info',
    '已发布': 'success'
  }
  return typeMap[status]
}

// 模拟题库数据
const getQuestionPool = (type) => {
  return Array(20).fill(null).map((_, index) => ({
    id: `${type}_${index}`,
    content: `这是一道${type}类型的题目${index + 1}`,
    difficulty: Math.ceil(Math.random() * 5)
  }))
}

const handleSelectionChange = (type, val) => {
  paperForm.value.selectedQuestions[type] = val
}

const handleCreate = () => {
  dialogType.value = 'create'
  paperForm.value = {
    name: '',
    subject: '',
    totalScore: 100,
    difficulty: 3,
    questionConfig: {
      single: { count: 10, score: 3 },
      multiple: { count: 5, score: 4 },
      judge: { count: 10, score: 2 },
      essay: { count: 2, score: 10 }
    },
    selectedQuestions: {
      single: [],
      multiple: [],
      judge: [],
      essay: []
    }
  }
  dialogVisible.value = true
}

const handlePreview = (paper) => {
  console.log('预览试卷', paper)
}

const handleEdit = (paper) => {
  dialogType.value = 'edit'
  // TODO: 加载试卷详细信息
  paperForm.value = { ...paper }
  dialogVisible.value = true
}

const handlePublish = (paper) => {
  ElMessageBox.confirm(
    `确定要发布试卷 ${paper.name} 吗？发布后将不能修改`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    }
  )
  .then(() => {
    console.log('发布试卷', paper)
    ElMessage.success('发布成功')
  })
  .catch(() => {
    ElMessage.info('已取消发布')
  })
}

const handleSubmit = async () => {
  if (!paperFormRef.value) return
  
  await paperFormRef.value.validate(async (valid, fields) => {
    if (valid) {
      loading.value = true
      try {
        // 模拟API调用
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        if (dialogType.value === 'create') {
          console.log('创建试卷', paperForm.value)
          ElMessage.success('创建试卷成功')
        } else {
          console.log('编辑试卷', paperForm.value)
          ElMessage.success('编辑试卷成功')
        }
        dialogVisible.value = false
      } catch (error) {
        console.error('操作失败:', error)
      } finally {
        loading.value = false
      }
    }
  })
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.question-config {
  margin-bottom: 20px;
}

.config-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.type-label {
  font-weight: bold;
}

.config-controls {
  display: flex;
  align-items: center;
  gap: 16px;
}

.count-label,
.score-label {
  margin-right: 8px;
}

.question-pool {
  margin-top: 10px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
</style> 