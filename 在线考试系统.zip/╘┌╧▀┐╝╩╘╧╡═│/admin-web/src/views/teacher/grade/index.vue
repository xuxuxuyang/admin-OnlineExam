<template>
  <div class="grade-management">
    <!-- 统计卡片 -->
    <el-row :gutter="20" class="statistics-cards">
      <el-col :span="6" v-for="stat in statistics" :key="stat.title">
        <el-card shadow="hover" :body-style="{ padding: '20px' }">
          <div class="stat-card">
            <div class="stat-icon" :style="{ backgroundColor: stat.color }">
              <el-icon><component :is="stat.icon" /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-title">{{ stat.title }}</div>
              <div class="stat-value">{{ stat.value }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 筛选栏 -->
    <div class="filter-section">
      <el-form :inline="true" :model="filters" class="filter-form">
        <el-form-item label="班级">
          <el-select v-model="filters.class" placeholder="选择班级">
            <el-option
              v-for="item in classOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="考试">
          <el-select v-model="filters.exam" placeholder="选择考试">
            <el-option
              v-for="item in examOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch">
            <el-icon><Search /></el-icon>查询
          </el-button>
          <el-button @click="handleExport">
            <el-icon><Download /></el-icon>导出成绩
          </el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 成绩图表 -->
    <el-row :gutter="20" class="chart-section">
      <el-col :span="12">
        <el-card class="chart-card">
          <template #header>
            <div class="card-header">
              <span>成绩分布</span>
            </div>
          </template>
          <div class="chart" ref="distributionChart"></div>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card class="chart-card">
          <template #header>
            <div class="card-header">
              <span>平均分趋势</span>
            </div>
          </template>
          <div class="chart" ref="trendChart"></div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 成绩列表 -->
    <el-card class="grade-table">
      <el-table :data="gradeList" border stripe>
        <el-table-column prop="studentId" label="学号" width="100" />
        <el-table-column prop="name" label="姓名" width="120" />
        <el-table-column prop="class" label="班级" width="120" />
        <el-table-column prop="exam" label="考试" width="180" />
        <el-table-column prop="score" label="分数" width="100">
          <template #default="{ row }">
            <span :class="getScoreClass(row.score)">{{ row.score }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="rank" label="排名" width="100" />
        <el-table-column label="得分率" width="180">
          <template #default="{ row }">
            <el-progress
              :percentage="(row.score / row.totalScore) * 100"
              :status="getProgressStatus(row.score / row.totalScore)"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="150" fixed="right">
          <template #default="{ row }">
            <el-button-group>
              <el-button type="primary" link @click="handleDetail(row)">
                详情
              </el-button>
              <el-button type="primary" link @click="handleEdit(row)">
                修改
              </el-button>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          :current-page="currentPage"
          :page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          @update:current-page="(val) => (currentPage = val)"
          @update:page-size="(val) => (pageSize = val)"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import {
  Search,
  Download,
  DataLine,
  Medal,
  User,
  Histogram,
} from "@element-plus/icons-vue";
import * as echarts from "echarts";

// 统计数据
const statistics = [
  {
    title: "参考人数",
    value: "126",
    icon: "User",
    color: "#409EFF",
  },
  {
    title: "平均分",
    value: "85.6",
    icon: "DataLine",
    color: "#67C23A",
  },
  {
    title: "最高分",
    value: "98",
    icon: "Medal",
    color: "#E6A23C",
  },
  {
    title: "及格率",
    value: "95.2%",
    icon: "Histogram",
    color: "#F56C6C",
  },
];

// 筛选条件
const filters = reactive({
  class: "",
  exam: "",
});

// 选项数据
const classOptions = [
  { value: "1", label: "高一(1)班" },
  { value: "2", label: "高一(2)班" },
  { value: "3", label: "高一(3)班" },
];

const examOptions = [
  { value: "1", label: "2024期中考试" },
  { value: "2", label: "2024月考(2月)" },
  { value: "3", label: "2024单元测试(1)" },
];

// 成绩列表数据
const gradeList = ref([
  {
    studentId: "20240101",
    name: "张三",
    class: "高一(1)班",
    exam: "2024期中考试",
    score: 92,
    totalScore: 100,
    rank: 1,
  },
  // 更多数据...
]);

// 分页相关
const currentPage = ref(1);
const pageSize = ref(10);
const total = ref(100);

// 图表引用
const distributionChart = ref(null);
const trendChart = ref(null);

// 初始化图表
onMounted(() => {
  initDistributionChart();
  initTrendChart();
});

// 初始化成绩分布图表
const initDistributionChart = () => {
  const chart = echarts.init(distributionChart.value);
  const option = {
    title: {
      text: "成绩分布",
      left: "center",
    },
    tooltip: {
      trigger: "axis",
    },
    xAxis: {
      type: "category",
      data: ["<60", "60-70", "70-80", "80-90", "90-100"],
    },
    yAxis: {
      type: "value",
    },
    series: [
      {
        data: [5, 15, 30, 45, 25],
        type: "bar",
        barWidth: "30%",
        itemStyle: {
          color: "#409EFF",
        },
      },
    ],
  };
  chart.setOption(option);
};

// 初始化平均分趋势图表
const initTrendChart = () => {
  const chart = echarts.init(trendChart.value);
  const option = {
    title: {
      text: "平均分趋势",
      left: "center",
    },
    tooltip: {
      trigger: "axis",
    },
    xAxis: {
      type: "category",
      data: ["第一次", "第二次", "第三次", "第四次", "第五次"],
    },
    yAxis: {
      type: "value",
    },
    series: [
      {
        data: [82, 85, 83, 86, 85.6],
        type: "line",
        smooth: true,
        itemStyle: {
          color: "#67C23A",
        },
      },
    ],
  };
  chart.setOption(option);
};

// 处理函数
const handleSearch = () => {
  // 实现查询逻辑
};

const handleExport = () => {
  // 实现导出逻辑
};

const handleDetail = (row) => {
  // 实现查看详情逻辑
};

const handleEdit = (row) => {
  // 实现编辑逻辑
};

const handleSizeChange = (val) => {
  pageSize.value = val;
  // 重新加载数据
};

const handleCurrentChange = (val) => {
  currentPage.value = val;
  // 重新加载数据
};

// 工具函数
const getScoreClass = (score) => {
  if (score >= 90) return "score-excellent";
  if (score >= 80) return "score-good";
  if (score >= 60) return "score-pass";
  return "score-fail";
};

const getProgressStatus = (rate) => {
  if (rate >= 0.9) return "success";
  if (rate >= 0.6) return "";
  return "exception";
};
</script>

<style scoped>
.grade-management {
  padding: 20px;
}

.statistics-cards {
  margin-bottom: 20px;
}

.stat-card {
  display: flex;
  align-items: center;
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
}

.stat-icon :deep(.el-icon) {
  font-size: 24px;
  color: #fff;
}

.stat-info {
  flex: 1;
}

.stat-title {
  font-size: 14px;
  color: #909399;
  margin-bottom: 4px;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
}

.filter-section {
  margin-bottom: 20px;
  padding: 20px;
  background-color: #fff;
  border-radius: 4px;
}

.filter-form {
  display: flex;
  align-items: center;
  gap: 20px;
}

/* 修改表单项样式 */
:deep(.el-form-item) {
  margin-bottom: 0;
  margin-right: 0;
}

/* 增加下拉框宽度 */
:deep(.el-select) {
  width: 240px;
}

/* 调整标签样式 */
:deep(.el-form-item__label) {
  font-weight: 500;
  padding-right: 12px;
}

/* 按钮组样式 */
:deep(.el-form-item:last-child) {
  margin-left: auto;
}

:deep(.el-button) {
  padding: 8px 20px;
}

:deep(.el-button .el-icon) {
  margin-right: 4px;
}

.chart-section {
  margin-bottom: 20px;
}

.chart-card {
  margin-bottom: 20px;
}

.chart {
  height: 300px;
}

.grade-table {
  margin-bottom: 20px;
}

.score-excellent {
  color: #67c23a;
  font-weight: bold;
}

.score-good {
  color: #409eff;
  font-weight: bold;
}

.score-pass {
  color: #e6a23c;
}

.score-fail {
  color: #f56c6c;
  font-weight: bold;
}

.pagination-container {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
}

:deep(.el-card__header) {
  padding: 12px 20px;
  border-bottom: 1px solid #ebeef5;
}

:deep(.el-button-group .el-button) {
  padding: 4px 8px;
}
</style>
