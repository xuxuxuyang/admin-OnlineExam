<template>
  <div class="teacher-exam">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>考试管理</span>
          <el-button type="primary" @click="handleAdd">创建考试</el-button>
        </div>
      </template>

      <el-table :data="examList" border stripe>
        <el-table-column prop="name" label="考试名称" />
        <el-table-column prop="subject" label="科目" width="120" />
        <el-table-column prop="startTime" label="开始时间" width="180" />
        <el-table-column prop="duration" label="考试时长" width="100">
          <template #default="scope"> {{ scope.row.duration }}分钟 </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="participantCount" label="参考人数" width="100" />
        <el-table-column label="操作" width="250" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleView(scope.row)"
              >查看</el-button
            >
            <el-button
              size="small"
              type="primary"
              @click="handleEdit(scope.row)"
              :disabled="scope.row.status !== '未开始'"
            >
              编辑
            </el-button>
            <el-button
              size="small"
              type="danger"
              @click="handleDelete(scope.row)"
              :disabled="scope.row.status !== '未开始'"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 创建/编辑考试对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogType === 'add' ? '创建考试' : '编辑考试'"
      width="600px"
    >
      <el-form
        ref="examFormRef"
        :model="examForm"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="考试名称" prop="name">
          <el-input v-model="examForm.name" placeholder="请输入考试名称" />
        </el-form-item>
        <el-form-item label="科目" prop="subject">
          <el-select
            v-model="examForm.subject"
            placeholder="请选择科目"
            style="width: 100%"
          >
            <el-option label="高等数学" value="高等数学" />
            <el-option label="大学英语" value="大学英语" />
            <el-option label="计算机基础" value="计算机基础" />
          </el-select>
        </el-form-item>
        <el-form-item label="试卷" prop="paperId">
          <el-select
            v-model="examForm.paperId"
            placeholder="请选择试卷"
            style="width: 100%"
          >
            <el-option
              v-for="paper in paperList"
              :key="paper.id"
              :label="paper.name"
              :value="paper.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="开始时间" prop="startTime">
          <el-date-picker
            v-model="examForm.startTime"
            type="datetime"
            placeholder="请选择开始时间"
            style="width: 100%"
          />
        </el-form-item>
        <el-form-item label="考试时长" prop="duration">
          <el-input-number
            v-model="examForm.duration"
            :min="30"
            :max="180"
            :step="30"
          />
          <span class="unit">分钟</span>
        </el-form-item>
        <el-form-item label="参考班级" prop="classes">
          <el-select
            v-model="examForm.classes"
            multiple
            placeholder="请选择参考班级"
            style="width: 100%"
          >
            <el-option label="计算机2101" value="计算机2101" />
            <el-option label="计算机2102" value="计算机2102" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="handleSubmit" :loading="loading">
            确定
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";

const dialogVisible = ref(false);
const dialogType = ref("add");
const loading = ref(false);
const examFormRef = ref(null);

const examForm = ref({
  name: "",
  subject: "",
  paperId: "",
  startTime: "",
  duration: 120,
  classes: [],
});

const rules = {
  name: [
    { required: true, message: "请输入考试名称", trigger: "blur" },
    { min: 3, max: 50, message: "长度在 3 到 50 个字符", trigger: "blur" },
  ],
  subject: [{ required: true, message: "请选择科目", trigger: "change" }],
  paperId: [{ required: true, message: "请选择试卷", trigger: "change" }],
  startTime: [{ required: true, message: "请选择开始时间", trigger: "change" }],
  duration: [{ required: true, message: "请设置考试时长", trigger: "change" }],
  classes: [{ required: true, message: "请选择参考班级", trigger: "change" }],
};

const examList = ref([
  {
    id: 1,
    name: "2024年春季高等数学期末考试",
    subject: "高等数学",
    startTime: "2024-03-20 09:00:00",
    duration: 120,
    status: "未开始",
    participantCount: 87,
  },
  {
    id: 2,
    name: "2024年春季大学英语四级考试",
    subject: "大学英语",
    startTime: "2024-03-15 14:00:00",
    duration: 90,
    status: "进行中",
    participantCount: 92,
  },
]);

const paperList = ref([
  { id: 1, name: "高等数学期末试卷A" },
  { id: 2, name: "高等数学期末试卷B" },
  { id: 3, name: "大学英语四级模拟试卷" },
]);

const getStatusType = (status) => {
  const typeMap = {
    未开始: "info",
    进行中: "success",
    已结束: "danger",
  };
  return typeMap[status];
};

const handleAdd = () => {
  dialogType.value = "add";
  examForm.value = {
    name: "",
    subject: "",
    paperId: "",
    startTime: "",
    duration: 120,
    classes: [],
  };
  dialogVisible.value = true;
};

const handleView = (exam) => {
  console.log("查看考试", exam);
};

const handleEdit = (exam) => {
  dialogType.value = "edit";
  examForm.value = {
    id: exam.id,
    name: exam.name,
    subject: exam.subject,
    paperId: exam.paperId,
    startTime: exam.startTime,
    duration: exam.duration,
    classes: exam.classes || [],
  };
  dialogVisible.value = true;
};

const handleDelete = (exam) => {
  ElMessageBox.confirm(`确定要删除考试 ${exam.name} 吗？`, "警告", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  })
    .then(async () => {
      console.log("删除考试", exam);
      ElMessage.success("删除成功");
    })
    .catch(() => {
      ElMessage.info("已取消删除");
    });
};

const handleSubmit = async () => {
  if (!examFormRef.value) return;

  await examFormRef.value.validate(async (valid, fields) => {
    if (valid) {
      loading.value = true;
      try {
        // 模拟API调用
        await new Promise((resolve) => setTimeout(resolve, 1000));

        if (dialogType.value === "add") {
          console.log("创建考试", examForm.value);
          ElMessage.success("创建考试成功");
        } else {
          console.log("编辑考试", examForm.value);
          ElMessage.success("编辑考试成功");
        }
        dialogVisible.value = false;
      } catch (error) {
        console.error("操作失败:", error);
      } finally {
        loading.value = false;
      }
    }
  });
};
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.unit {
  margin-left: 10px;
  color: #666;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
</style>
