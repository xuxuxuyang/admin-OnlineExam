<template>
  <div class="paper-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>组卷管理</span>
          <el-button type="primary" @click="handleCreatePaper">新建试卷</el-button>
        </div>
      </template>
      <div class="paper-content">
        <el-table :data="paperList" style="width: 100%">
          <el-table-column prop="name" label="试卷名称" />
          <el-table-column prop="subject" label="科目" />
          <el-table-column prop="totalScore" label="总分" width="100" />
          <el-table-column prop="duration" label="考试时长" width="100" />
          <el-table-column prop="createTime" label="创建时间" width="180" />
          <el-table-column prop="status" label="状态" width="100">
            <template #default="{ row }">
              <el-tag :type="row.status === '已发布' ? 'success' : 'info'">
                {{ row.status }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="250">
            <template #default="{ row }">
              <el-button type="primary" size="small" :disabled="row.status === '已发布'">
                编辑
              </el-button>
              <el-button type="success" size="small" :disabled="row.status === '已发布'">
                发布
              </el-button>
              <el-button type="info" size="small">预览</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const paperList = ref([
  {
    name: '2024春季高等数学期中考试',
    subject: '高等数学',
    totalScore: 100,
    duration: '120分钟',
    createTime: '2024-03-15 14:30',
    status: '草稿'
  },
  {
    name: '2024春季大学英语期中考试',
    subject: '大学英语',
    totalScore: 100,
    duration: '90分钟',
    createTime: '2024-03-16 09:30',
    status: '已发布'
  }
])

const handleCreatePaper = () => {
  // TODO: 实现新建试卷功能
  console.log('新建试卷')
}
</script>

<style scoped>
.paper-container {
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.paper-content {
  margin-top: 20px;
}
</style> 