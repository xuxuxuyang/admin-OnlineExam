<template>
  <div class="marking-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>批改试卷</span>
          <el-select v-model="currentExam" placeholder="选择考试" style="width: 200px">
            <el-option
              v-for="item in examList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </div>
      </template>
      <div class="marking-content">
        <el-table :data="paperList" style="width: 100%">
          <el-table-column prop="studentName" label="学生姓名" />
          <el-table-column prop="className" label="班级" />
          <el-table-column prop="submitTime" label="提交时间" />
          <el-table-column prop="status" label="状态">
            <template #default="{ row }">
              <el-tag :type="row.status === '待批改' ? 'warning' : 'success'">
                {{ row.status }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作">
            <template #default="{ row }">
              <el-button 
                type="primary" 
                size="small"
                :disabled="row.status !== '待批改'"
              >
                批改
              </el-button>
              <el-button type="info" size="small">查看</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const currentExam = ref('')
const examList = [
  { label: '2024春季高等数学期中考试', value: '1' },
  { label: '2024春季大学英语期中考试', value: '2' }
]

const paperList = ref([
  {
    studentName: '张三',
    className: '计算机2101',
    submitTime: '2024-03-20 10:30',
    status: '待批改'
  },
  {
    studentName: '李四',
    className: '计算机2101',
    submitTime: '2024-03-20 10:25',
    status: '已批改'
  }
])
</script>

<style scoped>
.marking-container {
  padding: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.marking-content {
  margin-top: 20px;
}
</style> 