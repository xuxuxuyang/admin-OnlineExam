<template>
  <div class="question-bank">
    <el-card class="header-card">
      <div class="statistics">
        <div class="stat-item" v-for="stat in statistics" :key="stat.title">
          <div class="stat-icon" :style="{ backgroundColor: stat.color }">
            <el-icon><component :is="stat.icon" /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stat.value }}</div>
            <div class="stat-title">{{ stat.title }}</div>
          </div>
        </div>
      </div>
    </el-card>

    <!-- 操作栏 -->
    <el-card class="operation-card">
      <div class="operation-bar">
        <div class="left-actions">
          <el-button type="primary" @click="handleAddQuestion">
            <el-icon><Plus /></el-icon>新增题目
          </el-button>
          <el-button type="success" @click="handleImportQuestions">
            <el-icon><Upload /></el-icon>批量导入
          </el-button>
          <el-button
            type="danger"
            :disabled="!selectedQuestions.length"
            @click="handleBatchDelete"
          >
            <el-icon><Delete /></el-icon>批量删除
          </el-button>
        </div>
        <div class="right-filters">
          <el-select
            v-model="filters.subject"
            placeholder="选择科目"
            class="filter-item"
            clearable
          >
            <el-option
              v-for="item in subjectOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-select
            v-model="filters.type"
            placeholder="题目类型"
            class="filter-item"
            clearable
          >
            <el-option
              v-for="item in questionTypes"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-select
            v-model="filters.difficulty"
            placeholder="难度等级"
            class="filter-item"
            clearable
          >
            <el-option
              v-for="item in difficultyOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-input
            v-model="filters.keyword"
            placeholder="搜索题目关键词"
            class="filter-item"
            clearable
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
        </div>
      </div>
    </el-card>

    <!-- 题目列表 -->
    <el-card class="table-card">
      <el-table
        :data="questionList"
        border
        stripe
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="id" label="题目ID" width="80" align="center" />
        <el-table-column prop="title" label="题目内容" min-width="400">
          <template #default="{ row }">
            <div class="question-content">
              <div class="question-title" v-html="row.title"></div>
              <div class="question-preview" v-if="row.preview">
                {{ row.preview }}
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="type" label="类型" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getQuestionTypeTag(row.type)" effect="plain">
              {{ row.type }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column
          prop="subject"
          label="科目"
          width="120"
          align="center"
        />
        <el-table-column
          prop="difficulty"
          label="难度"
          width="120"
          align="center"
        >
          <template #default="{ row }">
            <el-rate
              v-model="row.difficulty"
              disabled
              show-score
              text-color="#ff9900"
            />
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right" align="center">
          <template #default="{ row }">
            <el-button-group>
              <el-tooltip content="编辑题目" placement="top">
                <el-button type="primary" link @click="handleEdit(row)">
                  <el-icon><Edit /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="预览题目" placement="top">
                <el-button type="primary" link @click="handlePreview(row)">
                  <el-icon><View /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="删除题目" placement="top">
                <el-button type="danger" link @click="handleDelete(row)">
                  <el-icon><Delete /></el-icon>
                </el-button>
              </el-tooltip>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          :current-page="currentPage"
          :page-size="pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          @update:current-page="(val) => (currentPage = val)"
          @update:page-size="(val) => (pageSize = val)"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive } from "vue";
import {
  Plus,
  Upload,
  Search,
  Edit,
  View,
  Delete,
  Document,
  Collection,
  Star,
} from "@element-plus/icons-vue";
import { ElMessage, ElMessageBox } from "element-plus";

// 统计数据
const statistics = [
  {
    title: "题目总数",
    value: "1,234",
    icon: "Document",
    color: "#409EFF",
  },
  {
    title: "题库数量",
    value: "12",
    icon: "Collection",
    color: "#67C23A",
  },
  {
    title: "今日新增",
    value: "25",
    icon: "Plus",
    color: "#E6A23C",
  },
  {
    title: "收藏题目",
    value: "89",
    icon: "Star",
    color: "#F56C6C",
  },
];

// 筛选条件
const filters = reactive({
  subject: "",
  type: "",
  difficulty: "",
  keyword: "",
});

// 选中的题目
const selectedQuestions = ref([]);

// 选项数据
const subjectOptions = [
  { value: "1", label: "语文" },
  { value: "2", label: "数学" },
  { value: "3", label: "英语" },
];

const questionTypes = [
  { value: "1", label: "单选题" },
  { value: "2", label: "多选题" },
  { value: "3", label: "判断题" },
  { value: "4", label: "填空题" },
  { value: "5", label: "简答题" },
];

const difficultyOptions = [
  { value: 1, label: "简单" },
  { value: 2, label: "中等" },
  { value: 3, label: "困难" },
];

// 处理函数
const handleSelectionChange = (selection) => {
  selectedQuestions.value = selection;
};

const handleBatchDelete = () => {
  if (!selectedQuestions.value.length) return;

  ElMessageBox.confirm(
    `确定要删除选中的 ${selectedQuestions.value.length} 道题目吗？`,
    "警告",
    {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    }
  ).then(() => {
    ElMessage.success("删除成功");
  });
};

// ... 其他原有的处理函数保持不变 ...
</script>

<style scoped>
.question-bank {
  padding: 20px;
}

.header-card {
  margin-bottom: 20px;
}

.statistics {
  display: flex;
  justify-content: space-between;
  gap: 20px;
}

.stat-item {
  flex: 1;
  display: flex;
  align-items: center;
  padding: 20px;
  background-color: #f8f9fa;
  border-radius: 8px;
  transition: all 0.3s;
}

.stat-item:hover {
  transform: translateY(-2px);
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
}

.stat-icon :deep(.el-icon) {
  font-size: 24px;
  color: #fff;
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-title {
  font-size: 14px;
  color: #909399;
  margin-top: 4px;
}

.operation-card {
  margin-bottom: 20px;
}

.operation-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 20px;
}

.left-actions {
  display: flex;
  gap: 12px;
}

.right-filters {
  display: flex;
  gap: 12px;
  flex: 1;
  justify-content: flex-end;
}

.filter-item {
  width: 200px;
}

.table-card {
  margin-bottom: 20px;
}

.question-content {
  padding: 8px 0;
}

.question-title {
  line-height: 1.5;
  color: #303133;
}

.question-preview {
  margin-top: 8px;
  font-size: 13px;
  color: #909399;
  line-height: 1.4;
}

.pagination-container {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #ebeef5;
}

:deep(.el-card) {
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.05);
}

:deep(.el-button-group .el-button) {
  padding: 6px;
}

:deep(.el-tag) {
  text-align: center;
  min-width: 60px;
}

:deep(.el-table) {
  border-radius: 4px;
  overflow: hidden;
}
</style>
