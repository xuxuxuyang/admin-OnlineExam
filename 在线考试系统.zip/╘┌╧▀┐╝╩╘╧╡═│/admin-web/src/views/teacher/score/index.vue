<template>
  <div class="teacher-score">
    <el-card>
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <span>成绩管理</span>
            <el-select v-model="currentExam" placeholder="选择考试" style="width: 300px; margin-left: 16px">
              <el-option
                v-for="item in examList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-select v-model="currentClass" placeholder="选择班级" style="width: 200px; margin-left: 16px">
              <el-option
                v-for="item in classList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
          <el-button type="primary" @click="handleExport">导出成绩</el-button>
        </div>
      </template>

      <!-- 成绩统计卡片 -->
      <el-row :gutter="20" class="statistics-row">
        <el-col :span="6" v-for="card in statisticsCards" :key="card.title">
          <el-card shadow="hover" class="statistics-card">
            <div class="card-content">
              <div class="card-value">{{ card.value }}</div>
              <div class="card-title">{{ card.title }}</div>
            </div>
          </el-card>
        </el-col>
      </el-row>

      <!-- 成绩分布图表 -->
      <el-row :gutter="20" class="chart-row">
        <el-col :span="12">
          <el-card>
            <template #header>
              <div class="chart-header">成绩分布</div>
            </template>
            <div ref="scoreDistributionRef" style="height: 300px"></div>
          </el-card>
        </el-col>
        <el-col :span="12">
          <el-card>
            <template #header>
              <div class="chart-header">及格率趋势</div>
            </template>
            <div ref="passRateRef" style="height: 300px"></div>
          </el-card>
        </el-col>
      </el-row>

      <!-- 成绩列表 -->
      <el-table :data="scoreList" border stripe class="score-table">
        <el-table-column prop="studentName" label="学生姓名" width="120" />
        <el-table-column prop="studentId" label="学号" width="120" />
        <el-table-column prop="className" label="班级" width="120" />
        <el-table-column prop="score" label="得分" width="100" sortable>
          <template #default="scope">
            <span :class="getScoreClass(scope.row.score)">{{ scope.row.score }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="classRank" label="班级排名" width="100" sortable />
        <el-table-column prop="gradeRank" label="年级排名" width="100" sortable />
        <el-table-column prop="submitTime" label="提交时间" width="180" />
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleDetail(scope.row)">查看详情</el-button>
            <el-button size="small" type="primary" @click="handleAnalysis(scope.row)">成绩分析</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import * as echarts from 'echarts'

const currentExam = ref('')
const currentClass = ref('')

const examList = [
  { label: '2024年春季高等数学期末考试', value: '1' },
  { label: '2024年春季大学英语四级考试', value: '2' }
]

const classList = [
  { label: '计算机2101', value: '2101' },
  { label: '���算机2102', value: '2102' }
]

const statisticsCards = [
  { title: '平均分', value: '82.5' },
  { title: '最高分', value: '98' },
  { title: '最低分', value: '65' },
  { title: '及格率', value: '92.3%' }
]

const scoreList = ref([
  {
    studentName: '张三',
    studentId: '2021001',
    className: '计算机2101',
    score: 85,
    classRank: 15,
    gradeRank: 45,
    submitTime: '2024-03-20 10:30:00'
  },
  {
    studentName: '李四',
    studentId: '2021002',
    className: '计算机2101',
    score: 92,
    classRank: 5,
    gradeRank: 12,
    submitTime: '2024-03-20 10:25:00'
  }
])

const scoreDistributionRef = ref(null)
const passRateRef = ref(null)

onMounted(() => {
  // 初始化成绩分布图表
  const scoreDistribution = echarts.init(scoreDistributionRef.value)
  scoreDistribution.setOption({
    title: { text: '成绩分布' },
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: ['<60', '60-70', '70-80', '80-90', '90-100']
    },
    yAxis: { type: 'value' },
    series: [{
      data: [5, 15, 30, 35, 15],
      type: 'bar'
    }]
  })

  // 初始化及格率趋势图表
  const passRate = echarts.init(passRateRef.value)
  passRate.setOption({
    title: { text: '及格率趋势' },
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: ['第一次', '第二次', '第三次', '第四次', '第五次']
    },
    yAxis: { type: 'value' },
    series: [{
      data: [85, 88, 92, 90, 94],
      type: 'line',
      smooth: true
    }]
  })

  // 监听窗口大小变化
  window.addEventListener('resize', () => {
    scoreDistribution.resize()
    passRate.resize()
  })
})

const getScoreClass = (score) => {
  if (score >= 90) return 'score-excellent'
  if (score >= 80) return 'score-good'
  if (score >= 60) return 'score-pass'
  return 'score-fail'
}

const handleExport = () => {
  console.log('导出成绩')
}

const handleDetail = (score) => {
  console.log('查看成绩详情', score)
}

const handleAnalysis = (score) => {
  console.log('成绩分析', score)
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
}

.statistics-row {
  margin-bottom: 20px;
}

.statistics-card {
  text-align: center;
}

.card-value {
  font-size: 24px;
  font-weight: bold;
  color: #1890ff;
}

.card-title {
  margin-top: 8px;
  color: #666;
}

.chart-row {
  margin-bottom: 20px;
}

.chart-header {
  font-weight: bold;
}

.score-table {
  margin-top: 20px;
}

.score-excellent {
  color: #67c23a;
  font-weight: bold;
}

.score-good {
  color: #409eff;
  font-weight: bold;
}

.score-pass {
  color: #e6a23c;
  font-weight: bold;
}

.score-fail {
  color: #f56c6c;
  font-weight: bold;
}
</style> 