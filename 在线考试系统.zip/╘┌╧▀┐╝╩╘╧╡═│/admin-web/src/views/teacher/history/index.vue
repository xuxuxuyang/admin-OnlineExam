<template>
  <div class="teacher-history">
    <el-card>
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <span>历史答卷管理</span>
            <el-select
              v-model="currentExam"
              placeholder="选择考试"
              style="width: 300px; margin-left: 16px"
            >
              <el-option
                v-for="item in examList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-select
              v-model="currentClass"
              placeholder="选择班级"
              style="width: 200px; margin-left: 16px"
            >
              <el-option
                v-for="item in classList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
          <el-button type="primary" @click="handleExport">导出答卷</el-button>
        </div>
      </template>

      <!-- 答卷列表 -->
      <el-table :data="paperList" border stripe>
        <el-table-column prop="studentName" label="学生姓名" width="120" />
        <el-table-column prop="studentId" label="学号" width="120" />
        <el-table-column prop="className" label="班级" width="120" />
        <el-table-column prop="examName" label="考试名称" />
        <el-table-column prop="submitTime" label="提交时间" width="180" />
        <el-table-column prop="score" label="得分" width="100" sortable>
          <template #default="scope">
            <span :class="getScoreClass(scope.row.score)">{{
              scope.row.score
            }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="400" fixed="right">
          <template #default="scope">
            <el-button-group>
              <el-button type="primary" link @click="handleView(scope.row)">
                <el-icon><View /></el-icon>查看答卷
              </el-button>
              <el-button type="primary" link @click="handleAnalysis(scope.row)">
                <el-icon><DataAnalysis /></el-icon>答题分析
              </el-button>
              <el-button
                type="warning"
                link
                @click="handleRemark(scope.row)"
                :disabled="scope.row.status === '已批改'"
              >
                <el-icon><Edit /></el-icon>重新批改
              </el-button>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { View, DataAnalysis, Edit } from "@element-plus/icons-vue";

const currentExam = ref("");
const currentClass = ref("");

const examList = [
  { label: "2024年春季高等数学期末考试", value: "1" },
  { label: "2024年春季大学英语四级考试", value: "2" },
];

const classList = [
  { label: "计算机2101", value: "2101" },
  { label: "计算机2102", value: "2102" },
];

const paperList = ref([
  {
    studentName: "张三",
    studentId: "2021001",
    className: "计算机2101",
    examName: "2024年春季高等数学期末考试",
    submitTime: "2024-03-20 10:30:00",
    score: 85,
    status: "已批改",
  },
  {
    studentName: "李四",
    studentId: "2021002",
    className: "计算机2101",
    examName: "2024年春季高等数学期末考试",
    submitTime: "2024-03-20 10:25:00",
    score: 92,
    status: "已批改",
  },
]);

const getScoreClass = (score) => {
  if (score >= 90) return "score-excellent";
  if (score >= 80) return "score-good";
  if (score >= 60) return "score-pass";
  return "score-fail";
};

const getStatusType = (status) => {
  const typeMap = {
    未批改: "info",
    批改中: "warning",
    已批改: "success",
  };
  return typeMap[status];
};

const handleExport = () => {
  console.log("��出答卷");
};

const handleView = (paper) => {
  console.log("查看答卷", paper);
};

const handleAnalysis = (paper) => {
  console.log("答题分析", paper);
};

const handleRemark = (paper) => {
  ElMessageBox.confirm(
    `确定要重新批改 ${paper.studentName} 的答卷吗？`,
    "提示",
    {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    }
  )
    .then(() => {
      console.log("重新批改", paper);
      ElMessage.success("已开始重新批改");
    })
    .catch(() => {
      ElMessage.info("已取消操作");
    });
};
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
}

.score-excellent {
  color: #67c23a;
  font-weight: bold;
}

.score-good {
  color: #409eff;
  font-weight: bold;
}

.score-pass {
  color: #e6a23c;
  font-weight: bold;
}

.score-fail {
  color: #f56c6c;
  font-weight: bold;
}

:deep(.el-button-group) {
  display: flex;
  gap: 8px;
}

:deep(.el-button-group .el-button) {
  padding: 4px 8px;
}

:deep(.el-button .el-icon) {
  margin-right: 4px;
}
</style>
