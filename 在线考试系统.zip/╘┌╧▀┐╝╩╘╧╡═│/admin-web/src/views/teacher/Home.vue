<template>
  <div class="teacher-home">
    <h1>教师管理系统</h1>
    <div class="dashboard">
      <el-row :gutter="20">
        <el-col :span="8">
          <el-card>
            <template #header>
              <div class="card-header">
                <span>待批改试卷</span>
              </div>
            </template>
            <div class="item">
              <!-- 这里可以添加待批改试卷的列表 -->
            </div>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card>
            <template #header>
              <div class="card-header">
                <span>班级管理</span>
              </div>
            </template>
            <div class="item">
              <!-- 这里可以添加班级管理的内容 -->
            </div>
          </el-card>
        </el-col>
        <el-col :span="8">
          <el-card>
            <template #header>
              <div class="card-header">
                <span>考试管理</span>
              </div>
            </template>
            <div class="item">
              <!-- 这里可以添加考试管理的内容 -->
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script setup>
// 可以在这里添加需要的逻辑
</script>

<style scoped>
.teacher-home {
  padding: 20px;
}

.dashboard {
  margin-top: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.item {
  margin-bottom: 18px;
}
</style>
