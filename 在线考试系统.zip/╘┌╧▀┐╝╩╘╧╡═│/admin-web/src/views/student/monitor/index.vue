<template>
  <div class="monitor-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>考试行为监控</span>
        </div>
      </template>
      <div class="monitor-content">
        <el-alert
          title="考试行为监控说明"
          type="info"
          description="系统会记录您在考试过程中的行为，包括切换窗口、离开考试页面等操作。请遵守考试规则，保持诚信考试。"
          show-icon
          :closable="false"
        />
        <div class="monitor-list">
          <el-timeline>
            <el-timeline-item
              v-for="(activity, index) in activities"
              :key="index"
              :timestamp="activity.timestamp"
              :type="activity.type"
            >
              {{ activity.content }}
            </el-timeline-item>
          </el-timeline>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const activities = ref([
  {
    content: '进入考试页面',
    timestamp: '2024-03-20 09:00:00',
    type: 'success'
  },
  {
    content: '切换浏览器窗口',
    timestamp: '2024-03-20 09:15:30',
    type: 'warning'
  }
])
</script>

<style scoped>
.monitor-container {
  padding: 20px;
}
.monitor-content {
  margin-top: 20px;
}
.monitor-list {
  margin-top: 20px;
}
</style> 