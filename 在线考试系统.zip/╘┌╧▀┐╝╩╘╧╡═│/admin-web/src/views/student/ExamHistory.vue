<template>
  <div class="history">
    <h2>考试记录</h2>
    <p>这里将显示您的历史考试记录</p>
  </div>
</template>

<style scoped>
.history {
  padding: 20px;
  background: #fff;
  border-radius: 8px;
}
</style> 