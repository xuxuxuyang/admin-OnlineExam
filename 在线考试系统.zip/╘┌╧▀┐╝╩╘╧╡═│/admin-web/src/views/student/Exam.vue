<template>
  <div class="exam-list">
    <h2>我的考试</h2>
    <p>这里将显示您可以参加的考试列表</p>
  </div>
</template>

<style scoped>
.exam-list {
  padding: 20px;
  background: #fff;
  border-radius: 8px;
}
</style>
