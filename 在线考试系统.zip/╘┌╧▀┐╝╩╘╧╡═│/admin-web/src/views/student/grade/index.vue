<template>
  <div class="grade-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <el-icon class="header-icon"><DataLine /></el-icon>
            <span>成绩管理</span>
          </div>
          <div class="header-right">
            <el-button type="primary" :icon="Download" @click="exportGrade">
              导出成绩单
            </el-button>
          </div>
        </div>
      </template>

      <!-- 成绩统计卡片 -->
      <div class="statistics-cards">
        <el-row :gutter="20">
          <el-col :span="6" v-for="item in statisticsData" :key="item.title">
            <div class="stat-card" :class="item.type">
              <el-icon class="stat-icon"><component :is="item.icon" /></el-icon>
              <div class="stat-info">
                <div class="stat-value">{{ item.value }}</div>
                <div class="stat-title">{{ item.title }}</div>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>

      <div class="grade-content">
        <el-tabs v-model="activeName">
          <el-tab-pane label="成绩概览" name="overview">
            <!-- 成绩趋势图 -->
            <div class="grade-chart-container">
              <div class="chart-header">
                <h3>成绩趋势分析</h3>
                <el-select
                  v-model="selectedSubject"
                  placeholder="选择科目"
                  size="small"
                >
                  <el-option
                    v-for="subject in subjects"
                    :key="subject.value"
                    :label="subject.label"
                    :value="subject.value"
                  />
                </el-select>
              </div>
              <div ref="trendChartRef" class="trend-chart"></div>
            </div>

            <!-- 科目分析 -->
            <div class="subject-analysis">
              <h3>科目成绩分析</h3>
              <el-row :gutter="20">
                <el-col
                  :span="12"
                  v-for="subject in subjectAnalysis"
                  :key="subject.name"
                >
                  <el-card class="subject-card" shadow="hover">
                    <template #header>
                      <div class="subject-header">
                        <span>{{ subject.name }}</span>
                        <el-tag :type="getScoreType(subject.average)">
                          平均分：{{ subject.average }}
                        </el-tag>
                      </div>
                    </template>
                    <div class="subject-content">
                      <div class="progress-item">
                        <span class="label">得分率</span>
                        <el-progress
                          :percentage="subject.scoreRate"
                          :color="getProgressColor(subject.scoreRate)"
                        />
                      </div>
                      <div class="subject-stats">
                        <div class="stat-item">
                          <span class="label">最高分</span>
                          <span class="value">{{ subject.highest }}</span>
                        </div>
                        <div class="stat-item">
                          <span class="label">最低分</span>
                          <span class="value">{{ subject.lowest }}</span>
                        </div>
                        <div class="stat-item">
                          <span class="label">排名</span>
                          <span class="value"
                            >{{ subject.rank }}/{{ subject.total }}</span
                          >
                        </div>
                      </div>
                    </div>
                  </el-card>
                </el-col>
              </el-row>
            </div>
          </el-tab-pane>

          <el-tab-pane label="成绩明细" name="detail">
            <div class="grade-filter">
              <el-select
                v-model="semesterValue"
                placeholder="选择学期"
                size="small"
              >
                <el-option
                  v-for="item in semesters"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </div>
            <el-table :data="gradeList" style="width: 100%">
              <el-table-column prop="subject" label="科目" />
              <el-table-column prop="examName" label="考试名称" />
              <el-table-column prop="score" label="得分">
                <template #default="{ row }">
                  <span :class="getScoreClass(row.score)">{{ row.score }}</span>
                </template>
              </el-table-column>
              <el-table-column prop="rank" label="排名" />
              <el-table-column prop="examTime" label="考试时间" />
              <el-table-column fixed="right" label="操作" width="120">
                <template #default="{ row }">
                  <el-button link type="primary" @click="showDetail(row)">
                    查看详情
                  </el-button>
                </template>
              </el-table-column>
            </el-table>
          </el-tab-pane>
        </el-tabs>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import {
  DataLine,
  Download,
  Trophy,
  ArrowUp,
  TrendCharts,
  Medal,
} from "@element-plus/icons-vue";
import * as echarts from "echarts";

const activeName = ref("overview");
const selectedSubject = ref("");
const semesterValue = ref("");
const trendChartRef = ref(null);

// 统计卡片数据
const statisticsData = [
  {
    title: "总平均分",
    value: "88.5",
    type: "average",
    icon: "DataLine",
  },
  {
    title: "最高成绩",
    value: "98",
    type: "highest",
    icon: "Trophy",
  },
  {
    title: "进步成绩",
    value: "+5.2",
    type: "progress",
    icon: "ArrowUp",
  },
  {
    title: "综合排名",
    value: "8/150",
    type: "rank",
    icon: "Medal",
  },
];

// 科目分析数据
const subjectAnalysis = [
  {
    name: "高等数学",
    average: 89,
    scoreRate: 89,
    highest: 98,
    lowest: 75,
    rank: 12,
    total: 150,
  },
  {
    name: "大学英语",
    average: 92,
    scoreRate: 92,
    highest: 95,
    lowest: 82,
    rank: 5,
    total: 150,
  },
];

// 成绩列表数据
const gradeList = ref([
  {
    subject: "高等数学",
    examName: "期中考试",
    score: 95,
    rank: "10/150",
    examTime: "2024-03-15",
  },
]);

// 初始化趋势图
onMounted(() => {
  const chart = echarts.init(trendChartRef.value);
  const option = {
    tooltip: {
      trigger: "axis",
    },
    xAxis: {
      type: "category",
      data: ["第一次", "第二次", "第三次", "第四次", "期中", "期末"],
    },
    yAxis: {
      type: "value",
      min: 60,
      max: 100,
    },
    series: [
      {
        data: [75, 82, 85, 88, 92, 95],
        type: "line",
        smooth: true,
        markPoint: {
          data: [
            { type: "max", name: "最高分" },
            { type: "min", name: "最低分" },
          ],
        },
        markLine: {
          data: [{ type: "average", name: "平均分" }],
        },
      },
    ],
  };
  chart.setOption(option);
});

// 工具函数
const getScoreType = (score) => {
  if (score >= 90) return "success";
  if (score >= 80) return "warning";
  if (score >= 60) return "info";
  return "danger";
};

const getScoreClass = (score) => {
  if (score >= 90) return "score-excellent";
  if (score >= 80) return "score-good";
  if (score >= 60) return "score-pass";
  return "score-fail";
};

const getProgressColor = (percentage) => {
  if (percentage >= 90) return "#67C23A";
  if (percentage >= 80) return "#409EFF";
  if (percentage >= 60) return "#E6A23C";
  return "#F56C6C";
};

const showDetail = (row) => {
  console.log("查看详情", row);
};

const exportGrade = () => {
  console.log("导出成绩单");
};
</script>

<style scoped>
.grade-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.header-icon {
  font-size: 20px;
  color: var(--el-color-primary);
}

.statistics-cards {
  margin-bottom: 24px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  border-radius: 8px;
  transition: all 0.3s;
}

.stat-icon {
  font-size: 32px;
  padding: 12px;
  border-radius: 8px;
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 4px;
}

.stat-title {
  color: #909399;
  font-size: 14px;
}

/* 统计卡片样式变体 */
.average {
  background: #ecf5ff;
}
.average .stat-icon {
  color: #409eff;
  background: #d9ecff;
}
.average .stat-value {
  color: #409eff;
}

.highest {
  background: #f0f9eb;
}
.highest .stat-icon {
  color: #67c23a;
  background: #e1f3d8;
}
.highest .stat-value {
  color: #67c23a;
}

.progress {
  background: #fdf6ec;
}
.progress .stat-icon {
  color: #e6a23c;
  background: #faecd8;
}
.progress .stat-value {
  color: #e6a23c;
}

.rank {
  background: #f4f4f5;
}
.rank .stat-icon {
  color: #909399;
  background: #e9e9eb;
}
.rank .stat-value {
  color: #909399;
}

.grade-chart-container {
  margin: 20px 0;
  padding: 20px;
  background: #f8f9fb;
  border-radius: 8px;
}

.chart-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.chart-header h3 {
  margin: 0;
  font-size: 16px;
  color: #303133;
}

.trend-chart {
  height: 300px;
}

.subject-analysis {
  margin-top: 24px;
}

.subject-analysis h3 {
  margin-bottom: 16px;
  font-size: 16px;
  color: #303133;
}

.subject-card {
  margin-bottom: 20px;
}

.subject-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.progress-item {
  margin-bottom: 16px;
}

.progress-item .label {
  display: inline-block;
  margin-bottom: 8px;
  color: #606266;
}

.subject-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
}

.stat-item {
  text-align: center;
}

.stat-item .label {
  display: block;
  margin-bottom: 4px;
  color: #909399;
  font-size: 13px;
}

.stat-item .value {
  font-size: 16px;
  font-weight: 500;
  color: #303133;
}

.grade-filter {
  margin-bottom: 16px;
}

/* 成绩等级样式 */
.score-excellent {
  color: #67c23a;
  font-weight: bold;
}

.score-good {
  color: #409eff;
  font-weight: bold;
}

.score-pass {
  color: #e6a23c;
  font-weight: bold;
}

.score-fail {
  color: #f56c6c;
  font-weight: bold;
}
</style>
