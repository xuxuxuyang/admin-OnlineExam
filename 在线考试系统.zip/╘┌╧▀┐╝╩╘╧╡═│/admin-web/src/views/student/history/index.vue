<template>
  <div class="history-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <span>历史考试</span>
        </div>
      </template>
      <div class="history-list">
        <el-table :data="historyList" style="width: 100%">
          <el-table-column prop="name" label="考试名称" />
          <el-table-column prop="subject" label="科目" />
          <el-table-column prop="examTime" label="考试时间" />
          <el-table-column prop="score" label="得分" />
          <el-table-column label="操作">
            <template #default>
              <el-button type="info" size="small">查看详情</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const historyList = ref([
  {
    name: '期中考试',
    subject: '数学',
    examTime: '2024-03-15',
    score: '95'
  }
])
</script>

<style scoped>
.history-container {
  padding: 20px;
}
</style> 