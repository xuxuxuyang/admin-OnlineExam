<template>
  <div class="student-score">
    <el-row :gutter="20">
      <el-col :span="6" v-for="card in statisticsCards" :key="card.title">
        <el-card shadow="hover" class="statistics-card">
          <div class="card-content">
            <div class="card-value">{{ card.value }}</div>
            <div class="card-title">{{ card.title }}</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-card class="chart-card">
      <template #header>
        <div class="card-header">
          <span>成绩趋势</span>
          <el-select
            v-model="currentSubject"
            placeholder="选择科目"
            style="width: 200px"
          >
            <el-option
              v-for="item in subjectList"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </div>
      </template>
      <div ref="scoreChartRef" style="height: 300px"></div>
    </el-card>

    <el-card class="score-table">
      <template #header>
        <div class="card-header">
          <span>成绩列表</span>
          <div class="header-right">
            <el-date-picker
              v-model="dateRange"
              type="daterange"
              range-separator="至"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              style="width: 320px"
            />
          </div>
        </div>
      </template>

      <el-table :data="scoreList" border stripe>
        <el-table-column prop="examName" label="考试名称" />
        <el-table-column prop="subject" label="科目" width="120" />
        <el-table-column prop="score" label="得分" width="100" sortable>
          <template #default="scope">
            <span :class="getScoreClass(scope.row.score)">{{
              scope.row.score
            }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="rank" label="排名" width="100" sortable />
        <el-table-column prop="examTime" label="考试时间" width="180" />
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleDetail(scope.row)"
              >查看详情</el-button
            >
            <el-button
              size="small"
              type="primary"
              @click="handleAnalysis(scope.row)"
              >成绩分析</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import * as echarts from "echarts";

const currentSubject = ref("");
const dateRange = ref([]);

const subjectList = [
  { label: "全部科目", value: "" },
  { label: "高等数学", value: "math" },
  { label: "大学英语", value: "english" },
  { label: "计算机基础", value: "computer" },
];

const statisticsCards = [
  { title: "平均分", value: "85.5" },
  { title: "最高分", value: "98" },
  { title: "最低分", value: "72" },
  { title: "考试次数", value: "12" },
];

const scoreList = ref([
  {
    examName: "2024年春季高等数学期末考试",
    subject: "高等数学",
    score: 85,
    rank: 15,
    examTime: "2024-01-15",
  },
  {
    examName: "2024年春季大学英语四级考试",
    subject: "大学英语",
    score: 92,
    rank: 5,
    examTime: "2024-01-20",
  },
]);

const scoreChartRef = ref(null);

onMounted(() => {
  const scoreChart = echarts.init(scoreChartRef.value);
  scoreChart.setOption({
    title: { text: "成绩趋势" },
    tooltip: { trigger: "axis" },
    xAxis: {
      type: "category",
      data: ["第一次", "第二次", "第三次", "第四次", "第五次"],
    },
    yAxis: { type: "value" },
    series: [
      {
        data: [75, 82, 85, 90, 92],
        type: "line",
        smooth: true,
        markPoint: {
          data: [
            { type: "max", name: "最高分" },
            { type: "min", name: "最低分" },
          ],
        },
        markLine: {
          data: [{ type: "average", name: "平均分" }],
        },
      },
    ],
  });

  window.addEventListener("resize", () => {
    scoreChart.resize();
  });
});

const getScoreClass = (score) => {
  if (score >= 90) return "score-excellent";
  if (score >= 80) return "score-good";
  if (score >= 60) return "score-pass";
  return "score-fail";
};

const handleDetail = (score) => {
  console.log("查看成绩详情", score);
};

const handleAnalysis = (score) => {
  console.log("成绩分析", score);
};
</script>

<style scoped>
.statistics-card {
  margin-bottom: 20px;
}

.card-content {
  text-align: center;
}

.card-value {
  font-size: 24px;
  font-weight: bold;
  color: #1890ff;
}

.card-title {
  margin-top: 8px;
  color: #666;
}

.chart-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.score-excellent {
  color: #67c23a;
  font-weight: bold;
}

.score-good {
  color: #409eff;
  font-weight: bold;
}

.score-pass {
  color: #e6a23c;
  font-weight: bold;
}

.score-fail {
  color: #f56c6c;
  font-weight: bold;
}
</style>
