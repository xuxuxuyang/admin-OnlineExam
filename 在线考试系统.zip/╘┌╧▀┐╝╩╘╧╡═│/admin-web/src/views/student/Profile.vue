<template>
  <div class="profile">
    <h2>个人信息</h2>
    <p>这里将显示您的个人信息</p>
  </div>
</template>

<style scoped>
.profile {
  padding: 20px;
  background: #fff;
  border-radius: 8px;
}
</style> 