<template>
  <div class="exam-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <el-icon class="header-icon"><Edit /></el-icon>
            <span>考试管理</span>
          </div>
          <div class="header-right">
            <el-tooltip content="刷新考试列表" placement="top">
              <el-button :icon="Refresh" circle @click="refreshList" />
            </el-tooltip>
          </div>
        </div>
      </template>

      <!-- 考试状态统计卡片 -->
      <div class="exam-statistics">
        <el-row :gutter="20">
          <el-col :span="8">
            <div class="stat-card ongoing">
              <el-icon><Timer /></el-icon>
              <div class="stat-info">
                <div class="stat-value">{{ getExamCount("进行中") }}</div>
                <div class="stat-label">进行中考试</div>
              </div>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="stat-card upcoming">
              <el-icon><Calendar /></el-icon>
              <div class="stat-info">
                <div class="stat-value">{{ getExamCount("未开始") }}</div>
                <div class="stat-label">即将开始</div>
              </div>
            </div>
          </el-col>
          <el-col :span="8">
            <div class="stat-card finished">
              <el-icon><Check /></el-icon>
              <div class="stat-info">
                <div class="stat-value">{{ getExamCount("已结束") }}</div>
                <div class="stat-label">已结束考试</div>
              </div>
            </div>
          </el-col>
        </el-row>
      </div>

      <div class="exam-list">
        <el-table
          :data="examList"
          style="width: 100%"
          :row-class-name="tableRowClassName"
        >
          <el-table-column prop="name" label="考试名称">
            <template #default="{ row }">
              <div class="exam-name">
                <el-icon><Document /></el-icon>
                <span>{{ row.name }}</span>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="subject" label="科目">
            <template #default="{ row }">
              <el-tag size="small" effect="plain">{{ row.subject }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="startTime" label="开始时间">
            <template #default="{ row }">
              <div class="time-info">
                <el-icon><Clock /></el-icon>
                <span>{{ row.startTime }}</span>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="duration" label="考试时长">
            <template #default="{ row }">
              <div class="duration-info">
                <el-icon><Timer /></el-icon>
                <span>{{ row.duration }}</span>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="status" label="状态" width="100">
            <template #default="{ row }">
              <el-tag
                :type="getStatusType(row.status)"
                effect="dark"
                class="status-tag"
                size="large"
              >
                <el-icon class="status-icon">
                  <component :is="getStatusIcon(row.status)" />
                </el-icon>
                <span class="status-text">{{ row.status }}</span>
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="180" fixed="right">
            <template #default="{ row }">
              <el-button
                type="primary"
                :icon="VideoPlay"
                size="small"
                @click="handleEnterExam(row)"
                :disabled="!canEnterExam(row.status)"
                class="enter-btn"
              >
                进入考试
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import {
  Edit,
  Refresh,
  Document,
  Clock,
  Timer,
  Calendar,
  Check,
  VideoPlay,
  Loading,
  CircleCheck,
  Warning,
} from "@element-plus/icons-vue";

const router = useRouter();

const examList = ref([
  {
    id: "1",
    name: "2024春季高等数学期中考试",
    subject: "高等数学",
    startTime: "2024-03-20 09:00",
    duration: "120分钟",
    status: "进行中",
  },
  {
    id: "2",
    name: "2024春季大学英语期中考试",
    subject: "大学英语",
    startTime: "2024-03-21 14:00",
    duration: "90分钟",
    status: "未开始",
  },
  {
    id: "3",
    name: "2024春季计算机基础期中考试",
    subject: "计算机基础",
    startTime: "2024-03-19 10:00",
    duration: "120分钟",
    status: "已结束",
  },
]);

const getStatusType = (status) => {
  const typeMap = {
    未开始: "info",
    进行中: "success",
    已结束: "",
  };
  return typeMap[status];
};

const canEnterExam = (status) => {
  return status === "进行中";
};

const handleEnterExam = (exam) => {
  if (!canEnterExam(exam.status)) {
    ElMessage.warning("当前考试不可进入");
    return;
  }

  // 存储考试信息到 localStorage，以便在考试页面使用
  localStorage.setItem(
    "currentExam",
    JSON.stringify({
      id: exam.id,
      name: exam.name,
      subject: exam.subject,
      duration: exam.duration,
      startTime: exam.startTime,
    })
  );

  // 跳转到考试页面
  router.push(`/student/exam/${exam.id}`);
};

const getStatusIcon = (status) => {
  const iconMap = {
    未开始: Warning,
    进行中: Loading,
    已结束: CircleCheck,
  };
  return iconMap[status];
};

const getExamCount = (status) => {
  return examList.value.filter((exam) => exam.status === status).length;
};

const tableRowClassName = ({ row }) => {
  return `exam-row ${row.status}`;
};

const refreshList = () => {
  ElMessage.success("刷新成功");
};
</script>

<style scoped>
.exam-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: bold;
}

.header-icon {
  font-size: 20px;
  color: #409eff;
}

.exam-statistics {
  margin-bottom: 24px;
}

.stat-card {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px;
  border-radius: 8px;
  transition: all 0.3s;
  cursor: pointer;
}

.stat-card:hover {
  transform: translateY(-2px);
}

.stat-card .el-icon {
  font-size: 44px;
  padding: 12px;
  border-radius: 8px;
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 4px;
}

.stat-label {
  color: #909399;
  font-size: 14px;
}

.ongoing {
  background: #ecf5ff;
}

.ongoing .el-icon {
  color: #409eff;
  background: #d9ecff;
}

.ongoing .stat-value {
  color: #409eff;
}

.upcoming {
  background: #f0f9eb;
}

.upcoming .el-icon {
  color: #67c23a;
  background: #e1f3d8;
}

.upcoming .stat-value {
  color: #67c23a;
}

.finished {
  background: #f4f4f5;
}

.finished .el-icon {
  color: #909399;
  background: #e9e9eb;
}

.finished .stat-value {
  color: #909399;
}

.exam-name {
  display: flex;
  align-items: center;
  gap: 8px;
}

.time-info,
.duration-info {
  display: flex;
  align-items: center;
  gap: 4px;
  color: #606266;
}

.status-tag {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 2px;
  padding: 0 8px;
  height: 24px;
  min-width: 72px;
}

.status-icon {
  font-size: 14px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  line-height: 1;
}

.status-text {
  font-size: 12px;
  line-height: 1;
  display: inline-flex;
  align-items: center;
  white-space: nowrap;
}

/* 确保不同状态下的样式一致 */
.status-tag.el-tag--success .status-icon,
.status-tag.el-tag--warning .status-icon,
.status-tag.el-tag--info .status-icon {
  margin: 0;
  vertical-align: middle;
}

/* 移除多余的过渡效果声明 */
.status-tag {
  transition: all 0.3s ease;
}

.enter-btn {
  transition: all 0.3s;
}

.enter-btn:not(:disabled):hover {
  transform: translateX(4px);
}

:deep(.exam-row) {
  transition: all 0.3s;
}

:deep(.exam-row:hover) {
  background-color: #f5f7fa;
}

:deep(.exam-row.进行中) {
  background-color: #ecf5ff;
}

:deep(.exam-row.进行中:hover) {
  background-color: #d9ecff;
}

:deep(.el-table) {
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.05);
}

/* 添加动画 */
.exam-container {
  animation: fadeIn 0.5s ease-out;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 添加加载动画 */
:deep(.el-icon.is-loading) {
  animation: rotating 2s linear infinite;
}

@keyframes rotating {
  from {
    transform: rotate(0);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
