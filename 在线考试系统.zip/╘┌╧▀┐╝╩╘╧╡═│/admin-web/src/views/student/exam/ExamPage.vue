<template>
  <div class="exam-page">
    <!-- 左侧面板 -->
    <div class="left-panel">
      <!-- 学生信息区 -->
      <el-card class="student-info">
        <div class="info-header">
          <el-avatar :size="60" :src="studentInfo.avatar">
            {{ studentInfo.name.charAt(0) }}
          </el-avatar>
          <div class="info-details">
            <h3>{{ studentInfo.name }}</h3>
            <p>{{ studentInfo.studentId }}</p>
          </div>
        </div>
        <div class="answer-status">
          <div class="status-item">
            <span class="label">已答题数</span>
            <span class="value answered">{{ studentInfo.answered }}</span>
          </div>
          <div class="status-item">
            <span class="label">标记题数</span>
            <span class="value marked">{{ markedCount }}</span>
          </div>
          <div class="status-item">
            <span class="label">未答题数</span>
            <span class="value unanswered">{{ studentInfo.unanswered }}</span>
          </div>
        </div>
      </el-card>

      <!-- 考试时间区 -->
      <el-card class="exam-timer">
        <template #header>
          <div class="timer-header">
            <div class="timer-title">
              <el-icon><Document /></el-icon>
              <span>{{ examInfo.subject }}</span>
            </div>
            <div class="timer-tag">
              <el-icon><Timer /></el-icon>
              <span>剩余时间</span>
            </div>
          </div>
        </template>
        <div class="timer-content">
          <div class="exam-info">
            <div class="time-list">
              <div class="info-item">
                <div class="time-label-row">
                  <el-icon><Clock /></el-icon>
                  <span class="label">开始时间：</span>
                </div>
                <div class="time-value-row">
                  <span class="value">{{ examInfo.startTime }}</span>
                </div>
              </div>
              <div class="info-item">
                <div class="time-label-row">
                  <el-icon><Timer /></el-icon>
                  <span class="label">结束时间：</span>
                </div>
                <div class="time-value-row">
                  <span class="value">{{ examInfo.endTime }}</span>
                </div>
              </div>
            </div>
          </div>
          <div class="countdown">
            <div class="time-block">
              <span class="time-value">{{ countdown.hours }}</span>
              <span class="time-label">小时</span>
            </div>
            <span class="time-separator">:</span>
            <div class="time-block">
              <span class="time-value">{{ countdown.minutes }}</span>
              <span class="time-label">分</span>
            </div>
            <span class="time-separator">:</span>
            <div class="time-block">
              <span class="time-value">{{ countdown.seconds }}</span>
              <span class="time-label">秒</span>
            </div>
          </div>
        </div>
      </el-card>

      <!-- 将题目导航区改为考试行为监控区 -->
      <el-card class="monitor-card">
        <template #header>
          <div class="monitor-header">
            <div class="header-title">
              <el-icon><Warning /></el-icon>
              <span>考试行为监控</span>
            </div>
          </div>
        </template>
        <div class="monitor-content">
          <!-- 摄像头状态 -->
          <div class="monitor-item">
            <div class="item-label">
              <el-icon><VideoCamera /></el-icon>
              <span>摄像头状态</span>
            </div>
            <div class="item-value">
              <el-tag :type="cameraStatus ? 'success' : 'danger'" size="small">
                {{ cameraStatus ? "已开启" : "未开启" }}
              </el-tag>
            </div>
          </div>

          <!-- 切屏记录 -->
          <div class="monitor-item">
            <div class="item-label">
              <el-icon><Switch /></el-icon>
              <span>切屏次数</span>
            </div>
            <div class="item-value">
              <el-tag
                :type="switchCount > 3 ? 'danger' : 'warning'"
                size="small"
              >
                {{ switchCount }}次
              </el-tag>
            </div>
          </div>

          <!-- 考试时长 -->
          <div class="monitor-item">
            <div class="item-label">
              <el-icon><Timer /></el-icon>
              <span>已考时长</span>
            </div>
            <div class="item-value">
              <span class="time-text">{{ examDuration }}</span>
            </div>
          </div>

          <!-- 设备信息 -->
          <div class="monitor-item">
            <div class="item-label">
              <el-icon><Monitor /></el-icon>
              <span>设备信息</span>
            </div>
            <div class="item-value">
              <el-tag type="info" size="small">{{ deviceInfo }}</el-tag>
            </div>
          </div>

          <!-- IP地址 -->
          <div class="monitor-item">
            <div class="item-label">
              <el-icon><Location /></el-icon>
              <span>IP地址</span>
            </div>
            <div class="item-value">
              <span class="ip-text">{{ ipAddress }}</span>
            </div>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 中间答题区 -->
    <div class="center-panel">
      <el-card class="question-area">
        <template #header>
          <div class="question-header">
            <span class="question-type">单选题</span>
            <span class="question-score">本题分值：5分</span>
          </div>
        </template>
        <div class="question-content">
          <div class="question-title">
            <span class="question-index">3.</span>
            <div class="question-text">
              {{ currentQuestion.content }}
            </div>
          </div>
          <div class="question-options">
            <el-radio-group v-model="currentAnswer">
              <el-radio
                v-for="(option, index) in currentQuestion.options"
                :key="index"
                :label="option.value"
                class="option-item"
              >
                {{ option.label }}
              </el-radio>
            </el-radio-group>
          </div>
        </div>
        <div class="question-actions">
          <el-button type="warning" @click="handleMark">标记</el-button>
          <div class="navigation-buttons">
            <el-button @click="handlePrev">上一题</el-button>
            <el-button type="primary" @click="handleNext">下一题</el-button>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 右侧作答状态区 -->
    <div class="right-panel">
      <el-card class="answer-status-panel">
        <template #header>
          <div class="status-header">
            <el-icon><DataLine /></el-icon>
            <span>作答状态</span>
          </div>
        </template>
        <div class="status-content">
          <!-- 总题数统计定在顶部 -->
          <div class="total-stats">
            <div class="total-header">
              <span class="total-title">总题数：{{ totalQuestions }}题</span>
            </div>
            <div class="question-types-stats">
              <div
                v-for="type in questionTypes"
                :key="type.id"
                class="type-stat-item"
                :class="{ active: currentQuestionType.id === type.id }"
                @click="handleTypeChange(type.id)"
              >
                <span class="type-name">{{ type.name }}</span>
                <span class="type-count">{{ type.count }}题</span>
              </div>
            </div>
            <!-- 状态图例 -->
            <div class="status-legend">
              <div class="legend-item">
                <span class="legend-dot unanswered"></span>
                <span>未作答</span>
              </div>
              <div class="legend-item">
                <span class="legend-dot marked"></span>
                <span>已标记</span>
              </div>
              <div class="legend-item">
                <span class="legend-dot answered"></span>
                <span>已作答</span>
              </div>
            </div>
          </div>

          <!-- 可滚动的内容区域 - 根据选中题型显示对应题目列表 -->
          <div class="scrollable-content">
            <div class="question-status-sections">
              <!-- 动态显示当前选中题型的题目列表 -->
              <div class="status-section">
                <div class="section-header">
                  <div class="section-title">
                    <span>{{ currentQuestionType.name }}</span>
                  </div>
                  <div class="section-info">
                    <span class="section-count"
                      >{{ currentQuestionType.range }}题</span
                    >
                    <span class="section-score"
                      >每题{{ currentQuestionType.score }}分</span
                    >
                  </div>
                </div>
                <div class="status-grid">
                  <div
                    v-for="n in getQuestionRange()"
                    :key="getQuestionNumber(n)"
                    class="status-item"
                    :class="[
                      getQuestionStatus(getQuestionNumber(n)),
                      { active: currentQuestionIndex === getQuestionNumber(n) },
                    ]"
                    @click="jumpToQuestion(getQuestionNumber(n))"
                  >
                    {{ getQuestionNumber(n) }}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- 交卷按钮 -->
          <div class="submit-exam-area">
            <el-button
              type="primary"
              class="submit-exam-button"
              :loading="submitting"
              @click="handleSubmit"
            >
              <span>交卷</span>
            </el-button>
            <div class="submit-tip">请确认所有题目都已完成后再交卷</div>
          </div>
        </div>
      </el-card>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from "vue";
import { useRoute, useRouter } from "vue-router";

const studentInfo = ref({
  name: "baymax",
  studentId: "270123456",
  avatar: "",
  answered: 3,
  unanswered: 7,
});

const examInfo = ref({
  name: "2024春季高等数学期中考试",
  subject: "高等数学",
  startTime: "2024-03-20 09:00:00",
  endTime: "2024-03-20 11:00:00",
  duration: 7200, // 2小时，单位秒
});

const remainingTime = ref(examInfo.value.duration);
const countdown = computed(() => {
  const hours = Math.floor(remainingTime.value / 3600);
  const minutes = Math.floor((remainingTime.value % 3600) / 60);
  const seconds = remainingTime.value % 60;
  return {
    hours: hours.toString().padStart(2, "0"),
    minutes: minutes.toString().padStart(2, "0"),
    seconds: seconds.toString().padStart(2, "0"),
  };
});

let timer = null;

onMounted(() => {
  timer = setInterval(() => {
    if (remainingTime.value > 0) {
      remainingTime.value--;
    } else {
      clearInterval(timer);
      // TODO: 考试时间结束处理
    }
  }, 1000);
});

onUnmounted(() => {
  if (timer) {
    clearInterval(timer);
  }
});

const getQuestionStatus = (questionId) => {
  // 模拟题目状态
  if (questionId <= 3) return "answered";
  if (questionId === 4) return "marked";
  return "unanswered";
};

const jumpToQuestion = (questionNumber) => {
  currentQuestionIndex.value = questionNumber;
  // 根据题号确定题型并更新
  const type = questionTypes.value.find((t) => {
    const [start, end] = t.range.split("-").map(Number);
    return questionNumber >= start && questionNumber <= end;
  });
  if (type) {
    currentQuestionType.value = type;
    updateCurrentQuestionByType(type);
  }
};

// 前题目数据
const currentQuestion = ref({
  content: "单片机的堆栈指针 SP 终指向( )",
  options: [
    { label: "A. 指示堆栈地址", value: "A" },
    { label: "B. 指示堆栈底", value: "B" },
    { label: "C. 指示堆栈", value: "C" },
    { label: "D. 指示堆栈长度", value: "D" },
  ],
});

const currentAnswer = ref("");
const totalQuestions = ref(55);
const answeredCount = ref(3);
const unansweredCount = computed(
  () => totalQuestions.value - answeredCount.value
);
const markedCount = ref(1);

const handleMark = () => {
  console.log("标记前题目");
};

const handlePrev = () => {
  console.log("上一题");
};

const handleNext = () => {
  console.log("下一题");
};

// 加当前题目索引
const currentQuestionIndex = ref(3);

// 添加新的响应式数据
const singleAnswered = ref(2);
const multipleAnswered = ref(1);
const answerProgress = computed(() => {
  return Math.round((answeredCount.value / totalQuestions.value) * 100);
});

const getProgressStatus = (percentage) => {
  if (percentage === 100) return "success";
  if (percentage >= 60) return "";
  return "exception";
};

// 添加作答状态数据
const unansweredList = ref([4, 5, 6, 7, 8, 9, 10]);
const incompleteList = ref([11, 12, 13]);
const answeredList = ref([1, 2, 3]);

// 添加提交状态
const submitting = ref(false);

// 保留这个异步版本的 handleSubmit
const handleSubmit = async () => {
  try {
    submitting.value = true;
    // TODO: 处理提交逻辑
    await new Promise((resolve) => setTimeout(resolve, 1000)); // 模拟提交
    ElMessage.success("提交成功");
  } catch (error) {
    ElMessage.error("提交失败，请重试");
  } finally {
    submitting.value = false;
  }
};

// 添加题型相关的响应式数据
const questionTypes = ref([
  {
    id: "single",
    name: "单选题",
    range: "1-20",
    count: 20,
    score: 5,
    component: "SingleChoice",
  },
  {
    id: "multiple",
    name: "多选题",
    range: "21-35",
    count: 15,
    score: 10,
    component: "MultipleChoice",
  },
  {
    id: "essay",
    name: "问答题",
    range: "36-40",
    count: 5,
    score: 20,
    component: "Essay",
  },
]);

// 当前选中的题型
const currentQuestionType = ref(questionTypes.value[0]);

// 根据题型更新当前题目
const updateCurrentQuestionByType = (type) => {
  currentQuestionType.value = type;
  const [start] = type.range.split("-").map(Number);
  currentQuestionIndex.value = start;

  // 更新当前题目内容
  currentQuestion.value = {
    type: type.name,
    score: type.score,
    content: `这是一${type.name}（题号：${currentQuestionIndex.value}）`,
    options:
      type.id === "single"
        ? [
            { label: "A. 选项A", value: "A" },
            { label: "B. 选项B", value: "B" },
            { label: "C. 选项C", value: "C" },
            { label: "D. 选项D", value: "D" },
          ]
        : type.id === "multiple"
        ? [
            { label: "A. 多选项A", value: "A" },
            { label: "B. 多选项B", value: "B" },
            { label: "C. 多选项C", value: "C" },
            { label: "D. 多选项D", value: "D" },
          ]
        : [],
  };
};

// 获取当前题型的题目范围
const getQuestionRange = () => {
  const [start, end] = currentQuestionType.value.range.split("-").map(Number);
  return end - start + 1;
};

// 获取实际题号
const getQuestionNumber = (index) => {
  const [start] = currentQuestionType.value.range.split("-").map(Number);
  return start + index - 1;
};

// 更新题型切换处理函数
const handleTypeChange = (typeId) => {
  const selectedType = questionTypes.value.find((t) => t.id === typeId);
  if (selectedType) {
    currentQuestionType.value = selectedType;
    // 更新当前题目为该题型的第一题
    const [start] = selectedType.range.split("-").map(Number);
    currentQuestionIndex.value = start;
    updateCurrentQuestionByType(selectedType);
  }
};

// 修改右侧状态面板的题型统计部分
const renderQuestionTypeStats = () => {
  return questionTypes.value.map((type) => ({
    name: type.name,
    count: type.count,
    answered: getAnsweredCountByType(type.id),
  }));
};

// 获取某题型的已答题数
const getAnsweredCountByType = (typeId) => {
  // 这里可以根据实际数据统计已答题数
  return 0; // 临时返回0
};

// 添加监控相关的响应式数据
const cameraStatus = ref(true);
const switchCount = ref(2);
const examDuration = ref("00:45:30");
const deviceInfo = ref("Windows Chrome");
const ipAddress = ref("192.168.1.100");
</script>

<style scoped>
/* 基础布局 */
.exam-page {
  display: flex;
  gap: clamp(12px, 2vw, 20px);
  height: calc(100vh - 120px);
  padding: clamp(12px, 2vw, 20px);
  min-width: 1024px;
}

/* 左侧面 */
.left-panel {
  width: clamp(260px, 20vw, 320px);
  display: flex;
  flex-direction: column;
  gap: clamp(12px, 1.5vh, 16px);
  min-width: 260px;
}

/* 学生信息区样式 */
.student-info {
  min-height: fit-content;
}

.student-info :deep(.el-card__body) {
  padding: 20px;
}

.info-header {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
  padding-bottom: 16px;
  border-bottom: 1px solid #f0f0f0;
}

.info-details {
  flex: 1;
}

.info-details h3 {
  margin: 0;
  font-size: 18px;
  color: #303133;
  font-weight: 600;
  line-height: 1.4;
}

.info-details p {
  margin: 4px 0 0;
  color: #909399;
  font-size: 14px;
}

.answer-status {
  display: flex;
  justify-content: space-between;
  padding: 12px 16px;
  margin: 0 -20px -10px;
  /* background: #f5f7fa; */
  /* border-top: 1px solid #f0f0f0; */
}

.status-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}

.status-item .label {
  font-size: 13px;
  /* color: #909399; */
}

.status-item .value {
  font-size: 20px;
  font-weight: 600;
  line-height: 1;
}

/* 已答题数样式 */
.status-item .value.answered {
  color: #67c23a;
}

/* 标记题数样式 */
.status-item .value.marked {
  color: #e6a23c;
}

/* 未答题数样式 */
.status-item .value.unanswered {
  color: #f56c6c;
}

:deep(.el-avatar) {
  background: #409eff;
  font-size: 24px;
  font-weight: 500;
}

/* 考试时间区式 */
.exam-timer {
  min-height: fit-content;
}

.timer-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.timer-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: clamp(14px, 1vw, 15px);
  font-weight: bold;
  color: #303133;
}

.timer-title .el-icon {
  font-size: clamp(16px, 1.2vw, 18px);
  color: #409eff;
}

.timer-tag {
  display: flex;
  align-items: center;
  gap: 4px;
  color: #f56c6c;
  font-size: clamp(12px, 0.9vw, 13px);
}

.countdown {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: clamp(4px, 0.5vw, 8px);
  padding: clamp(12px, 2vh, 20px);
  background: #fef0f0;
  border-radius: 8px;
  margin-top: 16px;
}

.time-block {
  display: flex;
  flex-direction: column;
  align-items: center;
  background: #f56c6c;
  padding: clamp(4px, 0.8vw, 8px);
  border-radius: 4px;
  min-width: clamp(40px, 4vw, 60px);
}

.time-value {
  color: white;
  font-size: clamp(18px, 1.5vw, 20px);
  font-weight: bold;
  line-height: 1;
}

.time-label {
  color: rgba(255, 255, 255, 0.9);
  font-size: clamp(11px, 0.8vw, 12px);
  margin-top: 2px;
}

.time-separator {
  color: #f56c6c;
  font-size: clamp(18px, 1.5vw, 20px);
  font-weight: bold;
  padding: 0 2px;
  margin-top: -8px;
}

/* 监控卡片样式 */
.monitor-card {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.monitor-card :deep(.el-card__body) {
  padding: 20px;
  flex: 1;
}

.monitor-header {
  margin-bottom: 16px;
}

.header-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.header-title .el-icon {
  font-size: 18px;
  color: #f56c6c;
}

.monitor-content {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.monitor-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: #f8f9fb;
  border-radius: 8px;
}

.item-label {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #606266;
  font-size: 14px;
}

.item-label .el-icon {
  font-size: 16px;
}

.item-value {
  font-size: 14px;
}

.time-text {
  color: #409eff;
  font-weight: 500;
}

.ip-text {
  color: #606266;
  font-family: monospace;
}

/* 适配小屏幕 */
@media screen and (max-width: 1366px) {
  .monitor-card :deep(.el-card__body) {
    padding: 16px;
  }

  .monitor-item {
    padding: 10px 12px;
  }

  .item-label {
    font-size: 13px;
  }

  .item-value {
    font-size: 13px;
  }
}

/* 中间题区域 */
.center-panel {
  flex: 1;
  min-width: 500px;
  display: flex;
  flex-direction: column;
}

.question-area {
  height: 100%;
  display: flex;
  flex-direction: column;
}

/* 题目头部样式 */
.question-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  border-bottom: 1px solid #f0f0f0;
  background: #fafafa;
}

.question-type {
  display: flex;
  align-items: center;
  gap: 8px;
  font-weight: 600;
  color: #409eff;
  font-size: 16px;
}

.question-score {
  display: flex;
  align-items: center;
  gap: 4px;
  color: #f56c6c;
  font-size: 14px;
}

/* 题目内容区域 */
.question-content {
  flex: 1;
  padding: 24px;
  overflow-y: auto;
}

.question-title {
  display: flex;
  gap: 12px;
  margin-bottom: 24px;
  line-height: 1.6;
}

.question-index {
  font-size: 16px;
  font-weight: 600;
  color: #409eff;
  flex-shrink: 0;
}

.question-text {
  font-size: 16px;
  color: #303133;
  line-height: 1.6;
}

/* 选项样式 */
.question-options {
  padding-left: 28px;
}

.option-item {
  display: block;
  margin-bottom: 20px;
  padding: 12px 16px;
  border-radius: 8px;
  transition: all 0.3s;
  border: 1px solid transparent;
}

.option-item:hover {
  background: #f5f7fa;
  border-color: #dcdfe6;
}

:deep(.el-radio) {
  width: 100%;
  height: 100%;
  margin-right: 0;
}

:deep(.el-radio__label) {
  font-size: 15px;
  color: #606266;
  line-height: 1.6;
  white-space: normal;
  padding-right: 16px;
}

:deep(.el-radio__input.is-checked + .el-radio__label) {
  color: #409eff;
  font-weight: 500;
}

/* 底部操作区域 */
.question-actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 24px;
  border-top: 1px solid #f0f0f0;
  background: #fff;
}

.navigation-buttons {
  display: flex;
  gap: 12px;
}

:deep(.el-button) {
  padding: 10px 24px;
  font-size: 14px;
  border-radius: 6px;
}

:deep(.el-button--warning) {
  background: #fdf6ec;
  border-color: #e6a23c;
  color: #e6a23c;
}

:deep(.el-button--warning:hover) {
  background: #e6a23c;
  border-color: #e6a23c;
  color: #fff;
}

/* 滚动条样式 */
.question-content::-webkit-scrollbar {
  width: 6px;
}

.question-content::-webkit-scrollbar-thumb {
  background: #e4e7ed;
  border-radius: 3px;
}

.question-content::-webkit-scrollbar-track {
  background: #f5f7fa;
  border-radius: 3px;
}

/* 响应式调整 */
@media screen and (max-width: 1366px) {
  .question-content {
    padding: 20px;
  }

  .question-header,
  .question-actions {
    padding: 12px 20px;
  }

  .option-item {
    padding: 10px 14px;
    margin-bottom: 16px;
  }
}

@media screen and (min-width: 1920px) {
  .question-content {
    padding: 32px;
  }

  .question-header,
  .question-actions {
    padding: 20px 32px;
  }

  .question-title {
    font-size: 18px;
  }

  :deep(.el-radio__label) {
    font-size: 16px;
  }
}

/* 右侧状态面板基础样式 */
.right-panel {
  width: clamp(260px, 20vw, 320px);
  min-width: 260px;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.answer-status-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
}

:deep(.el-card__body) {
  flex: 1;
  padding: 0;
  display: flex;
  flex-direction: column;
}

/* 状态内容区域 */
.status-content {
  flex: 1;
  display: flex;
  flex-direction: column;
}

/* 可滚动的内容区域 */
.scrollable-content {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  /* 添加平滑滚动 */
  scroll-behavior: smooth;
  /* 美化滚动条 */
  scrollbar-width: thin;
  scrollbar-color: #909399 #f4f4f5;
}

.scrollable-content::-webkit-scrollbar {
  width: 6px;
}

.scrollable-content::-webkit-scrollbar-thumb {
  background-color: #909399;
  border-radius: 3px;
}

.scrollable-content::-webkit-scrollbar-track {
  background-color: #f4f4f5;
  border-radius: 3px;
}

/* 总题数统计固定在顶部 */
.total-stats {
  padding: 16px;
  background: #fff;
  border-bottom: 1px solid #f0f0f0;
}

/* 交卷按钮区域 */
.submit-exam-area {
  padding: 16px;
  background: #fff;
  border-top: 1px solid #f0f0f0;
  margin-top: auto;
  position: sticky;
  bottom: 0;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.submit-exam-button {
  width: 80%;
  height: 40px;
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 8px;
}

.submit-tip {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}

:deep(.submit-exam-button.el-button--primary) {
  background: #409eff;
  border-color: #409eff;
  box-shadow: 0 2px 6px rgba(64, 158, 255, 0.2);
}

:deep(.submit-exam-button.el-button--primary:hover) {
  background: #66b1ff;
  border-color: #66b1ff;
  box-shadow: 0 4px 12px rgba(64, 158, 255, 0.3);
}

/* 响应式调整 */
@media screen and (max-height: 768px) {
  .total-stats,
  .submit-exam-area,
  .status-legend {
    padding: 12px;
  }

  .scrollable-content {
    padding: 12px;
  }
}

/* 媒体查询 */
@media screen and (max-width: 1366px) {
  .exam-page {
    gap: 12px;
    padding: 12px;
  }

  .left-panel,
  .right-panel {
    width: 260px;
  }
}

@media screen and (min-width: 1920px) {
  .exam-page {
    gap: 24px;
    padding: 24px;
  }

  .left-panel,
  .right-panel {
    width: 320px;
  }
}

@media screen and (max-height: 768px) {
  .exam-page {
    height: calc(100vh - 80px);
  }
}

/* 打印样式 */
@media print {
  .exam-page {
    height: auto;
    padding: 0;
  }

  .left-panel,
  .right-panel {
    display: none;
  }

  .center-panel {
    width: 100%;
  }
}

/* 试信息列表样式 */
.exam-info {
  background: #f5f7fa;
  padding: 16px;
  border-radius: 8px;
  margin-bottom: 16px;
}

.time-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.info-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.time-label-row {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #909399;
}

.time-label-row .el-icon {
  font-size: 16px;
  color: #909399;
}

.time-label-row .label {
  font-size: 13px;
}

.time-value-row {
  padding-left: 24px; /* 与图标对齐 */
}

.time-value-row .value {
  font-size: 14px;
  font-weight: 500;
  color: #303133;
}

/* 更新考试时间区卡片样式 */
.exam-timer :deep(.el-card__body) {
  padding: 16px;
}

/* 确保时间信息在小幕上也能正常显示 */
@media screen and (max-width: 1366px) {
  .exam-info {
    padding: 12px;
  }

  .time-list {
    gap: 8px;
  }

  .time-value-row {
    padding-left: 20px;
  }
}

/* 总题数统计样式 */
.total-stats {
  background: #f5f7fa;
  padding: 16px;
  border-radius: 8px;
  /* margin-bottom: 20px; */
}

.total-header {
  margin-bottom: 12px;
}

.total-title {
  font-size: 16px;
  font-weight: bold;
  color: #303133;
}

.question-types-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}

.type-stat-item {
  background: #fff;
  padding: 8px;
  border-radius: 6px;
  text-align: center;
}

.type-name {
  display: block;
  margin-bottom: 4px;
  color: #606266;
  font-size: 13px;
}

.type-count {
  display: block;
  color: #409eff;
  font-weight: 500;
  font-size: 15px;
}

/* 题目状态区域样式 */
.question-status-sections {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.status-section {
  background: #fff;
  border-radius: 8px;
  padding: 20px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.05);
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
  padding-bottom: 12px;
  border-bottom: 1px solid #ebeef5;
}

.section-title {
  display: flex;
  align-items: center;
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.section-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.section-count,
.section-score {
  font-size: 13px;
  color: #606266;
  background: #f5f7fa;
  padding: 4px 12px;
  border-radius: 4px;
  font-weight: 500;
}

/* 题目网格样式 */
.status-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 10px;
  padding: 4px;
}

.status-item {
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  /* border: 1px solid #dcdfe6; */
  transition: all 0.25s ease;
  user-select: none;
}

/* 未答题状态 */
.status-item.unanswered {
  background: #f5f7fa;
  color: #909399;
  border-color: #dcdfe6;
}

/* 已答题状态 */
.status-item.answered {
  background: #f0f9eb;
  color: #67c23a;
  border-color: #67c23a;
}

/* 已标记状态 */
.status-item.marked {
  background: #fdf6ec;
  color: #e6a23c;
  border-color: #e6a23c;
}

/* 当前题目状态 */
.status-item.active {
  background: #ecf5ff;
  color: #409eff;
  border-color: #409eff;
  transform: scale(1.05);
  box-shadow: 0 2px 6px rgba(64, 158, 255, 0.2);
}

/* 悬浮效果 */
.status-item:hover:not(.active) {
  transform: translateY(-2px);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

/* 点击效果 */
.status-item:active {
  transform: scale(0.95);
}

/* 优化题型切换区域样式 */
.question-types-stats {
  margin: 16px 0;
  padding: 0 8px;
}

/* 适配不同屏幕尺寸 */
@media screen and (max-width: 1366px) {
  .scrollable-content {
    padding: 12px;
  }

  .status-section {
    padding: 16px;
  }

  .status-grid {
    gap: 8px;
  }

  .status-item {
    height: 32px;
    font-size: 13px;
  }
}

@media screen and (min-width: 1920px) {
  .scrollable-content {
    padding: 20px;
  }

  .status-section {
    padding: 24px;
  }

  .status-grid {
    gap: 12px;
  }

  .status-item {
    height: 40px;
    font-size: 15px;
  }
}

/* 状态图例样式 */
.status-legend {
  display: flex;
  justify-content: space-around;
  padding: 12px;
  /* background: #f5f7fa; */
  border-radius: 8px;
  margin: 10px 0px -5px 0px;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: #606266;
}

.legend-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}

.legend-dot.unanswered {
  background: #909399;
}

.legend-dot.marked {
  background: #e6a23c;
}

.legend-dot.answered {
  background: #67c23a;
}

/* 添加题型选择的样式 */
.type-stat-item {
  cursor: pointer;
  padding: 8px;
  border-radius: 6px;
  text-align: center;
  transition: all 0.3s;
  border: 1px solid transparent;
}

.type-stat-item:hover {
  background: #f5f7fa;
}

.type-stat-item.active {
  background: #ecf5ff;
  border-color: #409eff;
}

.type-stat-item.active .type-name,
.type-stat-item.active .type-count {
  color: #409eff;
}

/* 添加问答题样式 */
.question-essay {
  margin-top: 20px;
}

.question-essay :deep(.el-textarea__inner) {
  font-size: 14px;
  line-height: 1.6;
}

/* 状态栏样式优化 */
.status-header {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 32px; /* 固定高度确保垂直居中 */
}

.status-header .el-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  height: 20px; /* 设置固定高度 */
  line-height: 1; /* 重置行高 */
}

.status-header span {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
  line-height: 20px; /* 与图标高度一致 */
  display: inline-flex; /* 使用 inline-flex 确保文字垂直居中 */
  align-items: center;
}

/* 监控项样式优化 */
.item-label {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 24px; /* 固定高度确保垂直居中 */
}

.item-label .el-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  height: 16px; /* 设置固定高度 */
  line-height: 1; /* 重置行高 */
}

.item-label span {
  font-size: 14px;
  color: #606266;
  line-height: 16px; /* 与图标高度一致 */
  display: inline-flex; /* 使用 inline-flex 确保文字垂直居中 */
  align-items: center;
}
</style>
