<template>
  <div class="student-profile">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>个人信息</span>
          <el-button type="primary" @click="handleEdit">编辑信息</el-button>
        </div>
      </template>
      
      <el-descriptions :column="2" border>
        <el-descriptions-item label="学号">2021001001</el-descriptions-item>
        <el-descriptions-item label="姓名">张三</el-descriptions-item>
        <el-descriptions-item label="性别">男</el-descriptions-item>
        <el-descriptions-item label="年龄">20</el-descriptions-item>
        <el-descriptions-item label="班级">计算机2101</el-descriptions-item>
        <el-descriptions-item label="专业">计算机科学与技术</el-descriptions-item>
        <el-descriptions-item label="手机号码">13800138000</el-descriptions-item>
        <el-descriptions-item label="邮箱">zhangsan@example.com</el-descriptions-item>
      </el-descriptions>
    </el-card>
  </div>
</template>

<script setup>
const handleEdit = () => {
  console.log('编辑个人信息')
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style> 