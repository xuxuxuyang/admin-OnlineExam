<template>
  <div class="dashboard">
    <h2>欢迎使用在线考试系统</h2>
    <p>您可以在这里参加考试、查看历史记录等</p>
  </div>
</template>

<style scoped>
.dashboard {
  padding: 20px;
  background: #fff;
  border-radius: 8px;
}
</style> 