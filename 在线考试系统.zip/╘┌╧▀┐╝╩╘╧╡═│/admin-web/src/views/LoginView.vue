<template>
  <div class="login-container" @keypress="handleKeyPress">
    <div class="login-bg"></div>
    <div class="login-overlay"></div>

    <!-- 装饰性动画元素 -->
    <div class="floating-elements">
      <div class="circle c1"></div>
      <div class="circle c2"></div>
      <div class="circle c3"></div>
    </div>

    <div class="login-box">
      <div class="login-header">
        <el-icon class="sun-icon"><Sunny /></el-icon>
        <h2 class="login-title">在线考试系统</h2>
        <p class="subtitle">智慧教育 · 在线考试平台</p>
      </div>

      <el-form
        ref="loginFormRef"
        :model="loginForm"
        :rules="rules"
        @submit.prevent="handleLogin"
      >
        <el-form-item prop="username">
          <el-input
            v-model="loginForm.username"
            placeholder="请输入用户名"
            :prefix-icon="User"
            clearable
          />
        </el-form-item>

        <el-form-item prop="password">
          <el-input
            v-model="loginForm.password"
            type="password"
            placeholder="请输入密码"
            :prefix-icon="Lock"
            show-password
          />
        </el-form-item>

        <el-form-item prop="role">
          <div class="role-cards">
            <div
              class="role-card"
              :class="{ active: loginForm.role === 'student' }"
              @click="loginForm.role = 'student'"
            >
              <div class="icon-wrapper student">
                <el-icon><Reading /></el-icon>
              </div>
              <span>学生</span>
            </div>
            <div
              class="role-card"
              :class="{ active: loginForm.role === 'teacher' }"
              @click="loginForm.role = 'teacher'"
            >
              <div class="icon-wrapper teacher">
                <el-icon><Edit /></el-icon>
              </div>
              <span>教师</span>
            </div>
            <div
              class="role-card"
              :class="{ active: loginForm.role === 'admin' }"
              @click="loginForm.role = 'admin'"
            >
              <div class="icon-wrapper admin">
                <el-icon><Setting /></el-icon>
              </div>
              <span>教务/学校</span>
            </div>
          </div>
        </el-form-item>

        <el-button
          type="primary"
          class="login-btn"
          :loading="loading"
          @click="handleLogin"
        >
          {{ loading ? "登录中..." : "登 录" }}
        </el-button>
      </el-form>

      <div class="login-footer">
        <p>欢迎使用在线考试系统</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.login-container {
  height: 100vh;
  width: 100vw;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.login-bg {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-image: url("../../assets/img/login-bg.jpg");
  background-size: cover;
  background-position: center;
  animation: zoomBg 25s infinite alternate;
}

.login-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, rgba(0, 0, 0, 0.25), rgba(0, 0, 0, 0.18));
  backdrop-filter: blur(1.5px);
}

.floating-elements {
  position: absolute;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.circle {
  position: absolute;
  border-radius: 50%;
  background: linear-gradient(
    45deg,
    rgba(255, 255, 255, 0.13),
    rgba(255, 255, 255, 0.07)
  );
  backdrop-filter: blur(3.5px);
}

.c1 {
  width: 150px;
  height: 150px;
  top: 10%;
  left: 15%;
  animation: float 8s infinite ease-in-out;
}

.c2 {
  width: 100px;
  height: 100px;
  top: 60%;
  right: 15%;
  animation: float 6s infinite ease-in-out reverse;
}

.c3 {
  width: 80px;
  height: 80px;
  bottom: 10%;
  left: 25%;
  animation: float 7s infinite ease-in-out;
}

.login-box {
  width: 380px;
  padding: 32px;
  background: rgba(255, 255, 255, 0.96);
  border-radius: 16px;
  box-shadow: 0 8px 28px rgba(0, 0, 0, 0.12);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.92);
  animation: slideIn 0.8s cubic-bezier(0.2, 0.8, 0.2, 1);
  position: relative;
  z-index: 1;
}

.login-header {
  text-align: center;
  margin-bottom: 24px;
}

.login-logo {
  width: 100px;
  height: 100px;
  margin-bottom: 16px;
}

.login-title {
  font-size: 24px;
  color: #303133;
  margin-bottom: 8px;
  animation: fadeInUp 0.8s ease-out;
}

.login-btn {
  width: 100%;
  height: 40px;
  margin-top: 16px;
  font-size: 15px;
  transition: transform 0.2s;
}

.login-btn:hover {
  transform: translateY(-2px);
}

.role-cards {
  display: flex;
  gap: 16px;
  justify-content: space-between;
  margin: 8px 0;
  width: 100%;
}

.role-card {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 12px;
  min-width: 86px;
  height: 86px;
  background: #ffffff;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.3s ease;
  border: 1px solid #e4e7ed;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
}

.role-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  border-color: #c0c4cc;
}

.icon-wrapper {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  border-radius: 10px;
  margin-bottom: 6px;
  transition: all 0.3s ease;
}

.icon-wrapper .el-icon {
  font-size: 18px;
  color: #ffffff;
  line-height: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

/* 确保图标容器内的 svg 保持比例 */
:deep(.el-icon svg) {
  width: 50px;
  height: 50px;
  display: block;
}

/* 学生图标样式 - 更柔和的渐变 */
.icon-wrapper.student {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}

/* 教师图标样式 - 更柔和的渐变 */
.icon-wrapper.teacher {
  background: linear-gradient(135deg, #ff6b6b 0%, #ffc6c6 100%);
}

/* 管理员图标样式 - 更柔和的渐变 */
.icon-wrapper.admin {
  background: linear-gradient(135deg, #9890e3 0%, #b1a5f6 100%);
}

.role-card span {
  font-size: 13px;
  font-weight: 500;
  color: #606266;
  margin-top: 4px;
  line-height: 1;
}

.role-card.active {
  background: #f0f7ff;
  border-color: #409eff;
  box-shadow: 0 2px 12px rgba(64, 158, 255, 0.1);
}

.role-card.active span {
  color: #409eff;
  font-weight: 600;
}

.role-card.active .icon-wrapper {
  transform: scale(1.05);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* 动画关键帧 */
@keyframes zoomBg {
  0% {
    transform: scale(1);
  }
  100% {
    transform: scale(1.1);
  }
}

@keyframes float {
  0%,
  100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-20px);
  }
}

@keyframes slideIn {
  0% {
    opacity: 0;
    transform: translateY(20px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes rotateLogo {
  0% {
    opacity: 0;
    transform: rotate(-180deg) scale(0.3);
  }
  100% {
    opacity: 1;
    transform: rotate(0) scale(1);
  }
}

@keyframes fadeInUp {
  0% {
    opacity: 0;
    transform: translateY(20px);
  }
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 响应式适配 */
@media (max-width: 768px) {
  .login-box {
    width: 90%;
    max-width: 360px;
    padding: 24px;
  }

  .circle {
    display: none;
  }
}

.subtitle {
  color: #666;
  font-size: 13px;
  margin-top: 4px;
  letter-spacing: 1px;
  animation: fadeInUp 0.8s ease-out 0.2s both;
}

.login-footer {
  text-align: center;
  margin-top: 24px;
  color: #666;
  font-size: 12px;
}

/* 优化输入框样式 */
:deep(.el-input__wrapper) {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
  transition: all 0.3s ease;
  padding: 0 12px;
}

:deep(.el-input__wrapper:hover) {
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

:deep(.el-select__wrapper) {
  width: 100%;
}

/* 优化按钮样式 */
.login-btn {
  background: linear-gradient(135deg, #1890ff, #1677ff);
  border: none;
  height: 40px;
  font-size: 15px;
  letter-spacing: 4px;
  transition: all 0.3s ease;
}

.login-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(24, 144, 255, 0.3);
}

/* 优化选择框样式 */
:deep(.el-select-dropdown__item) {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
}

:deep(.el-select-dropdown__item .el-icon) {
  font-size: 16px;
  margin-right: 4px;
}

/* 优化输入框样式 */
:deep(.el-input__inner) {
  height: 36px;
}

.sun-icon {
  font-size: 48px;
  color: #f4b63e;
  margin-bottom: 16px;
  animation: rotate 20s linear infinite;
}

@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

/* 添加抖动动画 */
@keyframes shake {
  0%,
  100% {
    transform: translateX(0);
  }
  20%,
  60% {
    transform: translateX(-4px);
  }
  40%,
  80% {
    transform: translateX(4px);
  }
}

.shake {
  animation: shake 0.5s ease-in-out;
}

/* 移除表单项的错误状态样式 */
:deep(.el-form-item.is-error) {
  margin-bottom: 22px;
}

:deep(.el-form-item__error) {
  display: block;
}

.logo {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 30px;
}

.logo-icon {
  font-size: 32px;
  color: #409eff;
  margin-right: 8px;
}

.logo-text {
  font-size: 28px;
  font-weight: bold;
  color: #303133;
  margin-left: 4px;
}
</style>

<script setup>
import { test } from "../api/student";
import { ref } from "vue";
import { useRouter } from "vue-router";
import { ElMessage } from "element-plus";
import {
  User,
  UserFilled,
  Avatar,
  Lock,
  Sunny,
  Reading,
  Edit,
  Setting,
} from "@element-plus/icons-vue";
import { setupRoutes } from "../router";

const router = useRouter();
const loading = ref(false);
const loginFormRef = ref(null);

const loginForm = ref({
  username: "xuyang",
  password: "123456",
  role: "",
});

const rules = {
  username: [
    { required: true, message: "请输入用户名", trigger: "blur" },
    {
      min: 3,
      max: 20,
      message: "用户名长度在 3 到 20 个字符",
      trigger: "blur",
    },
  ],
  password: [
    { required: true, message: "请输入密码", trigger: "blur" },
    { min: 6, max: 20, message: "密码长度在 6 到 20 个字符", trigger: "blur" },
  ],
};

const validateRole = () => {
  if (!loginForm.value.role) {
    document.querySelector(".role-cards").classList.add("shake");
    ElMessage({
      message: "请选择您的角色",
      type: "info",
      offset: 80,
    });
    setTimeout(() => {
      document.querySelector(".role-cards").classList.remove("shake");
    }, 500);
    return false;
  }
  return true;
};

const handleLogin = async () => {
  if (!loginFormRef.value) return;

  try {
    await loginFormRef.value.validate();

    if (!validateRole()) return;

    loading.value = true;

    // TODO: 调用登录API
    // await new Promise((resolve) => setTimeout(resolve, 10));

    // 存储用户信息
    localStorage.setItem("userRole", loginForm.value.role);
    localStorage.setItem("userName", loginForm.value.username);

    // 设置路由
    setupRoutes(loginForm.value.role);

    ElMessage.success("登录成功");

    // 根据角色跳转到不同的首页
    const homePath =
      loginForm.value.role === "admin"
        ? "/system/exam"
        : loginForm.value.role === "student"
        ? "/student/exam"
        : "/teacher/marking";
    router.push(homePath);
  } catch (error) {
    if (error.message) {
      ElMessage.error(error.message);
    }
  } finally {
    loading.value = false;
  }
};
// 添加回车键登录
const handleKeyPress = (e) => {
  if (e.key === "Enter") {
    handleLogin();
  }
};
</script>
