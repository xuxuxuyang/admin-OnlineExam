<template>
  <div class="grade-score">
    <el-card>
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <span>年级成绩管理</span>
            <el-select v-model="currentGrade" placeholder="选择年级" style="width: 200px; margin-left: 16px">
              <el-option
                v-for="item in gradeList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-select v-model="currentSubject" placeholder="选择科目" style="width: 200px; margin-left: 16px">
              <el-option
                v-for="item in subjectList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
          <el-button type="primary" @click="handleExport">导出成绩</el-button>
        </div>
      </template>

      <!-- 成绩统计卡片 -->
      <el-row :gutter="20" class="statistics-row">
        <el-col :span="6" v-for="card in statisticsCards" :key="card.title">
          <el-card shadow="hover" class="statistics-card">
            <div class="card-content">
              <div class="card-value">{{ card.value }}</div>
              <div class="card-title">{{ card.title }}</div>
            </div>
          </el-card>
        </el-col>
      </el-row>

      <!-- 成绩分布图表 -->
      <el-row :gutter="20" class="chart-row">
        <el-col :span="12">
          <el-card>
            <template #header>
              <div class="chart-header">成绩分布</div>
            </template>
            <div ref="scoreDistributionRef" style="height: 300px"></div>
          </el-card>
        </el-col>
        <el-col :span="12">
          <el-card>
            <template #header>
              <div class="chart-header">班级对比</div>
            </template>
            <div ref="classComparisonRef" style="height: 300px"></div>
          </el-card>
        </el-col>
      </el-row>

      <!-- 成绩列表 -->
      <el-table :data="scoreList" border stripe class="score-table">
        <el-table-column prop="className" label="班级" width="120" />
        <el-table-column prop="studentCount" label="学生人数" width="100" />
        <el-table-column prop="avgScore" label="平均���" width="100" sortable />
        <el-table-column prop="maxScore" label="最高分" width="100" sortable />
        <el-table-column prop="minScore" label="最低分" width="100" sortable />
        <el-table-column prop="passRate" label="及格率" width="100">
          <template #default="scope">
            {{ scope.row.passRate }}%
          </template>
        </el-table-column>
        <el-table-column prop="excellentRate" label="优秀率" width="100">
          <template #default="scope">
            {{ scope.row.excellentRate }}%
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleDetail(scope.row)">查看详情</el-button>
            <el-button size="small" type="primary" @click="handleAnalysis(scope.row)">成绩分析</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import * as echarts from 'echarts'

const currentGrade = ref('')
const currentSubject = ref('')

const gradeList = [
  { label: '2021级', value: '2021' },
  { label: '2022级', value: '2022' },
  { label: '2023级', value: '2023' }
]

const subjectList = [
  { label: '高等数学', value: 'math' },
  { label: '大学英语', value: 'english' },
  { label: '计算机基础', value: 'computer' }
]

const statisticsCards = [
  { title: '年级平均分', value: '83.5' },
  { title: '最高分', value: '98' },
  { title: '最低分', value: '62' },
  { title: '及格率', value: '93.2%' }
]

const scoreList = ref([
  {
    className: '计算机2101',
    studentCount: 45,
    avgScore: 85.5,
    maxScore: 98,
    minScore: 65,
    passRate: 95.6,
    excellentRate: 35.6
  },
  {
    className: '计算机2102',
    studentCount: 42,
    avgScore: 82.8,
    maxScore: 96,
    minScore: 62,
    passRate: 92.8,
    excellentRate: 31.0
  }
])

const scoreDistributionRef = ref(null)
const classComparisonRef = ref(null)

onMounted(() => {
  // 初始化成绩分布图表
  const scoreDistribution = echarts.init(scoreDistributionRef.value)
  scoreDistribution.setOption({
    title: { text: '成绩分布' },
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: ['<60', '60-70', '70-80', '80-90', '90-100']
    },
    yAxis: { type: 'value' },
    series: [{
      data: [5, 15, 30, 35, 15],
      type: 'bar'
    }]
  })

  // 初始化班级对比图表
  const classComparison = echarts.init(classComparisonRef.value)
  classComparison.setOption({
    title: { text: '班级对比' },
    tooltip: { trigger: 'axis' },
    legend: {
      data: ['平均分', '及格率', '优秀率']
    },
    xAxis: {
      type: 'category',
      data: ['计算机2101', '计算机2102', '计算机2103']
    },
    yAxis: { type: 'value' },
    series: [
      {
        name: '平均分',
        type: 'bar',
        data: [85.5, 82.8, 84.2]
      },
      {
        name: '及格率',
        type: 'line',
        data: [95.6, 92.8, 94.5]
      },
      {
        name: '优秀率',
        type: 'line',
        data: [35.6, 31.0, 33.5]
      }
    ]
  })

  // 监听窗口大小变化
  window.addEventListener('resize', () => {
    scoreDistribution.resize()
    classComparison.resize()
  })
})

const handleExport = () => {
  console.log('导出成绩')
}

const handleDetail = (score) => {
  console.log('查看成绩详情', score)
}

const handleAnalysis = (score) => {
  console.log('成绩分析', score)
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
}

.statistics-row {
  margin-bottom: 20px;
}

.statistics-card {
  text-align: center;
}

.card-value {
  font-size: 24px;
  font-weight: bold;
  color: #1890ff;
}

.card-title {
  margin-top: 8px;
  color: #666;
}

.chart-row {
  margin-bottom: 20px;
}

.chart-header {
  font-weight: bold;
}

.score-table {
  margin-top: 20px;
}
</style> 