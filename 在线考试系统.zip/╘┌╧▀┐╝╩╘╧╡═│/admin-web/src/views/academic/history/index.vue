<template>
  <div class="academic-history">
    <el-card>
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <span>历史答卷管理</span>
            <el-select v-model="currentExam" placeholder="选择考试" style="width: 300px; margin-left: 16px">
              <el-option
                v-for="item in examList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-select v-model="currentClass" placeholder="选择班级" style="width: 200px; margin-left: 16px">
              <el-option
                v-for="item in classList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
          <div class="header-right">
            <el-button type="success" @click="handleBatchDownload">批量下载</el-button>
            <el-button type="primary" @click="handleExport">导出记录</el-button>
          </div>
        </div>
      </template>

      <!-- 统计卡片 -->
      <el-row :gutter="20" class="statistics-row">
        <el-col :span="6" v-for="card in statisticsCards" :key="card.title">
          <el-card shadow="hover" class="statistics-card">
            <div class="card-content">
              <div class="card-value">{{ card.value }}</div>
              <div class="card-title">{{ card.title }}</div>
            </div>
          </el-card>
        </el-col>
      </el-row>

      <!-- 答卷列表 -->
      <el-table 
        :data="paperList" 
        border 
        stripe 
        class="paper-table"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55" />
        <el-table-column prop="studentName" label="学生姓名" width="120" />
        <el-table-column prop="studentId" label="学号" width="120" />
        <el-table-column prop="className" label="班级" width="120" />
        <el-table-column prop="examName" label="考试名称" />
        <el-table-column prop="submitTime" label="提交时间" width="180" />
        <el-table-column prop="score" label="得分" width="100" sortable>
          <template #default="scope">
            <span :class="getScoreClass(scope.row.score)">{{ scope.row.score }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="250" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleView(scope.row)">查看答卷</el-button>
            <el-button size="small" type="primary" @click="handleAnalysis(scope.row)">答题分析</el-button>
            <el-button size="small" type="success" @click="handleDownload(scope.row)">下载</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 答题分析对话框 -->
    <el-dialog
      v-model="analysisDialogVisible"
      title="答题分析"
      width="800px"
    >
      <el-descriptions :column="2" border>
        <el-descriptions-item label="学生姓名">{{ currentPaper.studentName }}</el-descriptions-item>
        <el-descriptions-item label="学号">{{ currentPaper.studentId }}</el-descriptions-item>
        <el-descriptions-item label="考试名称">{{ currentPaper.examName }}</el-descriptions-item>
        <el-descriptions-item label="提交时间">{{ currentPaper.submitTime }}</el-descriptions-item>
        <el-descriptions-item label="得分">{{ currentPaper.score }}</el-descriptions-item>
        <el-descriptions-item label="用时">{{ currentPaper.duration }}分钟</el-descriptions-item>
      </el-descriptions>

      <!-- 答题情况统计图表 -->
      <div id="analysisChartRef" ref="analysisChartRef" style="height: 300px; margin-top: 20px"></div>

      <!-- 题型得分统计 -->
      <el-table :data="questionTypeStats" border stripe class="stats-table">
        <el-table-column prop="type" label="题型" />
        <el-table-column prop="count" label="题目数量" />
        <el-table-column prop="correctCount" label="正确数量" />
        <el-table-column prop="score" label="得分" />
        <el-table-column prop="totalScore" label="总分" />
        <el-table-column prop="accuracy" label="正确率">
          <template #default="scope">
            {{ scope.row.accuracy }}%
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick } from 'vue'
import { ElMessage } from 'element-plus'
import * as echarts from 'echarts'

const currentExam = ref('')
const currentClass = ref('')
const analysisDialogVisible = ref(false)
const selectedPapers = ref([])
const currentPaper = ref({})
const analysisChartRef = ref(null)

const examList = [
  { label: '2024年春季高等数学期末考试', value: '1' },
  { label: '2024年春季大学英语四级考试', value: '2' }
]

const classList = [
  { label: '计算机2101', value: '2101' },
  { label: '计算机2102', value: '2102' }
]

const statisticsCards = [
  { title: '总答卷数', value: '86' },
  { title: '平均分', value: '82.5' },
  { title: '最高分', value: '98' },
  { title: '及格率', value: '92.3%' }
]

const paperList = ref([
  {
    studentName: '张三',
    studentId: '2021001',
    className: '计算机2101',
    examName: '2024年春季高等数学期末考试',
    submitTime: '2024-03-20 10:30:00',
    score: 85,
    status: '已批改',
    duration: 110
  },
  {
    studentName: '李四',
    studentId: '2021002',
    className: '计算机2101',
    examName: '2024年春季高等数学期末考试',
    submitTime: '2024-03-20 10:25:00',
    score: 92,
    status: '已批改',
    duration: 95
  }
])

const questionTypeStats = ref([
  { type: '单选题', count: 20, correctCount: 18, score: 36, totalScore: 40, accuracy: 90 },
  { type: '多选题', count: 10, correctCount: 8, score: 24, totalScore: 30, accuracy: 80 },
  { type: '判断题', count: 10, correctCount: 9, score: 9, totalScore: 10, accuracy: 90 },
  { type: '���答题', count: 2, correctCount: 1.5, score: 16, totalScore: 20, accuracy: 75 }
])

const getScoreClass = (score) => {
  if (score >= 90) return 'score-excellent'
  if (score >= 80) return 'score-good'
  if (score >= 60) return 'score-pass'
  return 'score-fail'
}

const getStatusType = (status) => {
  const typeMap = {
    '未批改': 'info',
    '批改中': 'warning',
    '已批改': 'success'
  }
  return typeMap[status]
}

const handleSelectionChange = (selection) => {
  selectedPapers.value = selection
}

const handleView = (paper) => {
  console.log('查看答卷', paper)
}

const handleAnalysis = async (paper) => {
  currentPaper.value = paper
  analysisDialogVisible.value = true

  await nextTick()
  const analysisChart = echarts.init(analysisChartRef.value)
  analysisChart.setOption({
    title: { text: '答题情况分析' },
    tooltip: { trigger: 'axis' },
    legend: {
      data: ['得分率', '用时占比']
    },
    xAxis: {
      type: 'category',
      data: ['单选题', '多选题', '判断题', '简答题']
    },
    yAxis: { type: 'value' },
    series: [
      {
        name: '得分率',
        type: 'bar',
        data: [90, 80, 90, 75]
      },
      {
        name: '用时占比',
        type: 'line',
        data: [30, 25, 15, 30]
      }
    ]
  })

  window.addEventListener('resize', () => {
    analysisChart.resize()
  })
}

const handleDownload = (paper) => {
  console.log('下载答卷', paper)
  ElMessage.success('开始下载答卷')
}

const handleBatchDownload = () => {
  if (selectedPapers.value.length === 0) {
    ElMessage.warning('请选择要下载的答卷')
    return
  }
  console.log('批量下载答卷', selectedPapers.value)
  ElMessage.success(`开始下载 ${selectedPapers.value.length} 份答卷`)
}

const handleExport = () => {
  console.log('导出记录')
  ElMessage.success('开始导出记录')
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
}

.header-right {
  display: flex;
  gap: 16px;
}

.statistics-row {
  margin-bottom: 20px;
}

.statistics-card {
  text-align: center;
}

.card-value {
  font-size: 24px;
  font-weight: bold;
  color: #1890ff;
}

.card-title {
  margin-top: 8px;
  color: #666;
}

.paper-table {
  margin-top: 20px;
}

.stats-table {
  margin-top: 20px;
}

.score-excellent {
  color: #67c23a;
  font-weight: bold;
}

.score-good {
  color: #409eff;
  font-weight: bold;
}

.score-pass {
  color: #e6a23c;
  font-weight: bold;
}

.score-fail {
  color: #f56c6c;
  font-weight: bold;
}
</style> 