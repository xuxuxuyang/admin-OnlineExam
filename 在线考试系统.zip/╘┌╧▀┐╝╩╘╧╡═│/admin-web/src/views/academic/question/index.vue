<template>
  <div class="academic-question">
    <el-card>
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <span>题库管理</span>
            <el-radio-group v-model="questionType" class="type-filter">
              <el-radio-button label="all">全部</el-radio-button>
              <el-radio-button label="single">单选题</el-radio-button>
              <el-radio-button label="multiple">多选题</el-radio-button>
              <el-radio-button label="judge">判断题</el-radio-button>
              <el-radio-button label="essay">简答题</el-radio-button>
            </el-radio-group>
            <el-select v-model="currentSubject" placeholder="选择科目" style="width: 200px; margin-left: 16px">
              <el-option
                v-for="item in subjectList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
          <el-button type="primary" @click="handleAdd">新增题目</el-button>
        </div>
      </template>

      <!-- 题目列表 -->
      <el-table :data="questionList" border stripe>
        <el-table-column prop="type" label="题型" width="100">
          <template #default="scope">
            <el-tag :type="getTypeTag(scope.row.type)">
              {{ scope.row.type }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="content" label="题目内容" show-overflow-tooltip />
        <el-table-column prop="subject" label="所属科目" width="120" />
        <el-table-column prop="difficulty" label="难度" width="120">
          <template #default="scope">
            <el-rate
              v-model="scope.row.difficulty"
              disabled
              text-color="#ff9900"
            />
          </template>
        </el-table-column>
        <el-table-column prop="creator" label="创建人" width="120" />
        <el-table-column prop="createTime" label="创建时间" width="180" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="250" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handlePreview(scope.row)">预览</el-button>
            <el-button 
              size="small" 
              type="primary" 
              @click="handleEdit(scope.row)"
              :disabled="scope.row.status === '已审核'"
            >
              编辑
            </el-button>
            <el-button 
              size="small" 
              type="success" 
              @click="handleAudit(scope.row)"
              :disabled="scope.row.status === '已审核'"
            >
              审核
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增/编辑题目对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogType === 'add' ? '新增题目' : '编辑题目'"
      width="700px"
    >
      <el-form
        ref="questionFormRef"
        :model="questionForm"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="题型" prop="type">
          <el-select v-model="questionForm.type" placeholder="请选择题型" style="width: 100%">
            <el-option label="单选题" value="single" />
            <el-option label="多选��" value="multiple" />
            <el-option label="判断题" value="judge" />
            <el-option label="简答题" value="essay" />
          </el-select>
        </el-form-item>
        <el-form-item label="科目" prop="subject">
          <el-select v-model="questionForm.subject" placeholder="请选择科目" style="width: 100%">
            <el-option label="高等数学" value="高等数学" />
            <el-option label="大学英语" value="大学英语" />
            <el-option label="计算机基础" value="计算机基础" />
          </el-select>
        </el-form-item>
        <el-form-item label="题目内容" prop="content">
          <el-input
            v-model="questionForm.content"
            type="textarea"
            :rows="3"
            placeholder="请输入题目内容"
          />
        </el-form-item>
        <el-form-item label="选项" v-if="['single', 'multiple'].includes(questionForm.type)">
          <div v-for="(option, index) in questionForm.options" :key="index" class="option-item">
            <el-input v-model="option.content" placeholder="请输入选项内容">
              <template #prepend>{{ String.fromCharCode(65 + index) }}</template>
            </el-input>
            <el-checkbox 
              v-if="questionForm.type === 'multiple'"
              v-model="option.isCorrect"
            />
            <el-radio 
              v-else
              v-model="questionForm.answer"
              :label="String.fromCharCode(65 + index)"
            />
          </div>
          <div class="option-actions">
            <el-button type="primary" link @click="addOption">添加选项</el-button>
            <el-button type="danger" link @click="removeOption">删除选项</el-button>
          </div>
        </el-form-item>
        <el-form-item label="答案" prop="answer" v-if="questionForm.type === 'judge'">
          <el-radio-group v-model="questionForm.answer">
            <el-radio label="true">正确</el-radio>
            <el-radio label="false">错误</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="参考答案" prop="answer" v-if="questionForm.type === 'essay'">
          <el-input
            v-model="questionForm.answer"
            type="textarea"
            :rows="3"
            placeholder="请输入参考答案"
          />
        </el-form-item>
        <el-form-item label="分值" prop="score">
          <el-input-number v-model="questionForm.score" :min="1" :max="100" />
        </el-form-item>
        <el-form-item label="难度" prop="difficulty">
          <el-rate v-model="questionForm.difficulty" />
        </el-form-item>
        <el-form-item label="解析" prop="analysis">
          <el-input
            v-model="questionForm.analysis"
            type="textarea"
            :rows="3"
            placeholder="请输入题目解析"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="handleSubmit" :loading="loading">
            确定
          </el-button>
        </span>
      </template>
    </el-dialog>

    <!-- 审核对话框 -->
    <el-dialog
      v-model="auditDialogVisible"
      title="题目审核"
      width="500px"
    >
      <el-form
        ref="auditFormRef"
        :model="auditForm"
        :rules="auditRules"
        label-width="100px"
      >
        <el-form-item label="审核结果" prop="result">
          <el-radio-group v-model="auditForm.result">
            <el-radio label="pass">通过</el-radio>
            <el-radio label="reject">不通过</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="审核意见" prop="comment">
          <el-input
            v-model="auditForm.comment"
            type="textarea"
            :rows="3"
            placeholder="请输入审核意见"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="auditDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="handleAuditSubmit" :loading="loading">
            确定
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const questionType = ref('all')
const currentSubject = ref('')
const dialogVisible = ref(false)
const auditDialogVisible = ref(false)
const dialogType = ref('add')
const loading = ref(false)
const questionFormRef = ref(null)
const auditFormRef = ref(null)

const subjectList = [
  { label: '高等数学', value: 'math' },
  { label: '大学英语', value: 'english' },
  { label: '计算机基础', value: 'computer' }
]

const questionForm = ref({
  type: '',
  subject: '',
  content: '',
  options: [
    { content: '', isCorrect: false },
    { content: '', isCorrect: false },
    { content: '', isCorrect: false },
    { content: '', isCorrect: false }
  ],
  answer: '',
  score: 5,
  difficulty: 3,
  analysis: ''
})

const auditForm = ref({
  result: 'pass',
  comment: ''
})

const rules = {
  type: [
    { required: true, message: '请选择题型', trigger: 'change' }
  ],
  subject: [
    { required: true, message: '请选择科目', trigger: 'change' }
  ],
  content: [
    { required: true, message: '请输入题目内容', trigger: 'blur' }
  ],
  answer: [
    { required: true, message: '请设置正确答案', trigger: 'change' }
  ],
  score: [
    { required: true, message: '请设置分值', trigger: 'change' }
  ]
}

const auditRules = {
  result: [
    { required: true, message: '请选择审核结果', trigger: 'change' }
  ],
  comment: [
    { required: true, message: '请输入审核意见', trigger: 'blur' }
  ]
}

const questionList = ref([
  {
    id: 1,
    type: '单选题',
    content: '以下哪个不是JavaScript的数据类型？',
    subject: '计算机基础',
    difficulty: 3,
    creator: '张老师',
    createTime: '2024-01-15 10:00:00',
    status: '待审核'
  },
  {
    id: 2,
    type: '多选题',
    content: '以下哪些是HTTP请求方法？',
    subject: '计算机网络',
    difficulty: 4,
    creator: '李老师',
    createTime: '2024-01-16 14:30:00',
    status: '已审核'
  }
])

const getTypeTag = (type) => {
  const typeMap = {
    '单选题': '',
    '多选题': 'success',
    '判断题': 'warning',
    '简答题': 'info'
  }
  return typeMap[type]
}

const getStatusType = (status) => {
  const typeMap = {
    '待审核': 'info',
    '已审核': 'success',
    '未通过': 'danger'
  }
  return typeMap[status]
}

const addOption = () => {
  questionForm.value.options.push({ content: '', isCorrect: false })
}

const removeOption = () => {
  if (questionForm.value.options.length > 2) {
    questionForm.value.options.pop()
  }
}

const handleAdd = () => {
  dialogType.value = 'add'
  questionForm.value = {
    type: '',
    subject: '',
    content: '',
    options: [
      { content: '', isCorrect: false },
      { content: '', isCorrect: false },
      { content: '', isCorrect: false },
      { content: '', isCorrect: false }
    ],
    answer: '',
    score: 5,
    difficulty: 3,
    analysis: ''
  }
  dialogVisible.value = true
}

const handlePreview = (question) => {
  console.log('预览题目', question)
}

const handleEdit = (question) => {
  dialogType.value = 'edit'
  questionForm.value = { ...question }
  dialogVisible.value = true
}

const handleAudit = (question) => {
  auditForm.value = {
    result: 'pass',
    comment: ''
  }
  auditDialogVisible.value = true
}

const handleSubmit = async () => {
  if (!questionFormRef.value) return
  
  await questionFormRef.value.validate(async (valid, fields) => {
    if (valid) {
      loading.value = true
      try {
        await new Promise(resolve => setTimeout(resolve, 1000))
        
        if (dialogType.value === 'add') {
          console.log('新增题目', questionForm.value)
          ElMessage.success('新增题目成功')
        } else {
          console.log('编辑题目', questionForm.value)
          ElMessage.success('编辑题目成功')
        }
        dialogVisible.value = false
      } catch (error) {
        console.error('操作失败:', error)
      } finally {
        loading.value = false
      }
    }
  })
}

const handleAuditSubmit = async () => {
  if (!auditFormRef.value) return
  
  await auditFormRef.value.validate(async (valid, fields) => {
    if (valid) {
      loading.value = true
      try {
        await new Promise(resolve => setTimeout(resolve, 1000))
        console.log('审核题目', auditForm.value)
        ElMessage.success('审核完成')
        auditDialogVisible.value = false
      } catch (error) {
        console.error('操作失败:', error)
      } finally {
        loading.value = false
      }
    }
  })
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 20px;
}

.type-filter {
  margin-left: 20px;
}

.option-item {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}

.option-actions {
  margin-top: 10px;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
</style> 