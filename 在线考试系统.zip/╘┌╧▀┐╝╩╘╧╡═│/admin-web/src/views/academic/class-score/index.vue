<template>
  <div class="class-score">
    <el-card>
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <span>班级成绩管理</span>
            <el-select v-model="currentClass" placeholder="选择班级" style="width: 200px; margin-left: 16px">
              <el-option
                v-for="item in classList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-select v-model="currentSubject" placeholder="选择科目" style="width: 200px; margin-left: 16px">
              <el-option
                v-for="item in subjectList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
          <el-button type="primary" @click="handleExport">导出成绩</el-button>
        </div>
      </template>

      <!-- 成绩统计卡片 -->
      <el-row :gutter="20" class="statistics-row">
        <el-col :span="6" v-for="card in statisticsCards" :key="card.title">
          <el-card shadow="hover" class="statistics-card">
            <div class="card-content">
              <div class="card-value">{{ card.value }}</div>
              <div class="card-title">{{ card.title }}</div>
            </div>
          </el-card>
        </el-col>
      </el-row>

      <!-- 成绩分布图表 -->
      <el-row :gutter="20" class="chart-row">
        <el-col :span="12">
          <el-card>
            <template #header>
              <div class="chart-header">成绩分布</div>
            </template>
            <div ref="scoreDistributionRef" style="height: 300px"></div>
          </el-card>
        </el-col>
        <el-col :span="12">
          <el-card>
            <template #header>
              <div class="chart-header">成绩趋势</div>
            </template>
            <div ref="scoreTrendRef" style="height: 300px"></div>
          </el-card>
        </el-col>
      </el-row>

      <!-- 成绩列表 -->
      <el-table :data="scoreList" border stripe class="score-table">
        <el-table-column prop="studentName" label="学生姓名" width="120" />
        <el-table-column prop="studentId" label="学号" width="120" />
        <el-table-column prop="examName" label="考试名称" />
        <el-table-column prop="score" label="得分" width="100" sortable>
          <template #default="scope">
            <span :class="getScoreClass(scope.row.score)">{{ scope.row.score }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="classRank" label="班级排名" width="100" sortable />
        <el-table-column prop="gradeRank" label="年级排名" width="100" sortable />
        <el-table-column prop="examTime" label="考试时间" width="180" />
        <el-table-column label="操作" width="180" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleDetail(scope.row)">查看详情</el-button>
            <el-button size="small" type="primary" @click="handleAnalysis(scope.row)">成绩分析</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import * as echarts from 'echarts'

const currentClass = ref('')
const currentSubject = ref('')

const classList = [
  { label: '计算机2101', value: '2101' },
  { label: '计算机2102', value: '2102' }
]

const subjectList = [
  { label: '高等数学', value: 'math' },
  { label: '大学英语', value: 'english' },
  { label: '计算机基础', value: 'computer' }
]

const statisticsCards = [
  { title: '班级平均分', value: '82.5' },
  { title: '最高分', value: '98' },
  { title: '最低分', value: '65' },
  { title: '及格率', value: '92.3%' }
]

const scoreList = ref([
  {
    studentName: '张三',
    studentId: '2021001',
    examName: '2024年春季高等数学期末考试',
    score: 85,
    classRank: 15,
    gradeRank: 45,
    examTime: '2024-03-20'
  },
  {
    studentName: '李四',
    studentId: '2021002',
    examName: '2024年春季高等数学期末考试',
    score: 92,
    classRank: 5,
    gradeRank: 12,
    examTime: '2024-03-20'
  }
])

const scoreDistributionRef = ref(null)
const scoreTrendRef = ref(null)

onMounted(() => {
  // 初始化成绩分布图表
  const scoreDistribution = echarts.init(scoreDistributionRef.value)
  scoreDistribution.setOption({
    title: { text: '成绩分布' },
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: ['<60', '60-70', '70-80', '80-90', '90-100']
    },
    yAxis: { type: 'value' },
    series: [{
      data: [5, 15, 30, 35, 15],
      type: 'bar'
    }]
  })

  // 初始化成绩趋势图表
  const scoreTrend = echarts.init(scoreTrendRef.value)
  scoreTrend.setOption({
    title: { text: '成绩趋势' },
    tooltip: { trigger: 'axis' },
    legend: {
      data: ['平均分', '最高分', '最低分']
    },
    xAxis: {
      type: 'category',
      data: ['第一次', '第二次', '第三次', '第四次', '第五次']
    },
    yAxis: { type: 'value' },
    series: [
      {
        name: '平均分',
        type: 'line',
        data: [82, 85, 83, 86, 84]
      },
      {
        name: '最高分',
        type: 'line',
        data: [95, 98, 96, 97, 95]
      },
      {
        name: '最低分',
        type: 'line',
        data: [65, 68, 62, 70, 66]
      }
    ]
  })

  // 监听窗口大小变化
  window.addEventListener('resize', () => {
    scoreDistribution.resize()
    scoreTrend.resize()
  })
})

const getScoreClass = (score) => {
  if (score >= 90) return 'score-excellent'
  if (score >= 80) return 'score-good'
  if (score >= 60) return 'score-pass'
  return 'score-fail'
}

const handleExport = () => {
  console.log('导出成绩')
}

const handleDetail = (score) => {
  console.log('查看成绩详情', score)
}

const handleAnalysis = (score) => {
  console.log('成绩分析', score)
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
}

.statistics-row {
  margin-bottom: 20px;
}

.statistics-card {
  text-align: center;
}

.card-value {
  font-size: 24px;
  font-weight: bold;
  color: #1890ff;
}

.card-title {
  margin-top: 8px;
  color: #666;
}

.chart-row {
  margin-bottom: 20px;
}

.chart-header {
  font-weight: bold;
}

.score-table {
  margin-top: 20px;
}

.score-excellent {
  color: #67c23a;
  font-weight: bold;
}

.score-good {
  color: #409eff;
  font-weight: bold;
}

.score-pass {
  color: #e6a23c;
  font-weight: bold;
}

.score-fail {
  color: #f56c6c;
  font-weight: bold;
}
</style> 