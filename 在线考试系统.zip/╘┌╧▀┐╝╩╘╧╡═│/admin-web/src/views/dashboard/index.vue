<template>
  <div class="dashboard">
    <!-- 数据概览卡片 -->
    <el-row :gutter="20">
      <el-col :span="6" v-for="card in cards" :key="card.title">
        <el-card shadow="hover" class="data-card">
          <div class="card-content">
            <el-icon class="card-icon" :class="card.type">
              <component :is="card.icon" />
            </el-icon>
            <div class="card-info">
              <div class="card-title">{{ card.title }}</div>
              <div class="card-value">{{ card.value }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 图表区域 -->
    <el-row :gutter="20" class="chart-row">
      <el-col :span="16">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>访问趋势</span>
            </div>
          </template>
          <div ref="lineChartRef" style="width: 100%; height: 350px;"></div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card>
          <template #header>
            <div class="card-header">
              <span>访问来源</span>
            </div>
          </template>
          <div ref="pieChartRef" style="width: 100%; height: 350px;"></div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 系统信息 -->
    <el-card class="system-card">
      <template #header>
        <div class="card-header">
          <span>系统信息</span>
        </div>
      </template>
      <el-descriptions :column="3" border>
        <el-descriptions-item label="系统版本">v1.0.0</el-descriptions-item>
        <el-descriptions-item label="Node版本">v16.14.0</el-descriptions-item>
        <el-descriptions-item label="操作系统">Windows 10</el-descriptions-item>
        <el-descriptions-item label="内存使用">4GB/8GB</el-descriptions-item>
        <el-descriptions-item label="CPU使用率">45%</el-descriptions-item>
        <el-descriptions-item label="运行时长">7天</el-descriptions-item>
      </el-descriptions>
    </el-card>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import * as echarts from 'echarts'
import {
  User,
  View,
  Ticket,
  Message
} from '@element-plus/icons-vue'

// 数据卡片
const cards = [
  {
    title: '用户总数',
    value: '1,234',
    icon: User,
    type: 'success'
  },
  {
    title: '今日访问',
    value: '423',
    icon: View,
    type: 'primary'
  },
  {
    title: '待处理工单',
    value: '12',
    icon: Ticket,
    type: 'warning'
  },
  {
    title: '未读消息',
    value: '3',
    icon: Message,
    type: 'danger'
  }
]

// 图表实例
const lineChartRef = ref(null)
const pieChartRef = ref(null)

// 保存图表实例
let lineChart = null
let pieChart = null

// 初始化折线图
const initLineChart = () => {
  if (lineChartRef.value) {
    lineChart = echarts.init(lineChartRef.value)
    lineChart.setOption({
      tooltip: {
        trigger: 'axis'
      },
      grid: {
        left: '3%',
        right: '4%',
        bottom: '3%',
        containLabel: true
      },
      xAxis: {
        type: 'category',
        boundaryGap: false,
        data: ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
      },
      yAxis: {
        type: 'value'
      },
      series: [
        {
          name: '访问量',
          type: 'line',
          smooth: true,
          data: [120, 132, 101, 134, 90, 230, 210],
          areaStyle: {
            opacity: 0.3
          },
          itemStyle: {
            color: '#409EFF'
          }
        }
      ]
    })
  }
}

// 初始化饼图
const initPieChart = () => {
  if (pieChartRef.value) {
    pieChart = echarts.init(pieChartRef.value)
    pieChart.setOption({
      tooltip: {
        trigger: 'item'
      },
      legend: {
        orient: 'vertical',
        left: 'left'
      },
      series: [
        {
          name: '访问来源',
          type: 'pie',
          radius: '70%',
          data: [
            { value: 1048, name: '搜索引擎' },
            { value: 735, name: '直接访问' },
            { value: 580, name: '邮件营销' },
            { value: 484, name: '联盟广告' }
          ],
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    })
  }
}

// 处理窗口大小变化
const handleResize = () => {
  lineChart?.resize()
  pieChart?.resize()
}

onMounted(() => {
  // 延迟初始化，确保DOM已经渲染
  setTimeout(() => {
    initLineChart()
    initPieChart()
    window.addEventListener('resize', handleResize)
  }, 0)
})

// 清理事件监听
onUnmounted(() => {
  window.removeEventListener('resize', handleResize)
  lineChart?.dispose()
  pieChart?.dispose()
})
</script>

<style scoped>
.dashboard {
  padding: 20px;
}

.data-card {
  margin-bottom: 20px;
}

.card-content {
  display: flex;
  align-items: center;
}

.card-icon {
  font-size: 48px;
  margin-right: 16px;
  padding: 12px;
  border-radius: 8px;
}

.success {
  color: #67c23a;
  background-color: #f0f9eb;
}

.primary {
  color: #409eff;
  background-color: #ecf5ff;
}

.warning {
  color: #e6a23c;
  background-color: #fdf6ec;
}

.danger {
  color: #f56c6c;
  background-color: #fef0f0;
}

.card-info {
  flex: 1;
}

.card-title {
  font-size: 14px;
  color: #909399;
}

.card-value {
  font-size: 24px;
  font-weight: bold;
  margin-top: 4px;
}

.chart-row {
  margin: 20px 0;
}

:deep(.el-card__body) {
  padding: 20px;
}

.system-card {
  margin-bottom: 20px;
}

:deep(.el-card__header) {
  padding: 15px 20px;
  border-bottom: 1px solid #ebeef5;
  background-color: #fafafa;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style> 