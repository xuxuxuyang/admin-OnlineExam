<template>
  <div class="menu-management">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>菜单管理</span>
          <el-button type="primary" @click="handleAdd">新增菜单</el-button>
        </div>
      </template>

      <el-table
        :data="tableData"
        style="width: 100%"
        border
        stripe
        row-key="id"
        :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
      >
        <el-table-column prop="name" label="菜单名称" align="left" />
        <el-table-column prop="path" label="路由路径" align="center" />
        <el-table-column prop="component" label="组件路径" align="center" />
        <el-table-column label="图标" align="center" width="80">
          <template #default="scope">
            <el-icon v-if="scope.row.icon && iconComponents[scope.row.icon]">
              <component :is="iconComponents[scope.row.icon]" />
            </el-icon>
          </template>
        </el-table-column>
        <el-table-column prop="sort" label="排序" align="center" width="80" />
        <el-table-column
          prop="createTime"
          label="创建时间"
          align="center"
          width="180"
        >
          <template #default="scope">
            {{ formatDateTime(scope.row.createTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="200" align="center">
          <template #default="scope">
            <el-button
              size="small"
              type="primary"
              @click="handleEdit(scope.row)"
              :icon="Edit"
            >
              编辑
            </el-button>
            <el-button
              size="small"
              type="danger"
              @click="handleDelete(scope.row)"
              :icon="Delete"
            >
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 新增/编辑菜单对话框 -->
    <el-dialog
      v-model="dialogVisible"
      :title="dialogType === 'add' ? '新增菜单' : '编辑菜单'"
      width="500px"
    >
      <el-form
        ref="menuFormRef"
        :model="menuForm"
        :rules="rules"
        label-width="100px"
      >
        <el-form-item label="上级菜单">
          <el-tree-select
            v-model="menuForm.parentId"
            :data="menuTreeData"
            placeholder="请选择上级菜单"
            :props="{
              label: 'name',
              value: 'id',
              children: 'children',
            }"
            check-strictly
            clearable
          />
        </el-form-item>
        <el-form-item label="菜单名称" prop="name">
          <el-input v-model="menuForm.name" placeholder="请输入菜单名称" />
        </el-form-item>
        <el-form-item label="路由路径" prop="path">
          <el-input v-model="menuForm.path" placeholder="请输入路由路径" />
        </el-form-item>
        <el-form-item label="组件路径" prop="component">
          <el-input v-model="menuForm.component" placeholder="请输入组件路径" />
        </el-form-item>
        <el-form-item label="图标" prop="icon">
          <el-select v-model="menuForm.icon" placeholder="请选择图标">
            <el-option
              v-for="(icon, name) in iconComponents"
              :key="name"
              :label="name"
              :value="name"
            >
              <el-icon>
                <component :is="icon" />
              </el-icon>
              <span style="margin-left: 8px">{{ name }}</span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="排序" prop="sort">
          <el-input-number v-model="menuForm.sort" :min="0" :max="99" />
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">取消</el-button>
          <el-button type="primary" @click="handleSubmit" :loading="loading">
            确定
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed } from "vue";
import {
  Monitor,
  Setting,
  User,
  UserFilled,
  Operation,
  Edit,
  Delete
} from "@element-plus/icons-vue";
import { ElMessage, ElMessageBox } from "element-plus";
import request from "../../../utils/request";

// 定义可用的图标组件
const iconComponents = {
  Monitor,
  Setting,
  User,
  UserFilled,
  Operation,
  Edit,
  Delete
};

const dialogVisible = ref(false);
const dialogType = ref("add");
const loading = ref(false);
const menuFormRef = ref(null);

const menuForm = ref({
  name: "",
  path: "",
  component: "",
  icon: "",
  sort: 0,
  parentId: null,
});

const rules = {
  name: [
    { required: true, message: "请输入菜单名称", trigger: "blur" },
    { min: 2, max: 20, message: "长度在 2 到 20 个字符", trigger: "blur" },
  ],
  path: [{ required: true, message: "请输入路由路径", trigger: "blur" }],
  component: [{ required: true, message: "请输入组件路径", trigger: "blur" }],
};

const tableData = ref([]);

// 添加处理树形数据的计算属性
const menuTreeData = computed(() => {
  return [
    {
      id: 0,
      name: "顶级菜单",
      children: tableData.value,
    },
  ];
});

// 获取菜单列表
const fetchMenus = async () => {
  try {
    const data = await request.get("/menus");
    tableData.value = data;
  } catch (error) {
    console.error("获取菜单列表失败:", error);
  }
};

// 打开新增菜单对话框
const handleAdd = () => {
  dialogType.value = "add";
  menuForm.value = {
    name: "",
    path: "",
    component: "",
    icon: "",
    sort: 0,
    parentId: null,
  };
  dialogVisible.value = true;
};

// 打开编辑菜单对话框
const handleEdit = (row) => {
  dialogType.value = "edit";
  menuForm.value = {
    id: row.id,
    name: row.name,
    path: row.path,
    component: row.component,
    icon: row.icon,
    sort: row.sort,
    parentId: row.parentId,
  };
  dialogVisible.value = true;
};

// 删除菜单
const handleDelete = (row) => {
  ElMessageBox.confirm(
    `确定要删除菜单 ${row.name} 吗？${
      row.children?.length ? "（包含子菜单）" : ""
    }`,
    "警告",
    {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning",
    }
  )
    .then(async () => {
      try {
        await request.delete(`/menus/${row.id}`);
        ElMessage.success("删除成功");
        fetchMenus();
      } catch (error) {
        console.error("删除菜单失败:", error);
      }
    })
    .catch(() => {
      ElMessage.info("已取消删除");
    });
};

// 提交表单
const handleSubmit = async () => {
  if (!menuFormRef.value) return;

  await menuFormRef.value.validate(async (valid, fields) => {
    if (valid) {
      loading.value = true;
      try {
        const submitData = {
          ...menuForm.value,
          icon: menuForm.value.icon || null, // 确保图标为空时传null
        };

        if (dialogType.value === "add") {
          await request.post("/menus", submitData);
          ElMessage.success("添加菜单成功");
        } else {
          const { id, ...updateData } = submitData;
          await request.put(`/menus/${id}`, updateData);
          ElMessage.success("编辑菜单成功");
        }
        dialogVisible.value = false;
        fetchMenus();
      } catch (error) {
        console.error(
          dialogType.value === "add" ? "添加菜单失败:" : "编辑菜单失败:",
          error
        );
      } finally {
        loading.value = false;
      }
    }
  });
};

// 格式化时间
const formatDateTime = (date) => {
  if (!date) return "";
  const dt = new Date(date);
  const year = dt.getFullYear();
  const month = String(dt.getMonth() + 1).padStart(2, "0");
  const day = String(dt.getDate()).padStart(2, "0");
  const hour = String(dt.getHours()).padStart(2, "0");
  const minute = String(dt.getMinutes()).padStart(2, "0");
  const second = String(dt.getSeconds()).padStart(2, "0");
  return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
};

// 初始化获取菜单列表
fetchMenus();
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

:deep(.el-card__header) {
  padding: 15px 20px;
  border-bottom: 1px solid #ebeef5;
  background-color: #fafafa;
}

:deep(.el-table) {
  margin-top: 10px;
}

:deep(.el-button) {
  padding: 5px 12px;
  margin-left: 8px;
}

:deep(.el-button:first-child) {
  margin-left: 0;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}

.el-select-dropdown__item {
  display: flex;
  align-items: center;
}
</style>
