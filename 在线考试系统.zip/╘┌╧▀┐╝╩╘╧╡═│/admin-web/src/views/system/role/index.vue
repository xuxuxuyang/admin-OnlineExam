<template>
    <div class="role-management">
        <el-card>
            <template #header>
                <div class="card-header">
                    <span>角色管理</span>
                    <el-button type="primary" @click="handleAdd">新增角色</el-button>
                </div>
            </template>
            
            <el-table 
                :data="tableData" 
                style="width: 100%"
                border
                stripe
                highlight-current-row
            >
                <el-table-column prop="name" label="角色名称" align="center" />
                <el-table-column prop="description" label="角色描述" align="center" />
                <el-table-column 
                    prop="createTime" 
                    label="创建时间" 
                    align="center" 
                    width="180"
                >
                    <template #default="scope">
                        {{ formatDateTime(scope.row.createTime) }}
                    </template>
                </el-table-column>
                <el-table-column label="操作" width="200" align="center" fixed="right">
                    <template #default="scope">
                        <el-button 
                            size="small" 
                            type="primary" 
                            @click="handleEdit(scope.row)"
                            :icon="Edit"
                        >
                            编辑
                        </el-button>
                        <el-button 
                            size="small" 
                            type="danger" 
                            @click="handleDelete(scope.row)"
                            :icon="Delete"
                        >
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-card>

        <!-- 新增/编辑角色对话框 -->
        <el-dialog
            v-model="dialogVisible"
            :title="dialogType === 'add' ? '新增角色' : '编辑角色'"
            width="500px"
        >
            <el-form
                ref="roleFormRef"
                :model="roleForm"
                :rules="rules"
                label-width="100px"
            >
                <el-form-item label="角色名称" prop="name">
                    <el-input v-model="roleForm.name" placeholder="请输入角色名称" />
                </el-form-item>
                <el-form-item label="角色描述" prop="description">
                    <el-input 
                        v-model="roleForm.description" 
                        type="textarea" 
                        placeholder="请输入角色描述"
                    />
                </el-form-item>
                <el-form-item label="权限" prop="permissions">
                    <el-select
                        v-model="roleForm.permissions"
                        multiple
                        placeholder="请选择权限"
                        style="width: 100%"
                    >
                        <el-option label="用户查看" value="user:view" />
                        <el-option label="用户编辑" value="user:edit" />
                        <el-option label="角色查看" value="role:view" />
                        <el-option label="角色编辑" value="role:edit" />
                    </el-select>
                </el-form-item>
            </el-form>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="dialogVisible = false">取消</el-button>
                    <el-button type="primary" @click="handleSubmit" :loading="loading">
                        确定
                    </el-button>
                </span>
            </template>
        </el-dialog>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import { Edit, Delete } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '../../../utils/request'

const dialogVisible = ref(false)
const dialogType = ref('add')
const loading = ref(false)
const roleFormRef = ref(null)

const roleForm = ref({
    name: '',
    description: '',
    permissions: []
})

const rules = {
    name: [
        { required: true, message: '请输入角色名称', trigger: 'blur' },
        { min: 2, max: 20, message: '长度在 2 到 20 个字符', trigger: 'blur' }
    ],
    description: [
        { required: true, message: '请输入角色描述', trigger: 'blur' }
    ],
    permissions: [
        { required: true, message: '请选择权限', trigger: 'change' }
    ]
}

const tableData = ref([])

// 获取角色列表
const fetchRoles = async () => {
    try {
        const data = await request.get('/roles')
        tableData.value = data
    } catch (error) {
        console.error('获取角色列表失败:', error)
    }
}

// 打开新增角色对话框
const handleAdd = () => {
    dialogType.value = 'add'
    roleForm.value = {
        name: '',
        description: '',
        permissions: []
    }
    dialogVisible.value = true
}

// 打开编辑角色对话框
const handleEdit = (row) => {
    dialogType.value = 'edit'
    roleForm.value = {
        id: row.id,
        name: row.name,
        description: row.description,
        permissions: row.permissions
    }
    dialogVisible.value = true
}

// 删除角色
const handleDelete = (row) => {
    ElMessageBox.confirm(
        `确定要删除角色 ${row.name} 吗？`,
        '警告',
        {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
        }
    )
    .then(async () => {
        try {
            await request.delete(`/roles/${row.id}`)
            ElMessage.success('删除成功')
            fetchRoles()
        } catch (error) {
            console.error('删除角色失败:', error)
        }
    })
    .catch(() => {
        ElMessage.info('已取消删除')
    })
}

// 提交表单
const handleSubmit = async () => {
    if (!roleFormRef.value) return
    
    await roleFormRef.value.validate(async (valid, fields) => {
        if (valid) {
            loading.value = true
            try {
                if (dialogType.value === 'add') {
                    await request.post('/roles', roleForm.value)
                    ElMessage.success('添加角色成功')
                } else {
                    const { id, ...updateData } = roleForm.value
                    await request.put(`/roles/${id}`, updateData)
                    ElMessage.success('编辑角色成功')
                }
                dialogVisible.value = false
                fetchRoles()
            } catch (error) {
                console.error(dialogType.value === 'add' ? '添加角色失败:' : '编辑角色失败:', error)
            } finally {
                loading.value = false
            }
        }
    })
}

// 格式化时间
const formatDateTime = (date) => {
    if (!date) return ''
    const dt = new Date(date)
    const year = dt.getFullYear()
    const month = String(dt.getMonth() + 1).padStart(2, '0')
    const day = String(dt.getDate()).padStart(2, '0')
    const hour = String(dt.getHours()).padStart(2, '0')
    const minute = String(dt.getMinutes()).padStart(2, '0')
    const second = String(dt.getSeconds()).padStart(2, '0')
    return `${year}-${month}-${day} ${hour}:${minute}:${second}`
}

// 初始化获取角色列表
fetchRoles()
</script>

<style scoped>
.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

:deep(.el-card__header) {
    padding: 15px 20px;
    border-bottom: 1px solid #ebeef5;
    background-color: #fafafa;
}

:deep(.el-table) {
    margin-top: 10px;
}

:deep(.el-button) {
    padding: 5px 12px;
    margin-left: 8px;
}

:deep(.el-button:first-child) {
    margin-left: 0;
}

.dialog-footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}
</style> 