<template>
  <div class="class-management">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>班级管理</span>
          <el-button type="primary" @click="handleAdd">新增班级</el-button>
        </div>
      </template>
      
      <el-table :data="tableData" border stripe>
        <el-table-column prop="name" label="班级名称" />
        <el-table-column prop="grade" label="年级" width="120" />
        <el-table-column prop="major" label="专业" width="150" />
        <el-table-column prop="studentCount" label="学生人数" width="120" />
        <el-table-column prop="teacher" label="班主任" width="120" />
        <el-table-column prop="createTime" label="创建时间" width="180" />
        <el-table-column label="操作" width="250" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleStudents(scope.row)">学生管理</el-button>
            <el-button size="small" type="primary" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const tableData = ref([
  {
    name: '计算机2101',
    grade: '2021级',
    major: '计算机科学与技术',
    studentCount: 45,
    teacher: '张老师',
    createTime: '2021-09-01'
  },
  {
    name: '计算机2102',
    grade: '2021级',
    major: '计算机科学与技术',
    studentCount: 42,
    teacher: '李老师',
    createTime: '2021-09-01'
  }
])

const handleAdd = () => {
  console.log('新增班级')
}

const handleStudents = (row) => {
  console.log('管理学生', row)
}

const handleEdit = (row) => {
  console.log('编辑班级', row)
}

const handleDelete = (row) => {
  console.log('删除班级', row)
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style> 