<template>
    <div class="user-management">
        <el-card>
            <template #header>
                <div class="card-header">
                    <span>用户管理</span>
                    <el-button type="primary" @click="handleAdd">新增用户</el-button>
                </div>
            </template>
            
            <el-table 
                :data="tableData" 
                style="width: 100%"
                border
                stripe
                highlight-current-row
            >
                <el-table-column prop="username" label="用户名" align="center" />
                <el-table-column prop="role" label="角色" align="center" />
                <el-table-column 
                    prop="createTime" 
                    label="创建时间" 
                    align="center" 
                    width="180"
                >
                    <template #default="scope">
                        {{ formatDateTime(scope.row.createTime) }}
                    </template>
                </el-table-column>
                <el-table-column label="操作" width="200" align="center" fixed="right">
                    <template #default="scope">
                        <el-button 
                            size="small" 
                            type="primary" 
                            @click="handleEdit(scope.row)"
                            :icon="Edit"
                        >
                            编辑
                        </el-button>
                        <el-button 
                            size="small" 
                            type="danger" 
                            @click="handleDelete(scope.row)"
                            :icon="Delete"
                        >
                            删除
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-card>

        <!-- 新增/编辑用户对话框 -->
        <el-dialog
            v-model="dialogVisible"
            :title="dialogType === 'add' ? '新增用户' : '编辑用户'"
            width="500px"
        >
            <el-form
                ref="userFormRef"
                :model="userForm"
                :rules="rules"
                label-width="80px"
            >
                <el-form-item label="用户名" prop="username">
                    <el-input v-model="userForm.username" placeholder="请输入用户名" />
                </el-form-item>
                <el-form-item label="密码" prop="password" v-if="dialogType === 'add'">
                    <el-input
                        v-model="userForm.password"
                        type="password"
                        placeholder="请输入密码"
                        show-password
                    />
                </el-form-item>
                <el-form-item label="角色" prop="role">
                    <el-select v-model="userForm.role" placeholder="请选择角色">
                        <el-option label="管理员" value="admin" />
                        <el-option label="超级管理员" value="super_admin" />
                    </el-select>
                </el-form-item>
            </el-form>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="dialogVisible = false">取消</el-button>
                    <el-button type="primary" @click="handleSubmit" :loading="loading">
                        确定
                    </el-button>
                </span>
            </template>
        </el-dialog>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import { Edit, Delete } from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import request from '../../../utils/request'

const dialogVisible = ref(false)
const dialogType = ref('add')
const loading = ref(false)
const userFormRef = ref(null)

const userForm = ref({
    username: '',
    password: '',
    role: ''
})

const rules = {
    username: [
        { required: true, message: '请输入用户名', trigger: 'blur' },
        { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
    ],
    password: [
        { required: dialogType.value === 'add', message: '请输入密码', trigger: 'blur' },
        { min: 6, max: 20, message: '长度在 6 到 20 个字符', trigger: 'blur' }
    ],
    role: [
        { required: true, message: '请选择角色', trigger: 'change' }
    ]
}

const tableData = ref([
    {
        username: 'admin',
        role: '管理员',
        createTime: '2024-01-01'
    },
    {
        username: 'xuyang',
        role: '超级管理员',
        createTime: '2024-01-01'
    }
])

// 获取用户列表
const fetchUsers = async () => {
    try {
        const data = await request.get('/users')
        tableData.value = data
    } catch (error) {
        console.error('获取用户列表失败:', error)
    }
}

// 打开新增用户对话框
const handleAdd = () => {
    dialogType.value = 'add'
    userForm.value = {
        username: '',
        password: '',
        role: ''
    }
    dialogVisible.value = true
}

// 添加时间格式化函数
const formatDateTime = (date) => {
    if (!date) return ''
    const dt = new Date(date)
    const year = dt.getFullYear()
    const month = String(dt.getMonth() + 1).padStart(2, '0')
    const day = String(dt.getDate()).padStart(2, '0')
    const hour = String(dt.getHours()).padStart(2, '0')
    const minute = String(dt.getMinutes()).padStart(2, '0')
    const second = String(dt.getSeconds()).padStart(2, '0')
    return `${year}-${month}-${day} ${hour}:${minute}:${second}`
}

// 打开编辑用户对话框
const handleEdit = (row) => {
    dialogType.value = 'edit'
    userForm.value = {
        id: row.id,
        username: row.username,
        role: row.role
    }
    dialogVisible.value = true
}

// 修改提交表单函数
const handleSubmit = async () => {
    if (!userFormRef.value) return
    
    await userFormRef.value.validate(async (valid, fields) => {
        if (valid) {
            loading.value = true
            try {
                if (dialogType.value === 'add') {
                    const submitData = {
                        ...userForm.value,
                        createTime: new Date().toISOString()
                    }
                    await request.post('/users', submitData)
                    ElMessage.success('添加用户成功')
                } else {
                    const { id, ...updateData } = userForm.value
                    await request.put(`/users/${id}`, updateData)
                    ElMessage.success('编辑用户成功')
                }
                dialogVisible.value = false
                fetchUsers() // 刷新用户列表
            } catch (error) {
                console.error(dialogType.value === 'add' ? '添加用户失败:' : '编辑用户失败:', error)
            } finally {
                loading.value = false
            }
        }
    })
}

// 删除用户
const handleDelete = (row) => {
    ElMessageBox.confirm(
        `确定要删除用户 ${row.username} 吗？`,
        '警告',
        {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
        }
    )
    .then(async () => {
        try {
            await request.delete(`/users/${row.id}`)
            ElMessage.success('删除成功')
            fetchUsers() // 刷新用户列表
        } catch (error) {
            console.error('删除用户失败:', error)
        }
    })
    .catch(() => {
        ElMessage.info('已取消删除')
    })
}

// 初始化获取用户列表
fetchUsers()
</script>

<style scoped>
.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

:deep(.el-card__header) {
    padding: 15px 20px;
    border-bottom: 1px solid #ebeef5;
    background-color: #fafafa;
}

:deep(.el-table) {
    margin-top: 10px;
}

:deep(.el-button) {
    padding: 5px 12px;
    margin-left: 8px;
}

:deep(.el-button:first-child) {
    margin-left: 0;
}

.dialog-footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}
</style> 