<template>
    <div class="home-container">
        <el-container>
            <el-header>
                <div class="header-content">
                    <h2>欢迎, {{ username }}</h2>
                    <el-button type="danger" @click="handleLogout">退出登录</el-button>
                </div>
            </el-header>
            <el-main>
                <h1>后台管理系统</h1>
            </el-main>
        </el-container>
    </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useUserStore } from '../stores/user'
import { useRouter } from 'vue-router'
import { storeToRefs } from 'pinia'
import { ElMessage } from 'element-plus'

const userStore = useUserStore()
const router = useRouter()
const { username } = storeToRefs(userStore)

onMounted(async () => {
    try {
        await userStore.fetchUserInfo()
    } catch (error) {
        ElMessage.error('获取用户信息失败')
    }
})

const handleLogout = () => {
    userStore.logout()
    router.push('/login')
}
</script>

<style scoped>
.home-container {
    height: 100vh;
}

.el-header {
    background-color: #fff;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.header-content {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
</style> 