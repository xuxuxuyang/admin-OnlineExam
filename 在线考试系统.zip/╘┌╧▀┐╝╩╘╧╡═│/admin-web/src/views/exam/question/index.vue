<template>
  <div class="question-bank">
    <el-card>
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <span>题库管理</span>
            <el-radio-group v-model="questionType" class="type-filter">
              <el-radio-button label="all">全部</el-radio-button>
              <el-radio-button label="single">单选题</el-radio-button>
              <el-radio-button label="multiple">多选题</el-radio-button>
              <el-radio-button label="judge">判断题</el-radio-button>
              <el-radio-button label="essay">简答题</el-radio-button>
            </el-radio-group>
          </div>
          <el-button type="primary" @click="handleAdd">新增题目</el-button>
        </div>
      </template>
      
      <el-table :data="tableData" border stripe>
        <el-table-column prop="type" label="题型" width="100">
          <template #default="scope">
            <el-tag :type="getQuestionTypeTag(scope.row.type)">
              {{ scope.row.type }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="content" label="题目内容" show-overflow-tooltip />
        <el-table-column prop="subject" label="所属科目" width="120" />
        <el-table-column prop="difficulty" label="难度" width="100">
          <template #default="scope">
            <el-rate
              v-model="scope.row.difficulty"
              disabled
              text-color="#ff9900"
            />
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="创建时间" width="180" />
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="scope">
            <el-button size="small" type="primary" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const questionType = ref('all')

const tableData = ref([
  {
    type: '单选题',
    content: '以下哪个不是JavaScript的数据类型？',
    subject: '计算机基础',
    difficulty: 3,
    createTime: '2024-01-15 10:00:00'
  },
  {
    type: '多选题',
    content: '以下哪些是HTTP请求方法？',
    subject: '计算机网络',
    difficulty: 4,
    createTime: '2024-01-16 14:30:00'
  },
  {
    type: '判断题',
    content: 'Vue.js是一个前端框架。',
    subject: '前端开发',
    difficulty: 2,
    createTime: '2024-01-17 09:15:00'
  }
])

const getQuestionTypeTag = (type) => {
  const typeMap = {
    '单选题': '',
    '多选题': 'success',
    '判断题': 'warning',
    '简答题': 'info'
  }
  return typeMap[type]
}

const handleAdd = () => {
  console.log('新增题目')
}

const handleEdit = (row) => {
  console.log('编辑题目', row)
}

const handleDelete = (row) => {
  console.log('删除题目', row)
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 20px;
}

.type-filter {
  margin-left: 20px;
}
</style> 