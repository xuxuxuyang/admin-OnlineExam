<template>
  <div class="paper-management">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>试卷管理</span>
          <el-button type="primary" @click="handleAdd">新增试卷</el-button>
        </div>
      </template>
      
      <el-table :data="tableData" border stripe>
        <el-table-column prop="name" label="试卷名称" />
        <el-table-column prop="subject" label="科目" />
        <el-table-column prop="totalScore" label="总分" width="100" />
        <el-table-column prop="questionCount" label="题目数量" width="100" />
        <el-table-column prop="createTime" label="创建时间" width="180" />
        <el-table-column label="操作" width="250" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handlePreview(scope.row)">预览</el-button>
            <el-button size="small" type="primary" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const tableData = ref([
  {
    name: '高等数学期末试卷A',
    subject: '高等数学',
    totalScore: 100,
    questionCount: 20,
    createTime: '2024-01-10 10:00:00'
  },
  {
    name: '大学英语四级模拟试卷',
    subject: '大学英语',
    totalScore: 100,
    questionCount: 25,
    createTime: '2024-01-12 14:30:00'
  }
])

const handleAdd = () => {
  console.log('新增试卷')
}

const handlePreview = (row) => {
  console.log('预览试卷', row)
}

const handleEdit = (row) => {
  console.log('编辑试卷', row)
}

const handleDelete = (row) => {
  console.log('删除试卷', row)
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style> 