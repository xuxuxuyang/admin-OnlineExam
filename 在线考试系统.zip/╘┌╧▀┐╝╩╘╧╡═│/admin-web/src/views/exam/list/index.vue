<template>
  <div class="exam-list">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>考试列表</span>
          <el-button type="primary" @click="handleAdd">创建考试</el-button>
        </div>
      </template>
      
      <el-table :data="tableData" border stripe>
        <el-table-column prop="name" label="考试名称" />
        <el-table-column prop="subject" label="科目" />
        <el-table-column prop="startTime" label="开始时间" width="180" />
        <el-table-column prop="duration" label="考试时长" width="100">
          <template #default="scope">
            {{ scope.row.duration }}分钟
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status === '进行中' ? 'success' : scope.row.status === '未开始' ? 'info' : 'danger'">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="250" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleView(scope.row)">查看</el-button>
            <el-button size="small" type="primary" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const tableData = ref([
  {
    name: '2024年春季期末考试',
    subject: '高等数学',
    startTime: '2024-01-15 14:00:00',
    duration: 120,
    status: '已结束'
  },
  {
    name: '2024年春季期中考试',
    subject: '大学英语',
    startTime: '2024-03-20 09:00:00',
    duration: 90,
    status: '未开始'
  },
  {
    name: '第一次月考',
    subject: '计算机基础',
    startTime: '2024-02-01 10:00:00',
    duration: 60,
    status: '进行中'
  }
])

const handleAdd = () => {
  console.log('创建考试')
}

const handleView = (row) => {
  console.log('查看考试', row)
}

const handleEdit = (row) => {
  console.log('编辑考试', row)
}

const handleDelete = (row) => {
  console.log('删除考试', row)
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
</style> 