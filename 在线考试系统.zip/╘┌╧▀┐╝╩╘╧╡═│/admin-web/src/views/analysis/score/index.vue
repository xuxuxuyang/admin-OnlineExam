<template>
  <div class="score-analysis">
    <el-row :gutter="20">
      <el-col :span="6" v-for="card in statisticsCards" :key="card.title">
        <el-card shadow="hover" class="statistics-card">
          <div class="card-content">
            <div class="card-value">{{ card.value }}</div>
            <div class="card-title">{{ card.title }}</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" class="chart-row">
      <el-col :span="12">
        <el-card>
          <template #header>
            <div class="card-header">成绩分布</div>
          </template>
          <div ref="scoreDistributionRef" style="height: 300px"></div>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card>
          <template #header>
            <div class="card-header">及格率趋势</div>
          </template>
          <div ref="passRateRef" style="height: 300px"></div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import * as echarts from 'echarts'

const statisticsCards = [
  { title: '参考人数', value: '1,234' },
  { title: '平均分', value: '78.5' },
  { title: '最高分', value: '98' },
  { title: '及格率', value: '85.2%' }
]

const scoreDistributionRef = ref(null)
const passRateRef = ref(null)

onMounted(() => {
  const scoreDistribution = echarts.init(scoreDistributionRef.value)
  scoreDistribution.setOption({
    title: { text: '成绩分布' },
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: ['<60', '60-70', '70-80', '80-90', '90-100']
    },
    yAxis: { type: 'value' },
    series: [{
      data: [50, 100, 150, 80, 70],
      type: 'bar'
    }]
  })

  const passRate = echarts.init(passRateRef.value)
  passRate.setOption({
    title: { text: '及格率趋势' },
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: ['第一次', '第二次', '第三次', '第四次', '第五次']
    },
    yAxis: { type: 'value' },
    series: [{
      data: [75, 82, 80, 85, 88],
      type: 'line',
      smooth: true
    }]
  })
})
</script>

<style scoped>
.statistics-card {
  margin-bottom: 20px;
}

.card-content {
  text-align: center;
}

.card-value {
  font-size: 24px;
  font-weight: bold;
  color: #1890ff;
}

.card-title {
  margin-top: 8px;
  color: #666;
}

.chart-row {
  margin-top: 20px;
}

.card-header {
  font-weight: bold;
}
</style> 