<template>
  <div class="exam-report">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>考试报表</span>
          <div class="header-right">
            <el-select v-model="currentExam" placeholder="选择考试" style="width: 200px">
              <el-option
                v-for="item in examList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-button type="primary" @click="handleExport">导出报表</el-button>
          </div>
        </div>
      </template>

      <el-table :data="tableData" border stripe>
        <el-table-column type="index" label="序号" width="80" align="center" />
        <el-table-column prop="name" label="姓名" width="120" />
        <el-table-column prop="class" label="班级" width="120" />
        <el-table-column prop="score" label="得分" width="100" sortable />
        <el-table-column prop="rank" label="排名" width="100" sortable />
        <el-table-column prop="submitTime" label="提交时间" width="180" />
        <el-table-column prop="duration" label="答题时长" width="120">
          <template #default="scope">
            {{ scope.row.duration }}分钟
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.status === '已批改' ? 'success' : 'warning'">
              {{ scope.row.status }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleDetail(scope.row)">
              查看详情
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const currentExam = ref('')
const examList = [
  { label: '2024年春季期末考试', value: '1' },
  { label: '2024年春季期中考试', value: '2' },
  { label: '第一次月考', value: '3' }
]

const tableData = ref([
  {
    name: '张三',
    class: '计算机2101',
    score: 85,
    rank: 15,
    submitTime: '2024-01-15 15:30:00',
    duration: 110,
    status: '已批改'
  },
  {
    name: '李四',
    class: '计算机2102',
    score: 92,
    rank: 5,
    submitTime: '2024-01-15 14:50:00',
    duration: 95,
    status: '已批改'
  },
  {
    name: '王五',
    class: '计算机2101',
    score: 78,
    rank: 25,
    submitTime: '2024-01-15 15:45:00',
    duration: 115,
    status: '待批改'
  }
])

const handleExport = () => {
  console.log('导出报表')
}

const handleDetail = (row) => {
  console.log('查看详情', row)
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-right {
  display: flex;
  gap: 16px;
}
</style> 