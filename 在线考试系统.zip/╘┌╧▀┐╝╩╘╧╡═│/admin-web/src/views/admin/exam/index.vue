<template>
  <div class="exam-container">
    <!-- 数据概览卡片 -->
    <el-row :gutter="20" class="statistics">
      <el-col :span="6" v-for="stat in statistics" :key="stat.title">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-content">
            <div class="stat-icon" :style="{ backgroundColor: stat.color }">
              <el-icon><component :is="stat.icon" /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ stat.value }}</div>
              <div class="stat-title">{{ stat.title }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 主要内容区 -->
    <el-card class="main-content">
      <!-- 顶部操作栏 -->
      <div class="operation-bar">
        <div class="left-operations">
          <el-button type="primary" @click="handleCreate">
            <el-icon><Plus /></el-icon>创建试卷
          </el-button>
          <el-button type="success" @click="handleBatchImport">
            <el-icon><Upload /></el-icon>批量导入
          </el-button>
          <el-button type="warning" @click="handleExport">
            <el-icon><Download /></el-icon>导出试卷
          </el-button>
        </div>
        <div class="right-filters">
          <el-select
            v-model="filters.subject"
            placeholder="选择学科"
            clearable
            class="filter-item"
          >
            <el-option
              v-for="item in subjectOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-select
            v-model="filters.grade"
            placeholder="选择年级"
            clearable
            class="filter-item"
          >
            <el-option
              v-for="item in gradeOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-select
            v-model="filters.status"
            placeholder="试卷状态"
            clearable
            class="filter-item"
          >
            <el-option
              v-for="item in statusOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-input
            v-model="filters.keyword"
            placeholder="搜索试卷名称"
            clearable
            class="filter-item"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
          <el-button type="primary" @click="handleSearch">
            <el-icon><Search /></el-icon>搜索
          </el-button>
          <el-button @click="resetFilters">
            <el-icon><Refresh /></el-icon>重置
          </el-button>
        </div>
      </div>

      <!-- 试卷列表 -->
      <el-table
        :data="examList"
        style="width: 100%"
        border
        stripe
        v-loading="loading"
      >
        <el-table-column type="selection" width="55" align="center" />
        <el-table-column
          prop="name"
          label="试卷名称"
          min-width="200"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            <div class="exam-name">
              <el-tag
                size="small"
                :type="row.type === 'formal' ? 'danger' : 'info'"
              >
                {{ row.type === "formal" ? "正式" : "模拟" }}
              </el-tag>
              <span class="name-text">{{ row.name }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="subject"
          label="科目"
          width="100"
          align="center"
        />
        <el-table-column prop="grade" label="年级" width="100" align="center" />
        <el-table-column
          prop="totalScore"
          label="总分"
          width="80"
          align="center"
        />
        <el-table-column
          prop="duration"
          label="时长"
          width="100"
          align="center"
        >
          <template #default="{ row }"> {{ row.duration }}分钟 </template>
        </el-table-column>
        <el-table-column
          prop="examTime"
          label="考试时间"
          width="180"
          align="center"
        >
          <template #default="{ row }">
            <div class="exam-time">
              <div>{{ row.startTime }}</div>
              <div>{{ row.endTime }}</div>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="260" fixed="right" align="center">
          <template #default="{ row }">
            <el-button-group>
              <el-tooltip content="编辑试卷" placement="top">
                <el-button
                  type="primary"
                  link
                  :disabled="row.status === '已结束'"
                  @click="handleEdit(row)"
                >
                  <el-icon><Edit /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="预览试卷" placement="top">
                <el-button type="primary" link @click="handlePreview(row)">
                  <el-icon><View /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="发布试卷" placement="top">
                <el-button
                  type="success"
                  link
                  :disabled="row.status !== '未开始'"
                  @click="handlePublish(row)"
                >
                  <el-icon><Upload /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="查看成绩" placement="top">
                <el-button
                  type="warning"
                  link
                  :disabled="row.status === '未开始'"
                  @click="handleViewScores(row)"
                >
                  <el-icon><DataLine /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="删除试卷" placement="top">
                <el-button type="danger" link @click="handleDelete(row)">
                  <el-icon><Delete /></el-icon>
                </el-button>
              </el-tooltip>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          v-model="pagination.currentPage"
          :current-page="pagination.currentPage"
          :page-size="pagination.pageSize"
          @update:current-page="(val) => (pagination.currentPage = val)"
          @update:page-size="(val) => (pagination.pageSize = val)"
          :page-sizes="[10, 20, 50, 100]"
          :total="pagination.total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive } from "vue";
import {
  Plus,
  Edit,
  View,
  Upload,
  Download,
  Delete,
  Search,
  Refresh,
  DataLine,
  Document,
  Calendar,
  Timer,
  User,
} from "@element-plus/icons-vue";
import { ElMessage, ElMessageBox } from "element-plus";

// 统计数据
const statistics = [
  {
    title: "试卷总数",
    value: "128",
    icon: "Document",
    color: "#409EFF",
  },
  {
    title: "本月考试",
    value: "12",
    icon: "Calendar",
    color: "#67C23A",
  },
  {
    title: "进行中",
    value: "3",
    icon: "Timer",
    color: "#E6A23C",
  },
  {
    title: "参考人数",
    value: "1,234",
    icon: "User",
    color: "#F56C6C",
  },
];

// 筛选条件
const filters = reactive({
  subject: "",
  grade: "",
  status: "",
  keyword: "",
});

// 选项数据
const subjectOptions = [
  { label: "语文", value: "chinese" },
  { label: "数学", value: "math" },
  { label: "英语", value: "english" },
];

const gradeOptions = [
  { label: "高一", value: "g1" },
  { label: "高二", value: "g2" },
  { label: "高三", value: "g3" },
];

const statusOptions = [
  { label: "未开始", value: "pending" },
  { label: "进行中", value: "ongoing" },
  { label: "已结束", value: "finished" },
];

// 表格数据
const loading = ref(false);
const examList = ref([
  {
    id: 1,
    name: "2024春季高等数学期中考试",
    type: "formal",
    subject: "数学",
    grade: "高三",
    totalScore: 100,
    duration: 120,
    startTime: "2024-04-15 09:00",
    endTime: "2024-04-15 11:00",
    status: "未开始",
  },
  // ... 其他试卷数据
]);

// 分页
const pagination = reactive({
  currentPage: 1,
  pageSize: 10,
  total: 0,
});

// 方法定义
const getStatusType = (status) => {
  const typeMap = {
    未开始: "info",
    进行中: "success",
    已结束: "",
  };
  return typeMap[status];
};

const handleSearch = () => {
  // 实现搜索逻辑
  console.log("搜索条件：", filters);
};

const resetFilters = () => {
  Object.keys(filters).forEach((key) => {
    filters[key] = "";
  });
  handleSearch();
};

const handleSizeChange = (val) => {
  pagination.pageSize = val;
  handleSearch();
};

const handleCurrentChange = (val) => {
  pagination.currentPage = val;
  handleSearch();
};

// ... 其他方法实现
</script>

<style scoped>
.exam-container {
  padding: 20px;
}

.statistics {
  margin-bottom: 20px;
}

.stat-card .stat-content {
  display: flex;
  align-items: center;
}

.stat-card .stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
}

.stat-card .stat-icon :deep(.el-icon) {
  font-size: 24px;
  color: #fff;
}

.stat-card .stat-info .stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-card .stat-info .stat-title {
  font-size: 14px;
  color: #909399;
  margin-top: 4px;
}

.operation-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.left-operations {
  display: flex;
  gap: 12px;
}

.right-filters {
  display: flex;
  gap: 12px;
}

.right-filters .filter-item {
  width: 180px;
}

.exam-name {
  display: flex;
  align-items: center;
  gap: 8px;
}

.exam-name .name-text {
  color: #303133;
}

.exam-time {
  font-size: 13px;
  color: #606266;
}

.pagination-container {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #ebeef5;
}

:deep(.el-card) {
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.05);
}

:deep(.el-button-group .el-button) {
  padding: 6px 8px;
}
</style>
