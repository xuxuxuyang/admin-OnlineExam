<template>
  <div class="history-container">
    <!-- 数据概览 -->
    <el-row :gutter="20" class="statistics">
      <el-col :span="6" v-for="stat in statistics" :key="stat.title">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-content">
            <div class="stat-icon" :style="{ backgroundColor: stat.color }">
              <el-icon><component :is="stat.icon" /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ stat.value }}</div>
              <div class="stat-title">{{ stat.title }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 主要内容区 -->
    <el-card class="main-content">
      <!-- 顶部操作栏 -->
      <div class="operation-bar">
        <div class="left-operations">
          <el-button type="primary" @click="handleExport">
            <el-icon><Download /></el-icon>导出答卷
          </el-button>
          <el-button type="success" @click="handleAnalysis">
            <el-icon><DataLine /></el-icon>成绩分析
          </el-button>
          <el-button type="warning" @click="handleBatchArchive">
            <el-icon><Folder /></el-icon>批量归档
          </el-button>
        </div>
        <div class="right-filters">
          <el-select
            v-model="filters.exam"
            placeholder="选择考试"
            clearable
            class="filter-select"
          >
            <el-option
              v-for="item in examOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-select
            v-model="filters.subject"
            placeholder="选择科目"
            clearable
            class="filter-select"
          >
            <el-option
              v-for="item in subjectOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-select
            v-model="filters.class"
            placeholder="选择班级"
            clearable
            class="filter-select"
          >
            <el-option
              v-for="item in classOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-date-picker
            v-model="filters.dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            class="date-picker"
          />
          <el-input
            v-model="filters.keyword"
            placeholder="搜索学生姓名/学号"
            clearable
            class="search-input"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
          <div class="filter-buttons">
            <el-button type="primary" @click="handleSearch">
              <el-icon><Search /></el-icon>搜索
            </el-button>
            <el-button @click="resetFilters">
              <el-icon><Refresh /></el-icon>重置
            </el-button>
          </div>
        </div>
      </div>

      <!-- 答卷列表 -->
      <el-table
        :data="historyList"
        style="width: 100%"
        border
        stripe
        v-loading="loading"
      >
        <el-table-column type="selection" width="55" align="center" />
        <el-table-column
          prop="examName"
          label="考试名称"
          min-width="200"
          show-overflow-tooltip
        >
          <template #default="{ row }">
            <div class="exam-info">
              <el-tag
                size="small"
                :type="row.type === 'formal' ? 'danger' : 'info'"
              >
                {{ row.type === "formal" ? "正式考试" : "模拟考试" }}
              </el-tag>
              <span class="exam-name">{{ row.examName }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="studentName" label="学生姓名" width="120" />
        <el-table-column prop="studentId" label="学号" width="120" />
        <el-table-column prop="className" label="班级" width="120" />
        <el-table-column prop="subject" label="科目" width="100" />
        <el-table-column prop="score" label="得分" width="100" align="center">
          <template #default="{ row }">
            <span :class="getScoreClass(row.score, row.totalScore)">
              {{ row.score }}/{{ row.totalScore }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="submitTime" label="提交时间" width="180" />
        <el-table-column prop="duration" label="答题时长" width="120">
          <template #default="{ row }">
            {{ formatDuration(row.duration) }}
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100" align="center">
          <template #default="{ row }">
            <el-tag :type="getStatusType(row.status)">{{ row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180" fixed="right" align="center">
          <template #default="{ row }">
            <el-button-group>
              <el-tooltip content="查看答卷" placement="top">
                <el-button type="primary" link @click="handleView(row)">
                  <el-icon><View /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="导出答卷" placement="top">
                <el-button type="success" link @click="handleExportSingle(row)">
                  <el-icon><Download /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="归档答卷" placement="top">
                <el-button type="warning" link @click="handleArchive(row)">
                  <el-icon><Folder /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="删除答卷" placement="top">
                <el-button type="danger" link @click="handleDelete(row)">
                  <el-icon><Delete /></el-icon>
                </el-button>
              </el-tooltip>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          v-model="pagination.currentPage"
          :current-page="pagination.currentPage"
          :page-size="pagination.pageSize"
          @update:current-page="(val) => (pagination.currentPage = val)"
          @update:page-size="(val) => (pagination.pageSize = val)"
          :page-sizes="[10, 20, 50, 100]"
          :total="pagination.total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 答卷预览抽屉 -->
    <el-drawer
      v-model="drawerVisible"
      title="答卷详情"
      size="80%"
      :destroy-on-close="true"
    >
      <template #default>
        <div class="paper-preview">
          <!-- 答卷预览内容 -->
        </div>
      </template>
    </el-drawer>
  </div>
</template>

<script setup>
import { ref, reactive } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";

// 统计数据
const statistics = [
  {
    title: "总答卷数",
    value: "12,356",
    icon: "Document",
    color: "#409EFF",
  },
  {
    title: "本月答卷",
    value: "2,890",
    icon: "Calendar",
    color: "#67C23A",
  },
  {
    title: "平均分",
    value: "85.6",
    icon: "DataLine",
    color: "#E6A23C",
  },
  {
    title: "及格率",
    value: "92.3%",
    icon: "TrendCharts",
    color: "#F56C6C",
  },
];

// 筛选条件
const filters = reactive({
  exam: "",
  subject: "",
  class: "",
  dateRange: [],
  keyword: "",
});

// 选项数据
const examOptions = [
  { label: "2024春季高数期中考试", value: "math2024" },
  { label: "2024春季英语期中考试", value: "eng2024" },
];

const subjectOptions = [
  { label: "高等数学", value: "math" },
  { label: "大学英语", value: "english" },
];

const classOptions = [
  { label: "计算机2101班", value: "cs2101" },
  { label: "计算机2102班", value: "cs2102" },
];

// 表格数据
const loading = ref(false);
const historyList = ref([
  {
    id: 1,
    examName: "2024春季高等数学期中考试",
    type: "formal",
    studentName: "张三",
    studentId: "2021001",
    className: "计算机2101",
    subject: "高等数学",
    score: 85,
    totalScore: 100,
    submitTime: "2024-03-15 14:30:25",
    duration: 5400,
    status: "已批改",
  },
  // ... 其他答卷数据
]);

// 分页
const pagination = reactive({
  currentPage: 1,
  pageSize: 10,
  total: 0,
});

// 抽屉控制
const drawerVisible = ref(false);

// 方法定义
const getScoreClass = (score, total) => {
  const percentage = (score / total) * 100;
  if (percentage >= 90) return "score-excellent";
  if (percentage >= 80) return "score-good";
  if (percentage >= 60) return "score-pass";
  return "score-fail";
};

const formatDuration = (seconds) => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  return `${hours}时${minutes}分`;
};

const getStatusType = (status) => {
  const typeMap = {
    已批改: "success",
    待批改: "warning",
    已归档: "info",
  };
  return typeMap[status];
};

const handleSearch = () => {
  console.log("搜索条件：", filters);
};

const resetFilters = () => {
  Object.keys(filters).forEach((key) => {
    filters[key] = key === "dateRange" ? [] : "";
  });
  handleSearch();
};

// ... 其他方法实现
</script>

<style scoped>
.history-container {
  padding: 20px;
}

.statistics {
  margin-bottom: 20px;
}

.stat-card .stat-content {
  display: flex;
  align-items: center;
}

.stat-card .stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
}

.stat-card .stat-icon :deep(.el-icon) {
  font-size: 24px;
  color: #fff;
}

.stat-card .stat-info .stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-card .stat-info .stat-title {
  font-size: 14px;
  color: #909399;
  margin-top: 4px;
}

.operation-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.left-operations {
  display: flex;
  gap: 12px;
}

.right-filters {
  display: flex;
  gap: 8px;
  align-items: center;
}

.right-filters .filter-select {
  width: 160px;
}

.right-filters .date-picker {
  width: 240px;
}

.right-filters .search-input {
  width: 200px;
}

.filter-buttons {
  display: flex;
  gap: 8px;
}

.exam-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.exam-name {
  color: #303133;
}

.score-excellent {
  color: #67c23a;
  font-weight: bold;
}

.score-good {
  color: #409eff;
  font-weight: bold;
}

.score-pass {
  color: #e6a23c;
  font-weight: bold;
}

.score-fail {
  color: #f56c6c;
  font-weight: bold;
}

.pagination-container {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #ebeef5;
}

:deep(.el-card) {
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.05);
}

:deep(.el-button-group .el-button) {
  padding: 6px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 32px;
  height: 32px;
}

:deep(.el-button-group .el-button .el-icon) {
  margin: 0;
  font-size: 16px;
  vertical-align: middle;
}

:deep(.el-button-group) {
  display: inline-flex;
  align-items: center;
}
:deep(.el-button) > span {
  margin-left: -10px;
}
/* 响应式布局 */
@media screen and (max-width: 1400px) {
  .right-filters .filter-select {
    width: 140px;
  }

  .right-filters .date-picker {
    width: 220px;
  }

  .right-filters .search-input {
    width: 180px;
  }
}

@media screen and (max-width: 1200px) {
  .operation-bar {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;
  }

  .right-filters {
    width: 100%;
    flex-wrap: wrap;
  }
}
</style>
