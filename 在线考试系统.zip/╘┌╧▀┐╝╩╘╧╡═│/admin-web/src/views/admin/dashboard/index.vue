<template>
  <div class="dashboard-container">
    <!-- 统计卡片 -->
    <el-row :gutter="20">
      <el-col :span="6" v-for="item in statistics" :key="item.title">
        <el-card shadow="hover" class="statistic-card">
          <div class="statistic-item">
            <div class="item-icon" :style="{ background: item.color }">
              <el-icon><component :is="item.icon" /></el-icon>
            </div>
            <div class="item-content">
              <div class="item-value">{{ item.value }}</div>
              <div class="item-title">{{ item.title }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 实时监控 -->
    <el-row :gutter="20" class="monitor-section">
      <el-col :span="16">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>实时考试监控</span>
              <el-button type="primary" link>查看全部</el-button>
            </div>
          </template>
          <el-table :data="examList" style="width: 100%">
            <el-table-column prop="name" label="考试名称" min-width="180" />
            <el-table-column prop="subject" label="科目" width="120" />
            <el-table-column prop="studentCount" label="考生人数" width="100" />
            <el-table-column prop="status" label="状态" width="100">
              <template #default="{ row }">
                <el-tag :type="getStatusType(row.status)">{{ row.status }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="progress" label="进度" width="200">
              <template #default="{ row }">
                <el-progress 
                  :percentage="row.progress"
                  :status="getProgressStatus(row.progress)"
                />
              </template>
            </el-table-column>
            <el-table-column label="操作" width="120" fixed="right">
              <template #default="{ row }">
                <el-button type="primary" link @click="handleMonitor(row)">
                  监控
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>异常行为预警</span>
              <el-button type="primary" link>查看全部</el-button>
            </div>
          </template>
          <div class="warning-list">
            <div v-for="item in warningList" :key="item.id" class="warning-item">
              <el-tag :type="item.type" size="small">{{ item.tag }}</el-tag>
              <div class="warning-content">
                <div class="warning-title">{{ item.title }}</div>
                <div class="warning-time">{{ item.time }}</div>
              </div>
              <el-button type="primary" link size="small">处理</el-button>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 考试数据统计 -->
    <el-row :gutter="20" class="chart-section">
      <el-col :span="12">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>考试数据趋势</span>
              <el-select v-model="timeRange" size="small" style="width: 120px">
                <el-option label="最近7天" value="7" />
                <el-option label="最近30天" value="30" />
                <el-option label="最近90天" value="90" />
              </el-select>
            </div>
          </template>
          <div class="chart-placeholder">
            考试数据趋势图表
          </div>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card class="box-card">
          <template #header>
            <div class="card-header">
              <span>成绩分布统计</span>
              <el-select v-model="subjectType" size="small" style="width: 120px">
                <el-option label="全部科目" value="" />
                <el-option label="高等数学" value="math" />
                <el-option label="大学英语" value="english" />
              </el-select>
            </div>
          </template>
          <div class="chart-placeholder">
            成绩分布图表
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import {
  Document,
  User,
  Warning,
  DataLine
} from '@element-plus/icons-vue'

const timeRange = ref('7')
const subjectType = ref('')

const statistics = [
  {
    title: '进行中考试',
    value: '5',
    icon: 'Document',
    color: '#409EFF'
  },
  {
    title: '在线考生',
    value: '128',
    icon: 'User',
    color: '#67C23A'
  },
  {
    title: '异常行为',
    value: '3',
    icon: 'Warning',
    color: '#F56C6C'
  },
  {
    title: '今日考试数',
    value: '12',
    icon: 'DataLine',
    color: '#E6A23C'
  }
]

const examList = ref([
  {
    name: '2024春季高等数学期中考试',
    subject: '高等数学',
    studentCount: 45,
    status: '进行中',
    progress: 65
  },
  {
    name: '2024春季大学英语期中考试',
    subject: '大学英语',
    studentCount: 42,
    status: '即将开始',
    progress: 0
  }
])

const warningList = ref([
  {
    id: 1,
    type: 'warning',
    tag: '切屏',
    title: '张三(2021001) 切换窗口2次',
    time: '2分钟前'
  },
  {
    id: 2,
    type: 'danger',
    tag: '离开',
    title: '李四(2021002) 离开视野超过30秒',
    time: '5分钟前'
  }
])

const getStatusType = (status) => {
  const typeMap = {
    '进行中': 'success',
    '即将开始': 'info',
    '已结束': ''
  }
  return typeMap[status]
}

const getProgressStatus = (progress) => {
  if (progress === 100) return 'success'
  if (progress === 0) return ''
  return 'warning'
}

const handleMonitor = (exam) => {
  console.log('监控考试', exam)
}
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
}
.statistic-card {
  margin-bottom: 20px;
}
.statistic-item {
  display: flex;
  align-items: center;
}
.item-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
}
.item-icon .el-icon {
  font-size: 24px;
  color: #fff;
}
.item-content {
  flex: 1;
}
.item-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  line-height: 1;
  margin-bottom: 8px;
}
.item-title {
  font-size: 14px;
  color: #909399;
}
.monitor-section {
  margin-bottom: 20px;
}
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.warning-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
.warning-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 0;
  border-bottom: 1px solid #ebeef5;
}
.warning-content {
  flex: 1;
}
.warning-title {
  font-size: 14px;
  color: #303133;
  margin-bottom: 4px;
}
.warning-time {
  font-size: 12px;
  color: #909399;
}
.chart-placeholder {
  height: 300px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #909399;
  background: #f5f7fa;
  border-radius: 4px;
}
</style> 