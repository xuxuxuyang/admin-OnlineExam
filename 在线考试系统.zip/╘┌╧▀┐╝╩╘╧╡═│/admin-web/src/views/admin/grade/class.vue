<template>
  <div class="class-grade-container">
    <!-- 搜索和过滤区域 -->
    <div class="filter-section">
      <el-form :inline="true" :model="queryParams" class="search-form">
        <el-form-item label="班级名称">
          <el-input
            v-model="queryParams.className"
            placeholder="请输入班级名称"
            clearable
            @keyup.enter="handleQuery"
          />
        </el-form-item>
        <el-form-item label="考试名称">
          <el-input
            v-model="queryParams.examName"
            placeholder="请输入考试名称"
            clearable
            @keyup.enter="handleQuery"
          />
        </el-form-item>
        <el-form-item label="考试时间">
          <el-date-picker
            v-model="queryParams.dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="YYYY-MM-DD"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleQuery">
            <el-icon><Search /></el-icon>查询
          </el-button>
          <el-button @click="resetQuery">
            <el-icon><Refresh /></el-icon>重置
          </el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 数据统计卡片 -->
    <div class="statistics-cards">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="card-header">
                <span>平均分</span>
                <el-tag type="success">全部班级</el-tag>
              </div>
            </template>
            <div class="card-content">
              <span class="number">{{ statistics.averageScore || 0 }}</span>
              <span class="unit">分</span>
            </div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="card-header">
                <span>最高分</span>
                <el-tag type="danger">TOP 1</el-tag>
              </div>
            </template>
            <div class="card-content">
              <span class="number">{{ statistics.highestScore || 0 }}</span>
              <span class="unit">分</span>
            </div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="card-header">
                <span>及格率</span>
                <el-tag type="warning">60分以上</el-tag>
              </div>
            </template>
            <div class="card-content">
              <span class="number">{{ statistics.passRate || 0 }}</span>
              <span class="unit">%</span>
            </div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="card-header">
                <span>参考人数</span>
                <el-tag type="info">总计</el-tag>
              </div>
            </template>
            <div class="card-content">
              <span class="number">{{ statistics.totalStudents || 0 }}</span>
              <span class="unit">人</span>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <!-- 成绩表格 -->
    <div class="grade-table">
      <el-table
        v-loading="loading"
        :data="gradeList"
        border
        stripe
        style="width: 100%"
      >
        <el-table-column type="index" label="序号" width="60" align="center" />
        <el-table-column prop="className" label="班级" align="center" />
        <el-table-column prop="examName" label="考试名称" align="center" />
        <el-table-column prop="averageScore" label="平均分" align="center">
          <template #default="{ row }">
            <span :class="getScoreClass(row.averageScore)">
              {{ row.averageScore }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="highestScore" label="最高分" align="center">
          <template #default="{ row }">
            <span class="score-excellent">{{ row.highestScore }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="lowestScore" label="最低分" align="center">
          <template #default="{ row }">
            <span class="score-poor">{{ row.lowestScore }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="passRate" label="及格率" align="center">
          <template #default="{ row }">
            <el-progress
              :percentage="row.passRate"
              :status="getPassRateStatus(row.passRate)"
            />
          </template>
        </el-table-column>
        <el-table-column prop="examDate" label="考试时间" align="center" />
        <el-table-column label="操作" width="180" align="center">
          <template #default="{ row }">
            <el-button type="primary" link @click="handleDetail(row)">
              详情
            </el-button>
            <el-button type="success" link @click="handleAnalysis(row)">
              分析
            </el-button>
            <el-button type="warning" link @click="handleExport(row)">
              导出
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model="queryParams.pageNum"
          :page-size="queryParams.pageSize"
          :total="total"
          :page-sizes="[10, 20, 30, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          @update:page-size="(val) => (queryParams.pageSize = val)"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from "vue";
import { Search, Refresh } from "@element-plus/icons-vue";
import { ElMessage } from "element-plus";

// 查询参数
const queryParams = reactive({
  pageNum: 1,
  pageSize: 10,
  className: "",
  examName: "",
  dateRange: [],
});

// 统计数据
const statistics = reactive({
  averageScore: 0,
  highestScore: 0,
  passRate: 0,
  totalStudents: 0,
});

const loading = ref(false);
const total = ref(0);
const gradeList = ref([]);

// 获取成绩列表
const getGradeList = async () => {
  loading.value = true;
  try {
    // TODO: 调用API获取数据
    // const res = await getClassGradeList(queryParams)
    // gradeList.value = res.data.list
    // total.value = res.data.total
    // 更新统计数据
    // statistics.averageScore = res.data.statistics.averageScore
    // statistics.highestScore = res.data.statistics.highestScore
    // statistics.passRate = res.data.statistics.passRate
    // statistics.totalStudents = res.data.statistics.totalStudents
  } catch (error) {
    console.error("获取成绩列表失败:", error);
    ElMessage.error("获取成绩列表失败");
  } finally {
    loading.value = false;
  }
};

// 查询
const handleQuery = () => {
  queryParams.pageNum = 1;
  getGradeList();
};

// 重置
const resetQuery = () => {
  queryParams.className = "";
  queryParams.examName = "";
  queryParams.dateRange = [];
  handleQuery();
};

// 分页
const handleSizeChange = (val) => {
  queryParams.pageSize = val;
  getGradeList();
};

const handleCurrentChange = (val) => {
  queryParams.pageNum = val;
  getGradeList();
};

// 分数样式
const getScoreClass = (score) => {
  if (score >= 90) return "score-excellent";
  if (score >= 80) return "score-good";
  if (score >= 60) return "score-pass";
  return "score-poor";
};

// 及格率状态
const getPassRateStatus = (rate) => {
  if (rate >= 90) return "success";
  if (rate >= 70) return "";
  if (rate >= 50) return "warning";
  return "exception";
};

// 详情
const handleDetail = (row) => {
  // TODO: 实现查看详情功能
};

// 分析
const handleAnalysis = (row) => {
  // TODO: 实现成绩分析功能
};

// 导出
const handleExport = (row) => {
  // TODO: 实现导出功能
};

onMounted(() => {
  getGradeList();
});
</script>

<style scoped>
.class-grade-container {
  padding: 20px;
}

.filter-section {
  background: #fff;
  padding: 20px;
  border-radius: 4px;
  margin-bottom: 20px;
}

.statistics-cards {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-content {
  text-align: center;
}

.card-content .number {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
}

.card-content .unit {
  font-size: 14px;
  color: #909399;
  margin-left: 4px;
}

.grade-table {
  background: #fff;
  padding: 20px;
  border-radius: 4px;
}

.score-excellent {
  color: #67c23a;
  font-weight: bold;
}

.score-good {
  color: #409eff;
  font-weight: bold;
}

.score-pass {
  color: #e6a23c;
  font-weight: bold;
}

.score-poor {
  color: #f56c6c;
  font-weight: bold;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

:deep(.el-card) {
  transition: all 0.3s;
}

:deep(.el-card:hover) {
  transform: translateY(-2px);
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}
</style>
