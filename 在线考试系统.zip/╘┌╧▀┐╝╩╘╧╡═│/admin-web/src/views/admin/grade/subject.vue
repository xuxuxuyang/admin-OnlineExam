<template>
  <div class="subject-grade-container">
    <!-- 搜索和过滤区域 -->
    <div class="filter-section">
      <el-form :inline="true" :model="queryParams" class="search-form">
        <el-form-item label="学科">
          <el-select
            v-model="queryParams.subjectId"
            placeholder="请选择学科"
            clearable
            style="width: 200px"
          >
            <el-option
              v-for="item in subjectOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="班级">
          <el-select
            v-model="queryParams.classId"
            placeholder="请选择班级"
            clearable
            style="width: 200px"
          >
            <el-option
              v-for="item in classOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="考试时间">
          <el-date-picker
            v-model="queryParams.dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="YYYY-MM-DD"
            style="width: 380px"
          />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleQuery">
            <el-icon><Search /></el-icon>查询
          </el-button>
          <el-button @click="resetQuery">
            <el-icon><Refresh /></el-icon>重置
          </el-button>
        </el-form-item>
      </el-form>
    </div>

    <!-- 数据统计卡片 -->
    <div class="statistics-cards">
      <el-row :gutter="20">
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="card-header">
                <span>学科平均分</span>
                <el-tag type="success">全年级</el-tag>
              </div>
            </template>
            <div class="card-content">
              <span class="number">{{ statistics.averageScore || 0 }}</span>
              <span class="unit">分</span>
            </div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="card-header">
                <span>优秀率</span>
                <el-tag type="danger">85分以上</el-tag>
              </div>
            </template>
            <div class="card-content">
              <span class="number">{{ statistics.excellentRate || 0 }}</span>
              <span class="unit">%</span>
            </div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="card-header">
                <span>及格率</span>
                <el-tag type="warning">60分以上</el-tag>
              </div>
            </template>
            <div class="card-content">
              <span class="number">{{ statistics.passRate || 0 }}</span>
              <span class="unit">%</span>
            </div>
          </el-card>
        </el-col>
        <el-col :span="6">
          <el-card shadow="hover">
            <template #header>
              <div class="card-header">
                <span>标准差</span>
                <el-tag type="info">离散程度</el-tag>
              </div>
            </template>
            <div class="card-content">
              <span class="number">{{
                statistics.standardDeviation || 0
              }}</span>
              <span class="unit">分</span>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <!-- 成绩分布图 -->
    <div class="chart-section">
      <el-card shadow="hover">
        <template #header>
          <div class="card-header">
            <span>成绩分布</span>
            <el-radio-group v-model="chartType" size="small">
              <el-radio-button label="bar">柱状图</el-radio-button>
              <el-radio-button label="line">折线图</el-radio-button>
            </el-radio-group>
          </div>
        </template>
        <div class="chart-container" ref="chartRef"></div>
      </el-card>
    </div>

    <!-- 成绩表格 -->
    <div class="grade-table">
      <el-table
        v-loading="loading"
        :data="gradeList"
        border
        stripe
        style="width: 100%"
      >
        <el-table-column type="index" label="序号" width="60" align="center" />
        <el-table-column prop="subjectName" label="学科" align="center" />
        <el-table-column prop="className" label="班级" align="center" />
        <el-table-column prop="examName" label="考试名称" align="center" />
        <el-table-column prop="averageScore" label="平均分" align="center">
          <template #default="{ row }">
            <span :class="getScoreClass(row.averageScore)">
              {{ row.averageScore }}
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="excellentRate" label="优秀率" align="center">
          <template #default="{ row }">
            <el-progress
              :percentage="row.excellentRate"
              :status="getExcellentRateStatus(row.excellentRate)"
            />
          </template>
        </el-table-column>
        <el-table-column prop="passRate" label="及格率" align="center">
          <template #default="{ row }">
            <el-progress
              :percentage="row.passRate"
              :status="getPassRateStatus(row.passRate)"
            />
          </template>
        </el-table-column>
        <el-table-column prop="examDate" label="考试时间" align="center" />
        <el-table-column label="操作" width="200" align="center">
          <template #default="{ row }">
            <el-button type="primary" link @click="handleDetail(row)">
              详情
            </el-button>
            <el-button type="success" link @click="handleTrend(row)">
              趋势
            </el-button>
            <el-button type="warning" link @click="handleExport(row)">
              导出
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination">
        <el-pagination
          v-model="queryParams.pageNum"
          :page-size="queryParams.pageSize"
          :total="total"
          :page-sizes="[10, 20, 30, 50]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          @update:page-size="(val) => (queryParams.pageSize = val)"
        />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, onUnmounted, watch } from "vue";
import { Search, Refresh } from "@element-plus/icons-vue";
import { ElMessage } from "element-plus";
import * as echarts from "echarts";

// 查询参数
const queryParams = reactive({
  pageNum: 1,
  pageSize: 10,
  subjectId: "",
  classId: "",
  dateRange: [],
});

// 统计数据
const statistics = reactive({
  averageScore: 0,
  excellentRate: 0,
  passRate: 0,
  standardDeviation: 0,
});

// 图表相关
const chartRef = ref(null);
const chartType = ref("bar");
let chart = null;

// 拉选项
const subjectOptions = ref([
  { value: "1", label: "语文" },
  { value: "2", label: "数学" },
  { value: "3", label: "英语" },
]);

const classOptions = ref([
  { value: "1", label: "一年级一班" },
  { value: "2", label: "一年级二班" },
]);

const loading = ref(false);
const total = ref(0);
const gradeList = ref([]);

// 初始化图表
const initChart = () => {
  if (chartRef.value) {
    chart = echarts.init(chartRef.value);
    updateChart();
  }
};

// 更新图表数据
const updateChart = () => {
  const option = {
    title: {
      text: "成绩分布图",
      left: "center",
    },
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow",
      },
    },
    legend: {
      top: "30px",
    },
    grid: {
      top: "80px",
      left: "3%",
      right: "4%",
      bottom: "3%",
      containLabel: true,
    },
    xAxis: {
      type: "category",
      data: ["0-60", "60-70", "70-80", "80-90", "90-100"],
      axisLabel: {
        interval: 0,
      },
    },
    yAxis: {
      type: "value",
      name: "人数",
      nameTextStyle: {
        padding: [0, 0, 0, 40],
      },
    },
    series: [
      {
        name: "学生人数",
        type: chartType.value,
        data: [5, 10, 15, 12, 8],
        markLine: {
          data: [
            {
              type: "average",
              name: "平均值",
              label: {
                formatter: "平均: {c}",
              },
            },
          ],
        },
        itemStyle: {
          color: "#409EFF",
        },
        areaStyle:
          chartType.value === "line"
            ? {
                color: {
                  type: "linear",
                  x: 0,
                  y: 0,
                  x2: 0,
                  y2: 1,
                  colorStops: [
                    {
                      offset: 0,
                      color: "rgba(64,158,255,0.2)",
                    },
                    {
                      offset: 1,
                      color: "rgba(64,158,255,0)",
                    },
                  ],
                },
              }
            : null,
      },
    ],
  };
  chart?.setOption(option, true);
};

// 获取成绩列表
const getGradeList = async () => {
  loading.value = true;
  try {
    // TODO: 调用API获取数据
    // const res = await getSubjectGradeList(queryParams)
    // gradeList.value = res.data.list
    // total.value = res.data.total
    // 更新统计数据
    // statistics.averageScore = res.data.statistics.averageScore
    // statistics.excellentRate = res.data.statistics.excellentRate
    // statistics.passRate = res.data.statistics.passRate
    // statistics.standardDeviation = res.data.statistics.standardDeviation
    updateChart();
  } catch (error) {
    console.error("获取成绩列表失败:", error);
    ElMessage.error("获取成绩列表失败");
  } finally {
    loading.value = false;
  }
};

// 查询
const handleQuery = () => {
  queryParams.pageNum = 1;
  getGradeList();
};

// 重置
const resetQuery = () => {
  queryParams.subjectId = "";
  queryParams.classId = "";
  queryParams.dateRange = [];
  handleQuery();
};

// 分页
const handleSizeChange = (val) => {
  queryParams.pageSize = val;
  getGradeList();
};

const handleCurrentChange = (val) => {
  queryParams.pageNum = val;
  getGradeList();
};

// 分数样式
const getScoreClass = (score) => {
  if (score >= 90) return "score-excellent";
  if (score >= 80) return "score-good";
  if (score >= 60) return "score-pass";
  return "score-poor";
};

// 优秀率状态
const getExcellentRateStatus = (rate) => {
  if (rate >= 30) return "success";
  if (rate >= 20) return "";
  if (rate >= 10) return "warning";
  return "exception";
};

// 及格率状态
const getPassRateStatus = (rate) => {
  if (rate >= 90) return "success";
  if (rate >= 70) return "";
  if (rate >= 50) return "warning";
  return "exception";
};

// 详情
const handleDetail = (row) => {
  // TODO: 实现查看详情功能
};

// 趋势分析
const handleTrend = (row) => {
  // TODO: 实现趋势分析功能
};

// 导出
const handleExport = (row) => {
  // TODO: 实现导出功能
};

// 监听窗口大小变化
const handleResize = () => {
  if (chart) {
    chart.resize();
  }
};

// 在组件卸载时清理
onUnmounted(() => {
  window.removeEventListener("resize", handleResize);
  if (chart) {
    chart.dispose();
    chart = null;
  }
});

// 监听图表类型变化，需要添加 immediate 选项
watch(
  chartType,
  () => {
    updateChart();
  },
  { immediate: true }
);

onMounted(() => {
  getGradeList();
  initChart();
  window.addEventListener("resize", handleResize);
});
</script>

<style scoped>
.subject-grade-container {
  padding: 20px;
}

.filter-section {
  background: #fff;
  padding: 20px;
  border-radius: 4px;
  margin-bottom: 20px;
}

/* 搜索表单样式 */
:deep(.search-form .el-form-item) {
  margin-bottom: 0;
  margin-right: 20px;
}

:deep(.search-form .el-select),
:deep(.search-form .el-date-picker) {
  width: 100%;
}

.statistics-cards {
  margin-bottom: 20px;
}

.chart-section {
  margin-bottom: 20px;
  background: #fff;
  border-radius: 4px;
}

.chart-container {
  height: 400px;
  width: 100%;
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-content {
  text-align: center;
}

.card-content .number {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
}

.card-content .unit {
  font-size: 14px;
  color: #909399;
  margin-left: 4px;
}

.grade-table {
  background: #fff;
  padding: 20px;
  border-radius: 4px;
}

.score-excellent {
  color: #67c23a;
  font-weight: bold;
}

.score-good {
  color: #409eff;
  font-weight: bold;
}

.score-pass {
  color: #e6a23c;
  font-weight: bold;
}

.score-poor {
  color: #f56c6c;
  font-weight: bold;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

:deep(.el-card) {
  transition: all 0.3s;
}

:deep(.el-card:hover) {
  transform: translateY(-2px);
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

/* 修复响应式样式语法 */
@media screen and (max-width: 768px) {
  .chart-container {
    height: 300px;
  }

  :deep(.statistics-cards .el-col) {
    margin-bottom: 20px;
  }
}
</style>
