<template>
  <div class="paper-container">
    <el-card class="box-card">
      <template #header>
        <div class="card-header">
          <div class="header-left">
            <span class="title">组卷管理</span>
            <el-select
              v-model="currentSubject"
              placeholder="选择学科"
              class="filter-select"
            >
              <el-option
                v-for="item in subjectList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <el-select
              v-model="paperType"
              placeholder="试卷类型"
              class="filter-select"
            >
              <el-option
                v-for="item in typeList"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </div>
          <div class="header-right">
            <el-button type="success" @click="handleAutoGenerate">
              <el-icon><Magic /></el-icon>智能组卷
            </el-button>
            <el-button type="primary" @click="handleCreate">
              <el-icon><Plus /></el-icon>手动组卷
            </el-button>
          </div>
        </div>
      </template>

      <div class="paper-content">
        <el-table :data="paperList" style="width: 100%">
          <el-table-column prop="name" label="试卷名称" min-width="200" />
          <el-table-column prop="subject" label="科目" width="120" />
          <el-table-column prop="type" label="类型" width="100" />
          <el-table-column prop="questionCount" label="题目数" width="100" />
          <el-table-column prop="totalScore" label="总分" width="80" />
          <el-table-column prop="difficulty" label="难度" width="120">
            <template #default="{ row }">
              <el-rate v-model="row.difficulty" disabled />
            </template>
          </el-table-column>
          <el-table-column prop="createTime" label="创建时间" width="180" />
          <el-table-column prop="status" label="状态" width="100">
            <template #default="{ row }">
              <el-tag :type="getStatusType(row.status)">{{
                row.status
              }}</el-tag>
            </template>
          </el-table-column>
          <el-table-column label="操作" width="250" fixed="right">
            <template #default="{ row }">
              <el-button
                type="primary"
                size="small"
                :disabled="row.status === '已使用'"
                @click="handleEdit(row)"
              >
                编辑
              </el-button>
              <el-button type="info" size="small" @click="handlePreview(row)">
                预览
              </el-button>
              <el-button
                type="danger"
                size="small"
                :disabled="row.status === '已使用'"
                @click="handleDelete(row)"
              >
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref } from "vue";

const currentSubject = ref("");
const paperType = ref("");

const subjectList = [
  { label: "全部科目", value: "" },
  { label: "高等数学", value: "math" },
  { label: "大学英语", value: "english" },
  { label: "计算机基础", value: "computer" },
];

const typeList = [
  { label: "全部类型", value: "" },
  { label: "期中考试", value: "midterm" },
  { label: "期末考试", value: "final" },
  { label: "单元测试", value: "unit" },
  { label: "模拟考试", value: "mock" },
];

const paperList = ref([
  {
    name: "2024春季高等数学期中试卷A",
    subject: "高等数学",
    type: "期中考试",
    questionCount: 20,
    totalScore: 100,
    difficulty: 3,
    createTime: "2024-03-15 14:30",
    status: "未使用",
  },
  {
    name: "2024春季大学英语期中试卷B",
    subject: "大学英语",
    type: "期中考试",
    questionCount: 50,
    totalScore: 100,
    difficulty: 4,
    createTime: "2024-03-16 09:30",
    status: "已使用",
  },
]);

const getStatusType = (status) => {
  const typeMap = {
    未使用: "success",
    已使用: "info",
  };
  return typeMap[status];
};

const handleAutoGenerate = () => {
  console.log("智能组卷");
};

const handleCreate = () => {
  console.log("手动组卷");
};

const handleEdit = (paper) => {
  console.log("编辑试卷", paper);
};

const handlePreview = (paper) => {
  console.log("预览试卷", paper);
};

const handleDelete = (paper) => {
  console.log("删除试卷", paper);
};
</script>

<style scoped>
.paper-container {
  padding: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.header-left .title {
  font-size: 16px;
  font-weight: 500;
}

.header-left .filter-select {
  width: 160px;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 12px;
}

@media screen and (max-width: 1200px) {
  .header-left .filter-select {
    width: 140px;
  }
}

@media screen and (max-width: 768px) {
  .card-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;
  }

  .header-left {
    width: 100%;
    flex-wrap: wrap;
  }

  .header-left .filter-select {
    width: 160px;
  }

  .header-right {
    width: 100%;
  }
}

.paper-content {
  margin-top: 20px;
}
</style>
