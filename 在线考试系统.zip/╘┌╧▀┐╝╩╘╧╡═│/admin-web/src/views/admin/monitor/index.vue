<template>
  <div class="monitor-container">
    <!-- 数据概览 -->
    <el-row :gutter="20" class="statistics">
      <el-col :span="6" v-for="stat in statistics" :key="stat.title">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-content">
            <div class="stat-icon" :style="{ backgroundColor: stat.color }">
              <el-icon><component :is="stat.icon" /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ stat.value }}</div>
              <div class="stat-title">{{ stat.title }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 主要内容区 -->
    <el-card class="main-content">
      <!-- 顶部操作栏 -->
      <div class="operation-bar">
        <div class="left-operations">
          <el-radio-group v-model="monitorMode" size="large">
            <el-radio-button label="live">实时监控</el-radio-button>
            <el-radio-button label="playback">历史回放</el-radio-button>
          </el-radio-group>
        </div>
        <div class="right-filters">
          <el-select
            v-model="filters.exam"
            placeholder="选择考试"
            clearable
            class="filter-select"
          >
            <el-option
              v-for="item in examOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-select
            v-model="filters.class"
            placeholder="选择班级"
            clearable
            class="filter-select"
          >
            <el-option
              v-for="item in classOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-input
            v-model="filters.keyword"
            placeholder="搜索学生姓名/学号"
            clearable
            class="search-input"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
          <div class="filter-buttons">
            <el-button type="primary" @click="handleSearch">
              <el-icon><Search /></el-icon>搜索
            </el-button>
            <el-button @click="resetFilters">
              <el-icon><Refresh /></el-icon>重置
            </el-button>
          </div>
        </div>
      </div>

      <!-- 监控视图 -->
      <div class="monitor-view">
        <el-row :gutter="16">
          <el-col :span="6" v-for="student in monitorList" :key="student.id">
            <el-card
              class="monitor-card"
              :class="{ warning: student.hasWarning }"
            >
              <div class="monitor-header">
                <div class="student-info">
                  <span class="name">{{ student.name }}</span>
                  <el-tag
                    size="small"
                    :type="student.status === 'online' ? 'success' : 'danger'"
                  >
                    {{ student.status === "online" ? "在线" : "离线" }}
                  </el-tag>
                </div>
                <div class="warning-badge" v-if="student.warningCount">
                  <el-badge :value="student.warningCount" type="danger" />
                </div>
              </div>
              <div class="monitor-screen">
                <el-image
                  :src="student.screenShot"
                  fit="cover"
                  :preview-src-list="[student.screenShot]"
                >
                  <template #error>
                    <div class="screen-error">
                      <el-icon><VideoCamera /></el-icon>
                      <span v-if="!student.hasWarning">画面丢失</span>
                    </div>
                  </template>
                </el-image>
                <div class="screen-overlay" v-if="student.hasWarning">
                  <el-icon color="#F56C6C"><Warning /></el-icon>
                  <span>检测到异常行为</span>
                </div>
              </div>
              <div class="monitor-footer">
                <div class="action-buttons">
                  <el-tooltip content="查看详情" placement="top">
                    <el-button
                      type="primary"
                      link
                      @click="handleViewDetail(student)"
                    >
                      <el-icon><View /></el-icon>
                    </el-button>
                  </el-tooltip>
                  <el-tooltip content="实时通话" placement="top">
                    <el-button
                      type="success"
                      link
                      :disabled="student.status !== 'online'"
                      @click="handleCall(student)"
                    >
                      <el-icon><Phone /></el-icon>
                    </el-button>
                  </el-tooltip>
                  <el-tooltip content="警告提醒" placement="top">
                    <el-button type="warning" link @click="handleWarn(student)">
                      <el-icon><Bell /></el-icon>
                    </el-button>
                  </el-tooltip>
                  <el-tooltip content="终止考试" placement="top">
                    <el-button
                      type="danger"
                      link
                      @click="handleTerminate(student)"
                    >
                      <el-icon><CircleClose /></el-icon>
                    </el-button>
                  </el-tooltip>
                </div>
                <div class="status-info">
                  <div class="time">已考: {{ student.examTime }}</div>
                  <div class="progress">完成: {{ student.progress }}%</div>
                </div>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </div>

      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          v-model="pagination.currentPage"
          :current-page="pagination.currentPage"
          :page-size="pagination.pageSize"
          @update:current-page="(val) => (pagination.currentPage = val)"
          @update:page-size="(val) => (pagination.pageSize = val)"
          :page-sizes="[12, 24, 36, 48]"
          :total="pagination.total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <!-- 详情抽屉 -->
    <el-drawer
      v-model="drawerVisible"
      title="监控详情"
      size="800px"
      :destroy-on-close="true"
    >
      <template #default>
        <div class="detail-content">
          <!-- 详情内容 -->
        </div>
      </template>
    </el-drawer>
  </div>
</template>

<script setup>
import { ref, reactive } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";

// 统计数据
const statistics = [
  {
    title: "在线人数",
    value: "234",
    icon: "User",
    color: "#409EFF",
  },
  {
    title: "异常警告",
    value: "12",
    icon: "Warning",
    color: "#F56C6C",
  },
  {
    title: "考试场次",
    value: "5",
    icon: "Calendar",
    color: "#67C23A",
  },
  {
    title: "监控教室",
    value: "8",
    icon: "Monitor",
    color: "#E6A23C",
  },
];

// 监控模式
const monitorMode = ref("live");

// 筛选条件
const filters = reactive({
  exam: "",
  class: "",
  keyword: "",
});

// 选项数据
const examOptions = [
  { label: "2024春季高数期中考试", value: "math2024" },
  { label: "2024春季英语期中考试", value: "eng2024" },
];

const classOptions = [
  { label: "计算机2101班", value: "cs2101" },
  { label: "计算机2102班", value: "cs2102" },
];

// 监控列表数据
const monitorList = ref([
  {
    id: 1,
    name: "张三",
    status: "online",
    screenShot: "path/to/screenshot.jpg",
    hasWarning: true,
    warningCount: 2,
    examTime: "45:30",
    progress: 65,
  },
  // ... 其他学生数据
]);

// 分页
const pagination = reactive({
  currentPage: 1,
  pageSize: 12,
  total: 0,
});

// 抽屉控制
const drawerVisible = ref(false);

// 方法定义
const handleSearch = () => {
  console.log("搜索条件：", filters);
};

const resetFilters = () => {
  Object.keys(filters).forEach((key) => {
    filters[key] = "";
  });
  handleSearch();
};

const handleViewDetail = (student) => {
  drawerVisible.value = true;
  // TODO: 加载学生详情数据
};

const handleCall = (student) => {
  // TODO: 实现实时通话功能
};

const handleWarn = (student) => {
  ElMessageBox.confirm("确定要向该学生发送警告提醒吗？", "警告提醒", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning",
  }).then(() => {
    ElMessage.success("已发送警告提醒");
  });
};

const handleTerminate = (student) => {
  ElMessageBox.confirm(
    "确定要终止该学生的考试吗？此操作不可恢复！",
    "终止考试",
    {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "danger",
    }
  ).then(() => {
    ElMessage.success("已终止考试");
  });
};

// ... 其他方法实现
</script>

<style scoped>
.monitor-container {
  padding: 20px;
}

.statistics {
  margin-bottom: 20px;
}

.stat-card .stat-content {
  display: flex;
  align-items: center;
}

.stat-card .stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
}

.stat-card .stat-icon :deep(.el-icon) {
  font-size: 24px;
  color: #fff;
}

.stat-card .stat-info .stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-card .stat-info .stat-title {
  font-size: 14px;
  color: #909399;
  margin-top: 4px;
}

.operation-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.right-filters {
  display: flex;
  gap: 8px;
  align-items: center;
}

.right-filters .filter-select {
  width: 160px;
}

.right-filters .search-input {
  width: 200px;
}

.filter-buttons {
  display: flex;
  gap: 8px;
}

.monitor-view {
  margin-bottom: 20px;
}

.monitor-card {
  margin-bottom: 16px;
  transition: all 0.3s;
}

.monitor-card.warning {
  border: 1px solid #f56c6c;
}

.monitor-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.student-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.student-info .name {
  font-weight: 500;
}

.monitor-screen {
  position: relative;
  width: 100%;
  height: 0;
  padding-bottom: 75%;
  margin-bottom: 12px;
}

.monitor-screen .el-image {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 4px;
  overflow: hidden;
}

.screen-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  background-color: #f5f7fa;
  color: #909399;
}

.screen-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(245, 108, 108, 0.1);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: #f56c6c;
}

.monitor-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.action-buttons {
  display: flex;
  gap: 8px;
}

.status-info {
  text-align: right;
  font-size: 13px;
  color: #606266;
}

.pagination-container {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #ebeef5;
}

:deep(.el-card) {
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.05);
}

/* 响应式布局 */
@media screen and (max-width: 1400px) {
  .right-filters .filter-select {
    width: 140px;
  }

  .right-filters .search-input {
    width: 180px;
  }
}

@media screen and (max-width: 1200px) {
  .operation-bar {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;
  }

  .right-filters {
    width: 100%;
    flex-wrap: wrap;
  }
}
</style>
