<template>
  <div class="question-container">
    <!-- 数据概览 -->
    <el-row :gutter="20" class="statistics">
      <el-col :span="6" v-for="stat in statistics" :key="stat.title">
        <el-card shadow="hover" class="stat-card">
          <div class="stat-content">
            <div class="stat-icon" :style="{ backgroundColor: stat.color }">
              <el-icon><component :is="stat.icon" /></el-icon>
            </div>
            <div class="stat-info">
              <div class="stat-value">{{ stat.value }}</div>
              <div class="stat-title">{{ stat.title }}</div>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 主要内容区 -->
    <el-card class="main-content">
      <!-- 顶部操作栏 -->
      <div class="operation-bar">
        <div class="left-operations">
          <el-button type="primary" @click="handleAddQuestion">
            <el-icon><Plus /></el-icon>新增题目
          </el-button>
          <el-button type="success" @click="handleBatchImport">
            <el-icon><Upload /></el-icon>批量导入
          </el-button>
          <el-button type="warning" @click="handleExport">
            <el-icon><Download /></el-icon>导出题库
          </el-button>
          <el-button
            type="danger"
            :disabled="!selectedQuestions.length"
            @click="handleBatchDelete"
          >
            <el-icon><Delete /></el-icon>批量删除
          </el-button>
        </div>
        <div class="right-filters">
          <el-select
            v-model="filters.subject"
            placeholder="选择学科"
            clearable
            class="filter-select"
          >
            <el-option
              v-for="item in subjectOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-select
            v-model="filters.type"
            placeholder="题目类型"
            clearable
            class="filter-select"
          >
            <el-option
              v-for="item in questionTypes"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-select
            v-model="filters.difficulty"
            placeholder="难度等级"
            clearable
            class="filter-select"
          >
            <el-option
              v-for="item in difficultyOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <el-input
            v-model="filters.keyword"
            placeholder="搜索题目内容"
            clearable
            class="search-input"
          >
            <template #prefix>
              <el-icon><Search /></el-icon>
            </template>
          </el-input>
          <div class="filter-buttons">
            <el-button type="primary" @click="handleSearch">
              <el-icon><Search /></el-icon>搜索
            </el-button>
            <el-button @click="resetFilters">
              <el-icon><Refresh /></el-icon>重置
            </el-button>
          </div>
        </div>
      </div>

      <!-- 题目列表 -->
      <el-table
        :data="questionList"
        style="width: 100%"
        border
        stripe
        v-loading="loading"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55" align="center" />
        <el-table-column label="题目内容" min-width="400">
          <template #default="{ row }">
            <div class="question-content">
              <div class="question-type">
                <el-tag :type="getTypeTagType(row.type)" size="small">
                  {{ row.type }}
                </el-tag>
                <el-tag type="info" size="small" class="knowledge-tag">
                  {{ row.knowledge }}
                </el-tag>
              </div>
              <div class="question-title" v-html="row.title"></div>
              <div
                class="question-options"
                v-if="['单选题', '多选题'].includes(row.type)"
              >
                <div
                  v-for="(option, index) in row.options"
                  :key="index"
                  class="option-item"
                >
                  {{ optionLabels[index] }}. {{ option }}
                </div>
              </div>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          prop="subject"
          label="学科"
          width="100"
          align="center"
        />
        <el-table-column
          prop="difficulty"
          label="难度"
          width="120"
          align="center"
        >
          <template #default="{ row }">
            <el-rate
              v-model="row.difficulty"
              disabled
              show-score
              text-color="#ff9900"
            />
          </template>
        </el-table-column>
        <el-table-column
          prop="useCount"
          label="使用次数"
          width="100"
          align="center"
        />
        <el-table-column
          prop="createTime"
          label="创建时间"
          width="180"
          align="center"
        />
        <el-table-column label="操作" width="200" fixed="right" align="center">
          <template #default="{ row }">
            <el-button-group>
              <el-tooltip content="编辑题目" placement="top">
                <el-button type="primary" link @click="handleEdit(row)">
                  <el-icon><Edit /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="查看解析" placement="top">
                <el-button type="success" link @click="handleViewAnalysis(row)">
                  <el-icon><View /></el-icon>
                </el-button>
              </el-tooltip>
              <el-tooltip content="删除题目" placement="top">
                <el-button type="danger" link @click="handleDelete(row)">
                  <el-icon><Delete /></el-icon>
                </el-button>
              </el-tooltip>
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>

      <!-- 分页 -->
      <div class="pagination-container">
        <el-pagination
          v-model="pagination.currentPage"
          :current-page="pagination.currentPage"
          :page-size="pagination.pageSize"
          @update:current-page="(val) => (pagination.currentPage = val)"
          @update:page-size="(val) => (pagination.pageSize = val)"
          :page-sizes="[10, 20, 50, 100]"
          :total="pagination.total"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive } from "vue";
import {
  Plus,
  Edit,
  View,
  Upload,
  Download,
  Delete,
  Search,
  Refresh,
  Document,
  Collection,
  Star,
  DataLine,
} from "@element-plus/icons-vue";
import { ElMessage, ElMessageBox } from "element-plus";

// 统计数据
const statistics = [
  {
    title: "题目总数",
    value: "3,256",
    icon: "Document",
    color: "#409EFF",
  },
  {
    title: "题库数量",
    value: "12",
    icon: "Collection",
    color: "#67C23A",
  },
  {
    title: "本月新增",
    value: "156",
    icon: "Plus",
    color: "#E6A23C",
  },
  {
    title: "使用总数",
    value: "12,890",
    icon: "DataLine",
    color: "#F56C6C",
  },
];

// 筛选条件
const filters = reactive({
  subject: "",
  type: "",
  difficulty: "",
  keyword: "",
});

// 选项数据
const subjectOptions = [
  { label: "语文", value: "chinese" },
  { label: "数学", value: "math" },
  { label: "英语", value: "english" },
];

const questionTypes = [
  { label: "单选题", value: "single" },
  { label: "多选题", value: "multiple" },
  { label: "判断题", value: "judge" },
  { label: "填空题", value: "blank" },
  { label: "简答题", value: "essay" },
];

const difficultyOptions = [
  { label: "简单", value: 1 },
  { label: "中等", value: 2 },
  { label: "困难", value: 3 },
];

const optionLabels = ["A", "B", "C", "D", "E", "F", "G", "H"];

// 表格数据
const loading = ref(false);
const selectedQuestions = ref([]);
const questionList = ref([
  {
    id: 1,
    title: "下列关于面向对象编程的说法，正确的是：",
    type: "单选题",
    subject: "计算机",
    knowledge: "面向对象编程",
    difficulty: 3,
    useCount: 128,
    createTime: "2024-03-15 14:30",
    options: [
      "封装是为了隐藏实现细节，保护数据",
      "继承只能实现单继承，不能多继承",
      "多态必须通过接口实现",
      "抽象类可以被实例化",
    ],
  },
  // ... 其他题目数据
]);

// 分页
const pagination = reactive({
  currentPage: 1,
  pageSize: 10,
  total: 0,
});

// 方法定义
const getTypeTagType = (type) => {
  const typeMap = {
    单选题: "success",
    多选题: "warning",
    判断题: "info",
    填空题: "primary",
    简答题: "danger",
  };
  return typeMap[type];
};

const handleSelectionChange = (selection) => {
  selectedQuestions.value = selection;
};

const handleSearch = () => {
  console.log("搜索条件：", filters);
};

const resetFilters = () => {
  Object.keys(filters).forEach((key) => {
    filters[key] = "";
  });
  handleSearch();
};

// ... 其他方法实现
</script>

<style scoped>
.question-container {
  padding: 20px;
}

.statistics {
  margin-bottom: 20px;
}

.stat-card .stat-content {
  display: flex;
  align-items: center;
}

.stat-card .stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
}

.stat-card .stat-icon :deep(.el-icon) {
  font-size: 24px;
  color: #fff;
}

.stat-card .stat-info .stat-value {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-card .stat-info .stat-title {
  font-size: 14px;
  color: #909399;
  margin-top: 4px;
}

.operation-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.left-operations {
  display: flex;
  gap: 12px;
}

.right-filters {
  display: flex;
  gap: 8px;
  align-items: center;
}

.right-filters .filter-select {
  width: 140px;
}

.right-filters .search-input {
  width: 200px;
}

.filter-buttons {
  display: flex;
  gap: 8px;
}

.question-content {
  padding: 8px 0;
}

.question-type {
  margin-bottom: 8px;
  display: flex;
  gap: 8px;
}

.knowledge-tag {
  opacity: 0.8;
}

.question-title {
  margin-bottom: 8px;
  color: #303133;
  line-height: 1.5;
}

.question-options {
  color: #606266;
  font-size: 14px;
}

.option-item {
  margin-bottom: 4px;
  line-height: 1.4;
}

.pagination-container {
  display: flex;
  justify-content: flex-end;
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #ebeef5;
}

:deep(.el-card) {
  border-radius: 8px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.05);
}

:deep(.el-button-group .el-button) {
  padding: 6px 8px;
}

/* 响应式布局 */
@media screen and (max-width: 1400px) {
  .right-filters .filter-select {
    width: 120px;
  }

  .right-filters .search-input {
    width: 180px;
  }
}

@media screen and (max-width: 1200px) {
  .operation-bar {
    flex-direction: column;
    align-items: flex-start;
    gap: 16px;
  }

  .right-filters {
    width: 100%;
    flex-wrap: wrap;
  }
}
</style>
