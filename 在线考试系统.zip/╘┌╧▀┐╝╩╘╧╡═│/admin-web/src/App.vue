<template>
    <router-view></router-view>
</template>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}
</style> 