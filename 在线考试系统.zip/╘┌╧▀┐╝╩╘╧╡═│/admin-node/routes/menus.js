const Router = require('@koa/router');
const { verifyToken } = require('../middleware/auth');

const router = new Router({
    prefix: '/api/menus'
});

// 模拟菜单数据库
const menus = [
    {
        id: 1,
        name: '系统管理',
        path: '/system',
        component: 'Layout',
        icon: 'Setting',
        sort: 1,
        parentId: 0,
        createTime: new Date().toISOString(),
        children: [
            {
                id: 2,
                name: '用户管理',
                path: '/system/user',
                component: 'system/user/index',
                icon: 'User',
                sort: 1,
                parentId: 1,
                createTime: new Date().toISOString()
            },
            {
                id: 3,
                name: '角色管理',
                path: '/system/role',
                component: 'system/role/index',
                icon: 'UserFilled',
                sort: 2,
                parentId: 1,
                createTime: new Date().toISOString()
            },
            {
                id: 4,
                name: '菜单管理',
                path: '/system/menu',
                component: 'system/menu/index',
                icon: 'Menu',
                sort: 3,
                parentId: 1,
                createTime: new Date().toISOString()
            }
        ]
    }
];

// 获取菜单列表
router.get('/', verifyToken, async (ctx) => {
    ctx.body = menus;
});

// 新增菜单
router.post('/', verifyToken, async (ctx) => {
    const { name, path, component, icon, sort, parentId } = ctx.request.body;

    // 验证必填字段
    if (!name || !path || !component) {
        ctx.status = 400;
        ctx.body = { message: '菜单名称、路由路径和组件路径不能为空' };
        return;
    }

    // 生成新菜单ID
    const newId = Math.max(...menus.map(m => m.id)) + 1;

    // 创建新菜单
    const newMenu = {
        id: newId,
        name,
        path,
        component,
        icon,
        sort: sort || 0,
        parentId: parentId || 0,
        createTime: new Date().toISOString()
    };

    // 如果是子菜单，添加到父菜单的children中
    if (parentId) {
        const parent = findMenuById(menus, parentId);
        if (parent) {
            if (!parent.children) {
                parent.children = [];
            }
            parent.children.push(newMenu);
        } else {
            ctx.status = 400;
            ctx.body = { message: '父菜单不存在' };
            return;
        }
    } else {
        menus.push(newMenu);
    }

    ctx.status = 201;
    ctx.body = newMenu;
});

// 编辑菜单
router.put('/:id', verifyToken, async (ctx) => {
    const { id } = ctx.params;
    const { name, path, component, icon, sort, parentId } = ctx.request.body;
    
    // 查找并更新菜单
    const menu = findMenuById(menus, parseInt(id));
    
    if (!menu) {
        ctx.status = 404;
        ctx.body = { message: '菜单不存在' };
        return;
    }

    // 更新菜单信息
    Object.assign(menu, {
        name: name || menu.name,
        path: path || menu.path,
        component: component || menu.component,
        icon: icon || menu.icon,
        sort: sort ?? menu.sort,
        parentId: parentId ?? menu.parentId
    });

    ctx.body = menu;
});

// 删除菜单
router.delete('/:id', verifyToken, async (ctx) => {
    const { id } = ctx.params;
    
    // 递归删除菜单及其子菜单
    const deleteMenu = (menus, id) => {
        for (let i = 0; i < menus.length; i++) {
            if (menus[i].id === parseInt(id)) {
                menus.splice(i, 1);
                return true;
            }
            if (menus[i].children) {
                if (deleteMenu(menus[i].children, id)) {
                    return true;
                }
            }
        }
        return false;
    };

    if (deleteMenu(menus, id)) {
        ctx.status = 200;
        ctx.body = { message: '删除成功' };
    } else {
        ctx.status = 404;
        ctx.body = { message: '菜单不存在' };
    }
});

// 辅助函数：递归查找菜单
function findMenuById(menus, id) {
    for (const menu of menus) {
        if (menu.id === id) {
            return menu;
        }
        if (menu.children) {
            const found = findMenuById(menu.children, id);
            if (found) {
                return found;
            }
        }
    }
    return null;
}

module.exports = router; 