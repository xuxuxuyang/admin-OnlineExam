const Router = require('@koa/router');
const { verifyToken } = require('../middleware/auth');

const router = new Router({
    prefix: '/api/roles'
});

// 模拟角色数据库
const roles = [
    {
        id: 1,
        name: 'super_admin',
        description: '超级管理员',
        permissions: ['all'],
        createTime: new Date().toISOString()
    },
    {
        id: 2,
        name: 'admin',
        description: '管理员',
        permissions: ['user:view', 'user:edit'],
        createTime: new Date().toISOString()
    }
];

// 获取角色列表
router.get('/', verifyToken, async (ctx) => {
    ctx.body = roles;
});

// 新增角色
router.post('/', verifyToken, async (ctx) => {
    const { name, description, permissions } = ctx.request.body;

    // 验证必填字段
    if (!name || !description || !permissions) {
        ctx.status = 400;
        ctx.body = { message: '角色名称、描述和权限不能为空' };
        return;
    }

    // 检查角色名是否已存在
    if (roles.find(r => r.name === name)) {
        ctx.status = 400;
        ctx.body = { message: '角色名称已存在' };
        return;
    }

    // 创建新角色
    const newRole = {
        id: roles.length + 1,
        name,
        description,
        permissions,
        createTime: new Date().toISOString()
    };

    roles.push(newRole);
    ctx.status = 201;
    ctx.body = newRole;
});

// 编辑角色
router.put('/:id', verifyToken, async (ctx) => {
    const { id } = ctx.params;
    const { name, description, permissions } = ctx.request.body;
    
    // 查找角色
    const roleIndex = roles.findIndex(r => r.id === parseInt(id));
    
    if (roleIndex === -1) {
        ctx.status = 404;
        ctx.body = { message: '角色不存在' };
        return;
    }

    // 不允许修改超级管理员角色
    if (roles[roleIndex].name === 'super_admin') {
        ctx.status = 403;
        ctx.body = { message: '不能修改超级管理员角色' };
        return;
    }

    // 如果修改角色名，检查是否已存在
    if (name !== roles[roleIndex].name && 
        roles.some(r => r.name === name)) {
        ctx.status = 400;
        ctx.body = { message: '角色名称已存在' };
        return;
    }

    // 更新角色信息
    roles[roleIndex] = {
        ...roles[roleIndex],
        name: name || roles[roleIndex].name,
        description: description || roles[roleIndex].description,
        permissions: permissions || roles[roleIndex].permissions
    };

    ctx.body = roles[roleIndex];
});

// 删除角色
router.delete('/:id', verifyToken, async (ctx) => {
    const { id } = ctx.params;
    
    // 查找角色索引
    const roleIndex = roles.findIndex(r => r.id === parseInt(id));
    
    if (roleIndex === -1) {
        ctx.status = 404;
        ctx.body = { message: '角色不存在' };
        return;
    }

    // 不允许删除超级管理员角色
    if (roles[roleIndex].name === 'super_admin') {
        ctx.status = 403;
        ctx.body = { message: '不能删除超级管理员角色' };
        return;
    }

    // 删除角色
    roles.splice(roleIndex, 1);
    ctx.status = 200;
    ctx.body = { message: '删除成功' };
});

module.exports = router; 