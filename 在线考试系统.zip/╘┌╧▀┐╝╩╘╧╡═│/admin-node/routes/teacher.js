const Router = require('@koa/router');

const router = new Router({
    prefix: '/api/teacher'
});

// 模拟数据库
const users = [
   
];

// 获取用户列表
router.get('/test',async (ctx) => {
    // 返回用户列表时不包含密码
    ctx.body = {
      code: 200,
      message: '测试数据获取成功'
    }
});



module.exports = router; 