const Router = require('@koa/router');
const User = require('../models/User');

const router = new Router({
    prefix: '/api/dbtest'
});

// 测试数据库存储接口
router.post('/user', async (ctx) => {
    try {
        const userData = ctx.request.body;
        
        // 创建新用户
        const newUser = new User(userData);
        
        // 保存到数据库
        const savedUser = await newUser.save();
        
        ctx.body = {
            success: true,
            message: '用户数据保存成功',
            data: savedUser
        };
    } catch (error) {
        ctx.status = 500;
        ctx.body = {
            success: false,
            message: '保存失败',
            error: error.message
        };
    }
});

// 获取所有用户（用于测试）
router.get('/users', async (ctx) => {
    try {
        const users = await User.find({});
        ctx.body = {
            success: true,
            data: users
        };
    } catch (error) {
        ctx.status = 500;
        ctx.body = {
            success: false,
            message: '获取用户列表失败',
            error: error.message
        };
    }
});

module.exports = router; 