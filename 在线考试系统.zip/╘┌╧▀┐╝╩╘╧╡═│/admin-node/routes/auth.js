const Router = require('@koa/router');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { verifyToken } = require('../middleware/auth');

const router = new Router({
    prefix: '/api/auth'
});

const JWT_SECRET = 'your-jwt-secret';

// 模拟用户数据库，导出供其他模块使用
const users = [];

// 创建默认管理员账号
async function createDefaultAdmin() {
    // 检查是否已存在 xuyang 账号
    if (!users.find(u => u.username === 'xuyang')) {
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash('123456', salt);
        users.push({
            username: 'xuyang',
            password: hashedPassword,
            role: 'super_admin'
        });
        console.log('默认管理员账号创建成功');
    }
}

// 创建默认管理员账号
createDefaultAdmin();

// 注册接口
router.post('/register', async (ctx) => {
    const { username, password } = ctx.request.body;
    
    if (users.find(u => u.username === username)) {
        ctx.status = 400;
        ctx.body = { message: '用户已存在' };
        return;
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    users.push({
        username,
        password: hashedPassword
    });

    ctx.status = 201;
    ctx.body = { message: '注册成功' };
});

// 登录接口
router.post('/login', async (ctx) => {
    const { username, password } = ctx.request.body;

    // 添加调试日志
    console.log('Login attempt:', { username, password });

    // 查找用户
    const user = users.find(u => u.username === username);
    if (!user) {
        ctx.status = 401;
        ctx.body = {
            code: 401,
            message: '用户名或密码错误'
        };
        return;
    }

    // 验证密码
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
        ctx.status = 401;
        ctx.body = {
            code: 401,
            message: '用户名或密码错误'
        };
        return;
    }

    // 生成 token
    const token = jwt.sign(
        { username: user.username, role: user.role },
        JWT_SECRET,
        { expiresIn: '24h' }
    );

    ctx.body = {
        code: 200,
        message: '登录成功',
        data: {
            token,
            username: user.username,
            role: user.role
        }
    };
});

// 获取用户信息
router.get('/userinfo', verifyToken, async (ctx) => {
    ctx.body = {
        username: ctx.state.user.username
    };
});

module.exports = {
    router,
    users  // 导出 users 数组
}; 