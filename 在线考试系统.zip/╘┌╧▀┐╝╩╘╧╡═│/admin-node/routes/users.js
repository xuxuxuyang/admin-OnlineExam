const Router = require('@koa/router');
const bcrypt = require('bcryptjs');
const { verifyToken } = require('../middleware/auth');

const router = new Router({
    prefix: '/api/users'
});

// 模拟数据库
const users = [
    {
        id: 1,
        username: 'xuyang',
        role: 'super_admin',
        createTime: new Date().toISOString()
    }
];

// 获取用户列表
router.get('/', verifyToken, async (ctx) => {
    // 返回用户列表时不包含密码
    ctx.body = users.map(({ password, ...rest }) => rest);
});

// 新增用户
router.post('/', verifyToken, async (ctx) => {
    const { username, password, role } = ctx.request.body;

    // 验证必填字段
    if (!username || !password || !role) {
        ctx.status = 400;
        ctx.body = { message: '用户名、密码和角色不能为空' };
        return;
    }

    // 检查用户名是否已存在
    if (users.find(u => u.username === username)) {
        ctx.status = 400;
        ctx.body = { message: '用户名已存在' };
        return;
    }

    // 密码加密
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // 创建新用户
    const newUser = {
        id: users.length + 1,
        username,
        password: hashedPassword,
        role,
        createTime: new Date().toISOString()
    };

    // 同时添加到 auth 模块的 users 数组中
    const authUsers = require('./auth').users;
    authUsers.push({
        username,
        password: hashedPassword,
        role
    });

    users.push(newUser);

    // 返回创建成功的用户信息（不包含密码）
    const { password: _, ...userWithoutPassword } = newUser;
    ctx.status = 201;
    ctx.body = userWithoutPassword;
});

// 在现有代码后添加删除用户接口
router.delete('/:id', verifyToken, async (ctx) => {
    const { id } = ctx.params;
    
    // 查找用户索引
    const userIndex = users.findIndex(u => u.id === parseInt(id));
    
    if (userIndex === -1) {
        ctx.status = 404;
        ctx.body = { message: '用户不存在' };
        return;
    }

    // 不允许删除超级管理员
    if (users[userIndex].role === 'super_admin') {
        ctx.status = 403;
        ctx.body = { message: '不能删除超级管理员' };
        return;
    }

    // 删除用户
    users.splice(userIndex, 1);
    ctx.status = 200;
    ctx.body = { message: '删除成功' };
});

// 添加编辑用户接口
router.put('/:id', verifyToken, async (ctx) => {
    const { id } = ctx.params;
    const { username, role } = ctx.request.body;
    
    // 查找用户
    const userIndex = users.findIndex(u => u.id === parseInt(id));
    
    if (userIndex === -1) {
        ctx.status = 404;
        ctx.body = { message: '用户不存在' };
        return;
    }

    // 如果修改用户名，检查新用户名是否已存在
    if (username !== users[userIndex].username && 
        users.some(u => u.username === username)) {
        ctx.status = 400;
        ctx.body = { message: '用户名已存在' };
        return;
    }

    // 不允许修改超级管理员的角色
    if (users[userIndex].role === 'super_admin' && role !== 'super_admin') {
        ctx.status = 403;
        ctx.body = { message: '不能修改超级管理员的角色' };
        return;
    }

    // 更新用户信息
    users[userIndex] = {
        ...users[userIndex],
        username: username || users[userIndex].username,
        role: role || users[userIndex].role
    };

    // 返回更新后的用户信息（不包含密码）
    const { password: _, ...userWithoutPassword } = users[userIndex];
    ctx.body = userWithoutPassword;
});

module.exports = router; 