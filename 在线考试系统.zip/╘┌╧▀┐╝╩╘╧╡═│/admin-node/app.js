const Koa = require('koa');
const Router = require('@koa/router');
const bodyParser = require('koa-bodyparser');
const cors = require('@koa/cors');
const { router: authRoutes } = require('./routes/auth');
const usersRouter = require('./routes/users');
const { errorHandler } = require('./middleware/errorHandler');
const rolesRouter = require('./routes/roles');
const menusRouter = require('./routes/menus');

const app = new Koa();
const router = new Router();

// 修改日志中间件
app.use(async (ctx, next) => {
    const start = Date.now();
    console.log(`[Request] ${ctx.method} ${ctx.url}`);
    console.log('Headers:', ctx.headers);
    if (ctx.method === 'POST') {
        console.log('Body:', ctx.request.body);
    }
    await next();
    const ms = Date.now() - start;
    console.log(`[Response] ${ctx.method} ${ctx.url} - ${ms}ms - Status: ${ctx.status}`);
});

// 中间件
app.use(cors({
    origin: '*',
    credentials: true,
    allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'Authorization', 'Accept'],
}));
app.use(bodyParser());
app.use(errorHandler);

// 路由
app.use(authRoutes.routes());
app.use(usersRouter.routes());
app.use(authRoutes.allowedMethods());
app.use(usersRouter.allowedMethods());
app.use(rolesRouter.routes());
app.use(rolesRouter.allowedMethods());
app.use(menusRouter.routes());
app.use(menusRouter.allowedMethods());

const PORT = process.env.PORT || 3001;

// 优雅关闭服务器
process.on('SIGINT', () => {
    console.log('Shutting down server...');
    process.exit(0);
});

app.listen(PORT, () => {
    console.log(`后端服务器运行在 http://localhost:${PORT}`);
    console.log('按 Ctrl+C 停止服务器');
}); 