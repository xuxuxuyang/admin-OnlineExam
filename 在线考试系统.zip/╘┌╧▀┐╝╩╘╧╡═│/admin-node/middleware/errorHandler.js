exports.errorHandler = async (ctx, next) => {
    try {
        await next();
    } catch (err) {
        ctx.status = err.status || 500;
        ctx.body = {
            message: err.message || '服务器内部错误'
        };
        ctx.app.emit('error', err, ctx);
    }
}; 