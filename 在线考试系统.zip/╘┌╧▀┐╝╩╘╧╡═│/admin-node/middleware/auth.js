const jwt = require('jsonwebtoken');

const JWT_SECRET = 'your-jwt-secret';

const verifyToken = async (ctx, next) => {
    try {
        const token = ctx.header.authorization?.split(' ')[1];
        if (!token) {
            ctx.status = 401;
            ctx.body = { message: '未提供token' };
            return;
        }
        try {
            const decoded = jwt.verify(token, JWT_SECRET);
            ctx.state.user = decoded;
            await next();
        } catch (err) {
            console.error('Token verification failed:', err);
            ctx.status = 401;
            ctx.body = { message: 'token无效或已过期' };
        }
    } catch (err) {
        console.error('Auth middleware error:', err);
        ctx.status = 500;
        ctx.body = { message: '服务器错误' };
    }
};

module.exports = { verifyToken }; 