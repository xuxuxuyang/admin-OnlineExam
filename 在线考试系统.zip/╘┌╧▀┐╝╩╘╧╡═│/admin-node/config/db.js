const mongoose = require('mongoose');

// MongoDB连接配置
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/exam_system';

// 连接到MongoDB
const connectDB = async () => {
    try {
        await mongoose.connect(MONGODB_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('MongoDB连接成功');
    } catch (error) {
        console.error('MongoDB连接失败:', error.message);
        process.exit(1);
    }
};

// 监听MongoDB连接事件
mongoose.connection.on('disconnected', () => {
    console.log('MongoDB连接断开');
});

mongoose.connection.on('error', (err) => {
    console.error('MongoDB错误:', err);
});

module.exports = connectDB; 